# ProGuard rules for Noor Al-Iman Android WebView App
-keepclassmembers class * extends android.webkit.WebViewClient {
    public void *(..);
}
-keepclassmembers class * extends android.webkit.WebChromeClient {
    public void *(..);
}
-keepattributes JavascriptInterface
