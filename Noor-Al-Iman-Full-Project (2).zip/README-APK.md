# دليل بناء وتنزيل تطبيق «نور الإيمان» لنظام Android (APK)

تم إعداد مشروع Android أصلي كامل واحترافي داخل المجلد `native-android/`، بالإضافة إلى إعداد مسار عمل آلي **GitHub Actions** لبناء ملف APK حقيقي قابل للتثبيت على الهواتف ونشره تلقائياً.

---

## 1. بنية ملفات مشروع Android (`native-android/`)

```text
native-android/
├── app/
│   ├── build.gradle.kts           # إعدادات حزمة com.amirgalal.nooreleman وإصدار SDK 34 والتبعيات
│   ├── proguard-rules.pro         # قواعد حماية WebView والـ Javascript
│   └── src/
│       └── main/
│           ├── AndroidManifest.xml # الصلاحيات وإعدادات التطبيق واسم "نور الإيمان"
│           ├── java/com/amirgalal/nooreleman/
│           │   └── MainActivity.kt # كود WebView الآمن، التنزيلات، رفع الملفات، وشاشة انقطاع النت
│           └── res/
│               ├── layout/
│               │   └── activity_main.xml # واجهة التحميل والتحديث وشاشة إعادة المحاولة
│               ├── mipmap-*/             # أيقونات التطبيق الرسمية بجميع المقاسات (من شعار المشروع)
│               ├── values/               # النصوص العربية والألوان الذهبية والثيم الداكن
│               └── xml/
│                   └── network_security_config.xml # منع الاتصالات غير المشفرة وتأمين النطاقات
├── gradle/wrapper/
│   ├── gradle-wrapper.jar         # حزمة Gradle Wrapper الرسمية
│   └── gradle-wrapper.properties  # إصدار Gradle 8.5
├── build.gradle.kts               # إعدادات المكونات الرئيسية لـ Android و Kotlin
├── settings.gradle.kts            # إعدادات المستودعات والمشروع
├── gradle.properties              # إعدادات الذاكرة و AndroidX
├── gradlew                        # سكريبت تشغيل Gradle لأنظمة Linux / macOS
└── gradlew.bat                    # سكريبت تشغيل Gradle لأنظمة Windows
```

---

## 2. طريقة ربط المشروع بـ GitHub ومزامنة الملفات

إذا لم تكن قد رفعت المشروع إلى GitHub بعد، افتح Terminal في مجلد المشروع ونفّذ الخطوات التالية:

```bash
# 1. تهيئة مستودع Git
git init

# 2. إضافة جميع الملفات (بما في ذلك native-android و workflows)
git add .

# 3. حفظ التعديلات
git commit -m "إضافة مشروع أندرويد الأصلي وإعداد GitHub Actions لبناء APK"

# 4. تغيير اسم الفرع الرئيسي إلى main
git branch -M main

# 5. ربط المشروع بمستودعك على GitHub (استبدل YOUR_USERNAME و YOUR_REPO)
git remote add origin https://github.com/YOUR_USERNAME/YOUR_REPO.git

# 6. رفع الكود إلى GitHub
git push -u origin main
```

> **ملاحظة حول المستودع العام والخاص:**  
> لكي يتمكن أي شخص في العالم من تنزيل ملف APK مباشرة دون الحاجة لتسجيل دخول إلى GitHub، **يجب أن يكون المستودع عاماً (Public)**.  
> إذا كان المستودع خاصاً (Private)، سيتطلب رابط التنزيل تسجيل الدخول وصلاحيات على المستودع. الموقع لا يحتوي على أسرار خادم داخل الكود المرفوع، لذا يمكن جعل مستودع الواجهة والتطبيق عاماً بأمان.

---

## 3. طريقة تشغيل GitHub Actions لبناء ملف APK يدويًا

1. ادخل إلى صفحة مستودعك على **GitHub**.
2. اضغط على تبويب **Actions** في الشريط العلوي.
3. من القائمة الجانبية اليسرى، اختر سير العمل:  
   **Build & Release Noor Al-Iman APK**
4. اضغط على زر **Run workflow** في الجهة اليمنى.
5. يمكنك كتابة إصدار التطبيق (مثلاً `1.0.0`) ثم الضغط على **Run workflow** الأخضر.
6. سيبدأ البناء تلقائياً ويستغرق حوالي دقيقتين إلى 3 دقائق لتثبيت بيئة Java وAndroid SDK وتجميع ملف APK.

---

## 4. مكان العثور على ملف APK بعد اكتمال البناء

بمجرد اكتمال علامة الصح الخضراء (Success) في GitHub Actions:

1. **في صفحة الإصدارات (Releases):**  
   في يمين الصفحة الرئيسية للمستودع ستجد قسماً باسم **Releases**، ستجد فيه الإصدار المنشور (مثل `v1.0.0`) وبداخله الملف المرفق:  
   `Noor-Al-Iman.apk`
2. **في تبويب Actions:**  
   في أسفل صفحة تشغيل الـ Workflow ستجد قسماً باسم **Artifacts** يحتوي أيضاً على نسخة جاهزة للتحميل.

---

## 5. رابط التنزيل المباشر ومشاركته

صيغة الرابط الثابت لأحدث إصدار هي:

```text
https://github.com/OWNER/REPOSITORY/releases/latest/download/Noor-Al-Iman.apk
```

### كيف تستخدم هذا الرابط؟
- استبدل `OWNER` باسم حسابك على GitHub (مثلاً `amirgalal`).
- استبدل `REPOSITORY` باسم المستودع (مثلاً `noor-eleman`).
- فيصبح الرابط:
  `https://github.com/amirgalal/noor-eleman/releases/latest/download/Noor-Al-Iman.apk`
- هذا الرابط ثابت ودائم؛ في كل مرة تبني فيها إصداراً جديداً سيقوم تلقائياً بتنزيل أحدث ملف APK.

---

## 6. الفرق بين Debug APK و Release APK

| الخاصية | Debug APK (الافتراضي) | Release APK (الإنتاجي الموقّع) |
| :--- | :--- | :--- |
| **التوقيع** | مفتاح اختبار تجريبي ينشئه أندرويد تلقائياً | مفتاح مشفر خاص بك (Keystore / JKS) |
| **التثبيت على الهاتف** | يُثبّت مباشرة على أي هاتف أندرويد (قد يظهر تحذير روتيني عن مصادر غير معروفة) | يُثبّت كإصدار رسمي معتمد ومستقر |
| **التحديثات المستقبلية** | عند التحديث، قد يتطلب إزالة النسخة السابقة إذا تغير مفتاح التصحيح | يتيح تحديث التطبيق فوق النسخة الحالية بدون حذف بيانات المستخدم |
| **متاجر التطبيقات** | غير مقبول في Google Play | هو المطلوب للنشر في المتاجر الرسمية |

---

## 7. طريقة إنشاء مفتاح توقيع إنتاجي (Keystore) واستخدامه في GitHub Secrets

لإنتاج **Release APK** موقّع رسمياً عبر GitHub Actions:

### خطوة أ: إنشاء المفتاح محلياً على جهازك
نفّذ الأمر التالي في Terminal:
```bash
keytool -genkey -v -keystore my-release-key.jks -keyalg RSA -keysize 2048 -validity 10000 -alias noor-key
```
(سيطلب منك كلمة مرور وبيانات الاسم — احفظ كلمة المرور والـ Alias جيداً).

### خطوة ب: تحويل ملف المفتاح إلى نص Base64
- على Linux / Mac:
  ```bash
  base64 -w 0 my-release-key.jks > keystore_base64.txt
  ```
- على Windows PowerShell:
  ```powershell
  [Convert]::ToBase64String([IO.File]::ReadAllBytes("my-release-key.jks")) | Out-File -Encoding ASCII keystore_base64.txt
  ```

### خطوة ج: إضافة الأسرار في GitHub
1. في مستودع GitHub، انتقل إلى **Settings** > **Secrets and variables** > **Actions**.
2. اضغط **New repository secret** وأضف الـ 4 أسرار التالية:
   - `KEYSTORE_BASE64`: محتوى ملف `keystore_base64.txt` كاملاً.
   - `KEYSTORE_PASSWORD`: كلمة مرور الـ Keystore.
   - `KEY_ALIAS`: اسم المفتاح (في مثالنا: `noor-key`).
   - `KEY_PASSWORD`: كلمة مرور المفتاح.

> إذا لم تُضف هذه الأسرار، سيقوم الـ Workflow تلقائياً ببناء **Debug APK** سليم وجاهز للتثبيت والمشاركة دون أن يفشل البناء!

---

## 8. ملاحظة تقنية هامة حول عمل التطبيق
تطبيق **نور الإيمان** هو تطبيق يعتمد على الاتصال بالإنترنت (Online-dependent App) لعرض القرآن الكريم والصلوات والأذكار الحية من الرابط الآمن المعتمد للمشروع. وقد تم تضمين شاشة مخصصة باللغة العربية مع زر «إعادة المحاولة» تظهر بلباقة عند انقطاع الإنترنت.
