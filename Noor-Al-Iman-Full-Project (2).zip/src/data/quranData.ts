export interface QuranWordMeaning {
  word: string;
  meaning: string;
  root?: string;
}

export interface QuranAyah {
  number: number;
  ayahNumberInSurah: number;
  text: string;
  audioUrl: string;
  tafseer: string;
  asbabNuzul?: string;
  vocabulary: QuranWordMeaning[];
}

export interface SurahSummary {
  number: number;
  name: string;
  englishName: string;
  englishNameTranslation: string;
  numberOfAyahs: number;
  revelationType: 'Meccan' | 'Medinan';
  virtueAr: string;
}

export interface DetailedSurah extends SurahSummary {
  bismillahPre: boolean;
  themeAr: string;
  asbabGeneral?: string;
  ayahs: QuranAyah[];
}

export const SURAH_LIST: SurahSummary[] = [
  { number: 1, name: 'الفَاتِحَة', englishName: 'Al-Faatiha', englishNameTranslation: 'The Opening', numberOfAyahs: 7, revelationType: 'Meccan', virtueAr: 'أم الكتاب والسبع المثاني والشفاء التام' },
  { number: 2, name: 'البَقَرَة', englishName: 'Al-Baqara', englishNameTranslation: 'The Cow', numberOfAyahs: 286, revelationType: 'Medinan', virtueAr: 'سنام القرآن ولا تستطيعها البَطَلَة (السحرة)' },
  { number: 3, name: 'آل عِمْرَان', englishName: 'Aal-i-Imraan', englishNameTranslation: 'The Family of Imran', numberOfAyahs: 200, revelationType: 'Medinan', virtueAr: 'تأتي هي والبقرة كغمامتان تحاجان عن صاحبهما' },
  { number: 18, name: 'الكَهْف', englishName: 'Al-Kahf', englishNameTranslation: 'The Cave', numberOfAyahs: 110, revelationType: 'Meccan', virtueAr: 'نور ما بين الجمعتين وعصمة من فتنة المسيح الدجال' },
  { number: 36, name: 'يس', englishName: 'Yaseen', englishNameTranslation: 'Yasin', numberOfAyahs: 83, revelationType: 'Meccan', virtueAr: 'قلب القرآن وموقظة للقلوب' },
  { number: 55, name: 'الرَّحْمَٰن', englishName: 'Ar-Rahmaan', englishNameTranslation: 'The Beneficent', numberOfAyahs: 78, revelationType: 'Medinan', virtueAr: 'عروس القرآن وبيان آلاء الله ونعمه العظيمة' },
  { number: 56, name: 'الوَاقِعَة', englishName: 'Al-Waaqia', englishNameTranslation: 'The Inevitable', numberOfAyahs: 96, revelationType: 'Meccan', virtueAr: 'سورة الغنى وأحوال الناس يوم القيامة' },
  { number: 67, name: 'المُلْك', englishName: 'Al-Mulk', englishNameTranslation: 'The Dominion', numberOfAyahs: 30, revelationType: 'Meccan', virtueAr: 'المانعة والمنجية من عذاب القبر تشفع لصاحبها' },
  { number: 93, name: 'الضُّحَىٰ', englishName: 'Ad-Dhuhaa', englishNameTranslation: 'The Morning Hours', numberOfAyahs: 11, revelationType: 'Meccan', virtueAr: 'تسلية وتثبيت لفؤاد النبي ﷺ وبشارة بالرضا' },
  { number: 94, name: 'الشَّرْح', englishName: 'Ash-Sharh', englishNameTranslation: 'The Relief', numberOfAyahs: 8, revelationType: 'Meccan', virtueAr: 'بشارة اليسر بعد العسر وانشراح الصدر' },
  { number: 112, name: 'الإِخْلَاص', englishName: 'Al-Ikhlaas', englishNameTranslation: 'Sincerity', numberOfAyahs: 4, revelationType: 'Meccan', virtueAr: 'تعدل ثلث القرآن في الأجر والفضل' },
  { number: 113, name: 'الفَلَق', englishName: 'Al-Falaq', englishNameTranslation: 'The Daybreak', numberOfAyahs: 5, revelationType: 'Meccan', virtueAr: 'أعظم ما تعوّذ به المتعوذون من شرور الخلق والحسد' },
  { number: 114, name: 'النَّاس', englishName: 'An-Naas', englishNameTranslation: 'Mankind', numberOfAyahs: 6, revelationType: 'Meccan', virtueAr: 'الحصن الحصين من وسوسة الشيطان والجن والإنس' }
];

export const DETAILED_SURAHS: Record<number, DetailedSurah> = {
  1: {
    number: 1,
    name: 'الفَاتِحَة',
    englishName: 'Al-Faatiha',
    englishNameTranslation: 'The Opening',
    numberOfAyahs: 7,
    revelationType: 'Meccan',
    bismillahPre: false,
    virtueAr: 'أعظم سورة في كتاب الله، لا تصح الصلاة إلا بها، وتسمى الشافية والوافية والكافية.',
    themeAr: 'إخلاص العبودية والحمد لله تعالى وسؤال الهداية إلى الصراط المستقيم.',
    asbabGeneral: 'نزلت بمكة في أوائل ما نزل من القرآن لافتتاح الصلاة بها وتعليم المؤمنين أدب مناجاة الرب.',
    ayahs: [
      {
        number: 1,
        ayahNumberInSurah: 1,
        text: 'بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ',
        audioUrl: 'https://everyayah.com/data/Alafasy_128kbps/001001.mp3',
        tafseer: 'أبتدئ قراءتي مستعيناً باسم الله، والله هو المألوه المعبود بحق، والرحمن الرحيم اسمان مشتقان من الرحمة، الرحمن عام لجميع الخلق، والرحيم خاص بالمؤمنين.',
        vocabulary: [
          { word: 'بِسْمِ اللَّهِ', meaning: 'أبتدئ مستعيناً ومتبركاً باسم الله الأجل' },
          { word: 'الرَّحْمَٰنِ', meaning: 'ذو الرحمة الشاملة لجميع الخلائق في الدنيا' },
          { word: 'الرَّحِيمِ', meaning: 'المفيض رحمته الخاصة بأوليائه المؤمنين في الآخرة' }
        ]
      },
      {
        number: 2,
        ayahNumberInSurah: 2,
        text: 'الْحَمْدُ لِلَّهِ رَبِّ الْعَالَمِينَ',
        audioUrl: 'https://everyayah.com/data/Alafasy_128kbps/001002.mp3',
        tafseer: 'الثناء الكامل المطلق لله وحده بكمال صفاته وجزيل نعمائه، وهو سبحانه مربّي جميع المخلوقات وخالقها ومدبّر أمورها.',
        vocabulary: [
          { word: 'الْحَمْدُ', meaning: 'الثناء باللسان على المحمود بصفات كماله الذاتية والإنعام' },
          { word: 'رَبِّ', meaning: 'المالك المتصرف الخالق المربي لعباده بالنعم' },
          { word: 'الْعَالَمِينَ', meaning: 'جمع عالَم، وهم كل ما سوى الله من الإنس والجن والملائكة والخلائق' }
        ]
      },
      {
        number: 3,
        ayahNumberInSurah: 3,
        text: 'الرَّحْمَٰنِ الرَّحِيمِ',
        audioUrl: 'https://everyayah.com/data/Alafasy_128kbps/001003.mp3',
        tafseer: 'تأكيد لصفة الرحمة الواسعة الإلهية بعد ذكر الربوبية التي قد يقرنها البعض بالهيبة والقهر، فربوبيته سبحانه مبنية على الرحمة واللطف.',
        vocabulary: [
          { word: 'الرَّحْمَٰنِ الرَّحِيمِ', meaning: 'العاطف بلطفه، الواسع في إحسانه' }
        ]
      },
      {
        number: 4,
        ayahNumberInSurah: 4,
        text: 'مَالِكِ يَوْمِ الدِّينِ',
        audioUrl: 'https://everyayah.com/data/Alafasy_128kbps/001004.mp3',
        tafseer: 'المتصرف وحده بلا منازع في يوم الحساب والجزاء وهو يوم القيامة، حيث تتلاشى كل دعاوى الملك الدنيوي.',
        vocabulary: [
          { word: 'مَالِكِ', meaning: 'المتصرف بالأمر والنهي والقضاء المطلق' },
          { word: 'يَوْمِ الدِّينِ', meaning: 'يوم الجزاء والحساب على الأعمال' }
        ]
      },
      {
        number: 5,
        ayahNumberInSurah: 5,
        text: 'إِيَّاكَ نَعْبُدُ وَإِيَّاكَ نَسْتَعِينُ',
        audioUrl: 'https://everyayah.com/data/Alafasy_128kbps/001005.mp3',
        tafseer: 'نخصك وحدك بالعبادة والتذلل، ونخصك وحدك بطلب العون في كل شؤون ديننا ودنيانا، فلا نعبد غيرك ولا نستعين بسواك.',
        vocabulary: [
          { word: 'إِيَّاكَ', meaning: 'ضمير نصب منفصل يفيد الحصر والاختصاص (أي لا نعبد إلا أنت)' },
          { word: 'نَعْبُدُ', meaning: 'نخضع لك بغاية الذل والمحبة والطاعة' },
          { word: 'نَسْتَعِينُ', meaning: 'نطلب المعونة والتوفيق والمدد منك وحدك' }
        ]
      },
      {
        number: 6,
        ayahNumberInSurah: 6,
        text: 'اهْدِنَا الصِّرَاطَ الْمُسْتَقِيمَ',
        audioUrl: 'https://everyayah.com/data/Alafasy_128kbps/001006.mp3',
        tafseer: 'دُلَّنا وأرشدنا ووفّقنا وثبتنا على الطريق الواضح القويم الموصل لرضوانك وجنتك، وهو الإسلام وسنة نبيك.',
        vocabulary: [
          { word: 'اهْدِنَا', meaning: 'أرشدنا وثبتنا وزدنا بصيرة وتوفيقاً' },
          { word: 'الصِّرَاطَ', meaning: 'الطريق والمنهج الواضح' },
          { word: 'الْمُسْتَقِيمَ', meaning: 'الذي لا اعوجاج فيه ولا انحراف، وهو دين الإسلام' }
        ]
      },
      {
        number: 7,
        ayahNumberInSurah: 7,
        text: 'صِرَاطَ الَّذِينَ أَنْعَمْتَ عَلَيْهِمْ غَيْرِ الْمَغْضُوبِ عَلَيْهِمْ وَلَا الضَّالِّينَ',
        audioUrl: 'https://everyayah.com/data/Alafasy_128kbps/001007.mp3',
        tafseer: 'طريق النبيين والصدّيقين والشهداء والصالحين، لا طريق الذين عرفوا الحق وتركوه فعوقبوا بالغضب كاليهود، ولا طريق الذين عبدوا الله بجهل وضلال كالنصارى.',
        vocabulary: [
          { word: 'أَنْعَمْتَ عَلَيْهِمْ', meaning: 'بالهداية والتوفيق وهم النبيون والصديقون والشهداء' },
          { word: 'الْمَغْضُوبِ عَلَيْهِمْ', meaning: 'الذين علموا الحق وتنكّبوه عمداً' },
          { word: 'الضَّالِّينَ', meaning: 'الذين ضلوا عن الحق بجهلهم واتباع أهوائهم' }
        ]
      }
    ]
  },
  67: {
    number: 67,
    name: 'المُلْك',
    englishName: 'Al-Mulk',
    englishNameTranslation: 'The Dominion',
    numberOfAyahs: 5,
    revelationType: 'Meccan',
    bismillahPre: true,
    virtueAr: 'سورة تبارك هي المانعة من عذاب القبر تشفع لصاحبها حتى يغفر له (رواه الترمذي وحسنه).',
    themeAr: 'إثبات عظمة ملك الله وبديع صنعه في الكون وابتلاء الإنسان بالحياة والموت.',
    asbabGeneral: 'نزلت في كفار مكة الذين كانوا يتآمرون سراً على النبي ﷺ فأخبرهم الله بأنه يعلم السر وأخفى.',
    ayahs: [
      {
        number: 1,
        ayahNumberInSurah: 1,
        text: 'تَبَارَكَ الَّذِي بِيَدِهِ الْمُلْكُ وَهُوَ عَلَىٰ كُلِّ شَيْءٍ قَدِيرٌ',
        audioUrl: 'https://everyayah.com/data/Alafasy_128kbps/067001.mp3',
        tafseer: 'تعاظم وكثُر خير الله وبركته، الذي بيده مقاليد الملك والسلطان في الدنيا والآخرة، وله القدرة المطلقة.',
        vocabulary: [
          { word: 'تَبَارَكَ', meaning: 'تعالى وتعاظم وثبتت بركاته وخيراته' },
          { word: 'بِيَدِهِ الْمُلْكُ', meaning: 'له التصرف التام في سائر الموجودات بلا شريك' }
        ]
      },
      {
        number: 2,
        ayahNumberInSurah: 2,
        text: 'الَّذِي خَلَقَ الْمَوْتَ وَالْحَيَاةَ لِيَبْلُوَكُمْ أَيُّكُمْ أَحْسَنُ عَمَلًا ۚ وَهُوَ الْعَزِيزُ الْغَفُورُ',
        audioUrl: 'https://everyayah.com/data/Alafasy_128kbps/067002.mp3',
        tafseer: 'خلق الحياة الدنيوية والموت ليمتحنكم ويختبركم: أيكم أخلص لله عملاً وأصوبه على هدي رسوله.',
        vocabulary: [
          { word: 'لِيَبْلُوَكُمْ', meaning: 'ليختبركم ويمتحن صدق إيمانكم' },
          { word: 'أَحْسَنُ عَمَلًا', meaning: 'أخلصه لله وأصوبه باتباع النبي ﷺ' },
          { word: 'الْعَزِيزُ الْغَفُورُ', meaning: 'القاهر الذي لا يُغلب، الساتر لذنوب التائبين' }
        ]
      },
      {
        number: 3,
        ayahNumberInSurah: 3,
        text: 'الَّذِي خَلَقَ سَبْعَ سَمَاوَاتٍ طِبَاقًا ۖ مَّا تَرَىٰ فِي خَلْقِ الرَّحْمَٰنِ مِن تَفَاوُتٍ ۖ فَارْجِعِ الْبَصَرَ هَلْ تَرَىٰ مِن فُطُورٍ',
        audioUrl: 'https://everyayah.com/data/Alafasy_128kbps/067003.mp3',
        tafseer: 'خلق سبع سموات طبقة فوق طبقة بإحكام متقن، ما ترى في خلق الله من خلل أو اضطراب، فكرر النظر هل تجد شقوقاً أو تصدعاً؟',
        vocabulary: [
          { word: 'طِبَاقًا', meaning: 'طبقة فوق طبقة متناسقة' },
          { word: 'تَفَاوُتٍ', meaning: 'اختلال أو نقص أو عدم تناسق' },
          { word: 'فُطُورٍ', meaning: 'شقوق أو صدوع أو عيوب' }
        ]
      },
      {
        number: 4,
        ayahNumberInSurah: 4,
        text: 'ثُمَّ ارْجِعِ الْبَصَرَ كَرَّتَيْنِ يَنقَلِبْ إِلَيْكَ الْبَصَرُ خَاسِئًا وَهُوَ حَسِيرٌ',
        audioUrl: 'https://everyayah.com/data/Alafasy_128kbps/067004.mp3',
        tafseer: 'أعد النظر مرة بعد مرة باحثاً عن عيب، يرجع إليك بصرك خائباً داحراً كليلاً مجهداً دون أن يجد نقصاً واحداً.',
        vocabulary: [
          { word: 'كَرَّتَيْنِ', meaning: 'كرّة بعد كرّة مراراً وتكراراً' },
          { word: 'خَاسِئًا', meaning: 'ذليلاً صاغراً خائباً عن إدراك خلل' },
          { word: 'حَسِيرٌ', meaning: 'مُنقطع كليل تعِب من طول البحث' }
        ]
      },
      {
        number: 5,
        ayahNumberInSurah: 5,
        text: 'وَلَقَدْ زَيَّنَّا السَّمَاءَ الدُّنْيَا بِمَصَابِيحَ وَجَعَلْنَاهَا رُجُومًا لِّلشَّيَاطِينِ ۖ وَأَعْتَدْنَا لَهُمْ عَذَابَ السَّعِيرِ',
        audioUrl: 'https://everyayah.com/data/Alafasy_128kbps/067005.mp3',
        tafseer: 'زيّن الله السماء القريبة بنجوم مضيئة زينة للناظرين، وجعل الشهب المنقضة منها رجمياً للشياطين مسترقي السمع.',
        vocabulary: [
          { word: 'بِمَصَابِيحَ', meaning: 'النجوم والكواكب المضيئة اللامعة' },
          { word: 'رُجُومًا', meaning: 'شُهُباً ترجم الشياطين التي تسترق السمع' },
          { word: 'السَّعِيرِ', meaning: 'النار الموقدة المتأججة' }
        ]
      }
    ]
  },
  112: {
    number: 112,
    name: 'الإِخْلَاص',
    englishName: 'Al-Ikhlaas',
    englishNameTranslation: 'Sincerity',
    numberOfAyahs: 4,
    revelationType: 'Meccan',
    bismillahPre: true,
    virtueAr: 'تعدل ثلث القرآن، وحبها يوجب محبة الله ودخول الجنة.',
    themeAr: 'صفة الرحمن الخالصة ونفي الشريك والولد والند عن ذاته العلية.',
    asbabGeneral: 'سأل المشركون النبي ﷺ: انسُب لنا ربك أمن ذهب هو أم من فضة؟ فأنزل الله هذه السورة الحاسمة.',
    ayahs: [
      {
        number: 1,
        ayahNumberInSurah: 1,
        text: 'قُلْ هُوَ اللَّهُ أَحَدٌ',
        audioUrl: 'https://everyayah.com/data/Alafasy_128kbps/112001.mp3',
        tafseer: 'قل أيها الرسول لمن سألك عن ربك: هو الله المتفرد بالألوهية والربوبية والأسماء والصفات، لا شريك له.',
        vocabulary: [
          { word: 'أَحَدٌ', meaning: 'الواحد المنفرد الذي لا نظير له ولا مثيل ولا شريك' }
        ]
      },
      {
        number: 2,
        ayahNumberInSurah: 2,
        text: 'اللَّهُ الصَّمَدُ',
        audioUrl: 'https://everyayah.com/data/Alafasy_128kbps/112002.mp3',
        tafseer: 'السيد العظيم الكامل في سؤدده الذي تصمد وتلجأ إليه جميع الخلائق في قضاء حوائجها ورغائبها.',
        vocabulary: [
          { word: 'الصَّمَدُ', meaning: 'السيد المطاع المقصود في الحوائج، الذي لا جوف له ولا يطعم ولا يشرب' }
        ]
      },
      {
        number: 3,
        ayahNumberInSurah: 3,
        text: 'لَمْ يَلِدْ وَلَمْ يُولَدْ',
        audioUrl: 'https://everyayah.com/data/Alafasy_128kbps/112003.mp3',
        tafseer: 'تنزه عن اتخاذ الولد فليس له ابن ولا بنت، وتنزه عن الولادة فليس له أب ولا أم، بل هو الأول والآخر.',
        vocabulary: [
          { word: 'لَمْ يَلِدْ', meaning: 'نفي الولد تنزيهاً لعظمته عن مشابهة المخلوقين' },
          { word: 'لَمْ يُولَدْ', meaning: 'نفي الحدوث والافتقار إلى موجد، فهو سبحانه أزلي أبدي' }
        ]
      },
      {
        number: 4,
        ayahNumberInSurah: 4,
        text: 'وَلَمْ يَكُن لَّهُ كُفُوًا أَحَدٌ',
        audioUrl: 'https://everyayah.com/data/Alafasy_128kbps/112004.mp3',
        tafseer: 'ليس له مماثل ولا مكافئ ولا نظير في ذاته ولا في أسمائه ولا في صفاته وأفعاله سبحانه.',
        vocabulary: [
          { word: 'كُفُوًا', meaning: 'مكافئاً أو مماثلاً أو شبيهاً' }
        ]
      }
    ]
  },
  113: {
    number: 113,
    name: 'الفَلَق',
    englishName: 'Al-Falaq',
    englishNameTranslation: 'The Daybreak',
    numberOfAyahs: 5,
    revelationType: 'Meccan',
    bismillahPre: true,
    virtueAr: 'المعوذتان لم يتعوّذ بمثلهما قط للتحصين من الحسد والسحر والشرور.',
    themeAr: 'الاستعاذة برب الصبح المنير من شرور المخلوقات والظلمات والسواحر والحاسدين.',
    asbabGeneral: 'نزلت حين سُحر النبي صلى الله عليه وسلم من لبيد بن الأعصم اليهودي، فكان يرقى بهما حتى شُفي.',
    ayahs: [
      {
        number: 1,
        ayahNumberInSurah: 1,
        text: 'قُلْ أَعُوذُ بِرَبِّ الْفَلَقِ',
        audioUrl: 'https://everyayah.com/data/Alafasy_128kbps/113001.mp3',
        tafseer: 'قل أعتصم وألتجئ برب الصبح الذي ينفلق عنه ظلام الليل، وخالق كل ما ينفلق من حب ونوى.',
        vocabulary: [
          { word: 'أَعُوذُ', meaning: 'ألتجئ وأعتصم وأتحصن' },
          { word: 'الْفَلَقِ', meaning: 'الصبح إذا انفلق ضوؤه، وقيل: كل ما يفلقه الله من النبات والحب' }
        ]
      },
      {
        number: 2,
        ayahNumberInSurah: 2,
        text: 'مِن شَرِّ مَا خَلَقَ',
        audioUrl: 'https://everyayah.com/data/Alafasy_128kbps/113002.mp3',
        tafseer: 'من شر جميع المخلوقات التي فيها شر من إنس وجن ودواب وهوام وظواهر.',
        vocabulary: [
          { word: 'مَا خَلَقَ', meaning: 'جميع المخلوقات التي قد يصدر منها أذى وشر' }
        ]
      },
      {
        number: 3,
        ayahNumberInSurah: 3,
        text: 'وَمِن شَرِّ غَاسِقٍ إِذَا وَقَبَ',
        audioUrl: 'https://everyayah.com/data/Alafasy_128kbps/113003.mp3',
        tafseer: 'ومن شر الليل إذا أقبل واشتدت ظلمته وغمر الأرض، حيث تنتشر فيه الشياطين وأهل السوء.',
        vocabulary: [
          { word: 'غَاسِقٍ', meaning: 'الليل شديد الظلمة' },
          { word: 'وَقَبَ', meaning: 'دخل واشتدت عتمته وظلامه وتغلغل' }
        ]
      },
      {
        number: 4,
        ayahNumberInSurah: 4,
        text: 'وَمِن شَرِّ النَّفَّاثَاتِ فِي الْعُقَدِ',
        audioUrl: 'https://everyayah.com/data/Alafasy_128kbps/113004.mp3',
        tafseer: 'ومن شر السواحر اللاتي يعقدن الخيوط وينفخن فيها بريقهن الشرير إضراراً بالناس.',
        vocabulary: [
          { word: 'النَّفَّاثَاتِ', meaning: 'النساء السواحر اللاتي ينفثن (النفخ مع ريق خفيف)' },
          { word: 'الْعُقَدِ', meaning: 'عُقد الخيوط والحبال التي يعقدها الساحر لأعمال السحر' }
        ]
      },
      {
        number: 5,
        ayahNumberInSurah: 5,
        text: 'وَمِن شَرِّ حَاسِدٍ إِذَا حَسَدَ',
        audioUrl: 'https://everyayah.com/data/Alafasy_128kbps/113005.mp3',
        tafseer: 'ومن شر الإنسان الذي يتمنى زوال نعمة الله عن غيره ويطلق عينه ونفسه الخبيثة بالأذى.',
        vocabulary: [
          { word: 'حَاسِدٍ', meaning: 'المتمني زوال نعمة غيره إليه أو إلى العدم' },
          { word: 'إِذَا حَسَدَ', meaning: 'إذا أظهر ما في قلبه من الشر وسعى بالأذى والعين' }
        ]
      }
    ]
  },
  114: {
    number: 114,
    name: 'النَّاس',
    englishName: 'An-Naas',
    englishNameTranslation: 'Mankind',
    numberOfAyahs: 6,
    revelationType: 'Meccan',
    bismillahPre: true,
    virtueAr: 'التحصين الأعظم من وسوسة الصدور وكيد إبليس وأعوانه من شياطين الإنس والجن.',
    themeAr: 'الاعتصام بربوبية الله وملكه وألوهيته من شر الوسواس الخناس.',
    ayahs: [
      {
        number: 1,
        ayahNumberInSurah: 1,
        text: 'قُلْ أَعُوذُ بِرَبِّ النَّاسِ',
        audioUrl: 'https://everyayah.com/data/Alafasy_128kbps/114001.mp3',
        tafseer: 'قل ألتجئ وأتحصن برب البشر وخالقهم ومدبر أمورهم.',
        vocabulary: [{ word: 'بِرَبِّ النَّاسِ', meaning: 'خالقهم ومربيهم بالنعم ومدبر شؤونهم' }]
      },
      {
        number: 2,
        ayahNumberInSurah: 2,
        text: 'مَلِكِ النَّاسِ',
        audioUrl: 'https://everyayah.com/data/Alafasy_128kbps/114002.mp3',
        tafseer: 'سلطانهم الحق المتصرف فيهم بما يشاء، لا ملك حقيقي سواه.',
        vocabulary: [{ word: 'مَلِكِ النَّاسِ', meaning: 'الحاكم المتصرف بأمره النافذ فيهم' }]
      },
      {
        number: 3,
        ayahNumberInSurah: 3,
        text: 'إِلَٰهِ النَّاسِ',
        audioUrl: 'https://everyayah.com/data/Alafasy_128kbps/114003.mp3',
        tafseer: 'معبودهم الحق الذي لا تنبغي العبادة والألوهية إلا له وحده.',
        vocabulary: [{ word: 'إِلَٰهِ النَّاسِ', meaning: 'معبودهم الحق الذي تألهه القلوب بالمحبة والتعظيم' }]
      },
      {
        number: 4,
        ayahNumberInSurah: 4,
        text: 'مِن شَرِّ الْوَسْوَاسِ الْخَنَّاسِ',
        audioUrl: 'https://everyayah.com/data/Alafasy_128kbps/114004.mp3',
        tafseer: 'من شر الشيطان الذي يوسوس عند الغفلة، ويخنس ويختفي ويهرب عند ذكر الله.',
        vocabulary: [
          { word: 'الْوَسْوَاسِ', meaning: 'الشيطان الذي يلقي الخواطر الرديئة في القلب' },
          { word: 'الْخَنَّاسِ', meaning: 'المتأخر الهارب المختفي إذا ذُكر الله تعالى' }
        ]
      },
      {
        number: 5,
        ayahNumberInSurah: 5,
        text: 'الَّذِي يُوَسْوِسُ فِي صُدُورِ النَّاسِ',
        audioUrl: 'https://everyayah.com/data/Alafasy_128kbps/114005.mp3',
        tafseer: 'الذي يبث الشر والشكوك والأوهام والمعاصي في قلوب البشر وصدورهم.',
        vocabulary: [{ word: 'يُوَسْوِسُ', meaning: 'يلقي الكلام الخفي المشوب بالفتنة في النفس' }]
      },
      {
        number: 6,
        ayahNumberInSurah: 6,
        text: 'مِنَ الْجِنَّةِ وَالنَّاسِ',
        audioUrl: 'https://everyayah.com/data/Alafasy_128kbps/114006.mp3',
        tafseer: 'هذا الوسواس يكون من شياطين الجن، ويكون أيضاً من شياطين الإنس الذين يزينون الباطل.',
        vocabulary: [
          { word: 'الْجِنَّةِ', meaning: 'عالم الجن والشياطين الخفية' },
          { word: 'وَالنَّاسِ', meaning: 'شياطين الإنس وجلساء السوء والمضلين' }
        ]
      }
    ]
  }
};
