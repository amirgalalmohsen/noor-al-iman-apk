import { CommunityChallenge, ForumPost } from '../utils/community';

export const INITIAL_COMMUNITY_CHALLENGES: CommunityChallenge[] = [
  {
    id: 'ch-1',
    titleAr: 'تحدي المليون صلاة على الحبيب المصطفى ﷺ',
    descriptionAr: 'تحدٍ جماعي يشارك فيه أهل المنصة لجمع مليون صلاة وسلام على رسول الله ﷺ في ليلة ويوم الجمعة المبارك.',
    targetCount: 1000000,
    currentCount: 842600,
    totalParticipants: 3418,
    daysRemaining: 2,
    category: 'azkar',
    rewardLeaves: 50,
    joined: true,
    userProgress: 450
  },
  {
    id: 'ch-2',
    titleAr: 'ختمة سورة الكهف والتدبر الأسبوعي',
    descriptionAr: 'قراءة سورة الكهف وتدبر قصصها الأربع (أصحاب الكهف، صاحب الجنتين، موسى والخضر، ذو القرنين).',
    targetCount: 5000,
    currentCount: 4210,
    totalParticipants: 4210,
    daysRemaining: 3,
    category: 'quran',
    rewardLeaves: 40,
    joined: false,
    userProgress: 0
  },
  {
    id: 'ch-3',
    titleAr: 'أسبوع المحافظة على الصف الأول في الفجر',
    descriptionAr: 'تحدي أداء صلاة الفجر في جماعة بالمسجد / في أول وقتها سبعة أيام متتالية استجلاباً للنور التام.',
    targetCount: 7,
    currentCount: 5,
    totalParticipants: 1890,
    daysRemaining: 2,
    category: 'salah',
    rewardLeaves: 60,
    joined: true,
    userProgress: 5
  },
  {
    id: 'ch-4',
    titleAr: 'غراس الجنة: 10,000 تسبيحة واستغفار',
    descriptionAr: 'تحدي الإكثار من الباقيات الصالحات والاستغفار طوال الأسبوع لغرس بساتين النخيل في الفردوس الأعلى.',
    targetCount: 10000,
    currentCount: 7920,
    totalParticipants: 2650,
    daysRemaining: 4,
    category: 'azkar',
    rewardLeaves: 70,
    joined: false,
    userProgress: 0
  }
];

export interface CommunityTreeProfile {
  id: string;
  userName: string;
  levelTitle: string;
  stage: number;
  totalHasanat: number;
  leavesCount: number;
  duaPointsReceived: number;
  isPublic: boolean;
  avatarChar: string;
  badge: string;
  recentDeed: string;
}

export const COMMUNITY_PROFILES: CommunityTreeProfile[] = [
  {
    id: 'usr-1',
    userName: 'أمير جلال (المؤسس)',
    levelTitle: 'سدرة المنتهى وشجرة الفردوس الذهبية',
    stage: 5,
    totalHasanat: 3450,
    leavesCount: 160,
    duaPointsReceived: 184,
    isPublic: true,
    avatarChar: 'أ',
    badge: '👑 المؤسس',
    recentDeed: 'أكمل ورد أذكار الصباح وختمة جزء عم'
  },
  {
    id: 'usr-2',
    userName: 'عبد الرحمن الشامي',
    levelTitle: 'حديقة الذاكرين العظيمة',
    stage: 4,
    totalHasanat: 1240,
    leavesCount: 95,
    duaPointsReceived: 92,
    isPublic: true,
    avatarChar: 'ع',
    badge: '🌟 حامل المسك',
    recentDeed: 'أهدى 300 تسبيحة في تحدي الجمعة'
  },
  {
    id: 'usr-3',
    userName: 'مريم الأندلسية',
    levelTitle: 'دوحة الحسنات المتلألئة',
    stage: 3,
    totalHasanat: 680,
    leavesCount: 58,
    duaPointsReceived: 64,
    isPublic: true,
    avatarChar: 'م',
    badge: '✨ صاحبة الدوحة',
    recentDeed: 'أتمت صيام الإثنين والخميس'
  },
  {
    id: 'usr-4',
    userName: 'خالد بن الوليد المصري',
    levelTitle: 'شجرة النور الرطبة بالذكر',
    stage: 2,
    totalHasanat: 280,
    leavesCount: 28,
    duaPointsReceived: 35,
    isPublic: true,
    avatarChar: 'خ',
    badge: '🌿 الذاكر الرطب',
    recentDeed: 'حافظ على صلاة الفجر في جماعة 5 أيام'
  }
];

export const INITIAL_FORUM_POSTS: ForumPost[] = [
  {
    id: 'post-1',
    authorName: 'أمير جلال',
    authorTreeLevel: 5,
    category: 'tadabbur',
    categoryAr: 'تدبر آية',
    titleAr: 'تأمُّل في قوله تعالى: {فَاذْكُرُونِي أَذْكُرْكُمْ}',
    contentAr: 'ما أعظم هذا الوعد الإلهي الكريم! مخلوق ضعيف في أطراف هذا الكون الفسيح يذكر الله بلسانه وقلبه، فيذكره خالق السماوات والأرض في الملأ الأعلى بين الملائكة الكرام. اجعلوا ألسنتكم دائماً رطبة بذكره تروا عجائب التوفيق والسكينة في بيوتكم وقلوبكم.',
    upvotes: 48,
    userUpvoted: true,
    repliesCount: 3,
    timestamp: 'منذ ساعتين',
    replies: [
      {
        id: 'rep-1',
        authorName: 'أحمد الصالح',
        contentAr: 'جزاك الله خيراً يا أخي أمير، فعلاً الذكر هو الروح التي تحيا بها القلوب الميتة.',
        timestamp: 'منذ ساعة'
      },
      {
        id: 'rep-2',
        authorName: 'فاطمة الزهراء',
        contentAr: 'اللهم أعنا على ذكرك وشكرك وحسن عبادتك، كلمات تلمس الوجدان.',
        timestamp: 'منذ 40 دقيقة'
      }
    ]
  },
  {
    id: 'post-2',
    authorName: 'سعيد المغربي',
    authorTreeLevel: 3,
    category: 'hifz',
    categoryAr: 'تجارب حفظ القرآن',
    titleAr: 'طريقتي المجربة في تثبيت سورة البقرة دون نسيان',
    contentAr: 'السلام عليكم ورحمة الله، كنت أعاني من تشابه الآيات في سورة البقرة، فبدأت بربط كل ربع بموضوعه الأساسي، وقراءة الربع المحفوظ في السنن الرواتب وقيام الليل. هل لديكم نصائح إضافية لتثبيت الأرباع الأخيرة؟',
    upvotes: 32,
    userUpvoted: false,
    repliesCount: 2,
    timestamp: 'منذ 5 ساعات',
    replies: [
      {
        id: 'rep-3',
        authorName: 'ياسين الجزائري',
        contentAr: 'وعليكم السلام، الاستماع المستمر إلى الشيخ الحصري بالقراءة التحقيقية يساعد جداً على طبع نبرة الآيات في الذاكرة.',
        timestamp: 'منذ 3 ساعات'
      }
    ]
  },
  {
    id: 'post-3',
    authorName: 'نور الهدى',
    authorTreeLevel: 4,
    category: 'q_and_a',
    categoryAr: 'سؤال وجواب وتواصٍ',
    titleAr: 'أدعية نبوية مأثورة عند هجوم القلق وتشتت الذهن؟',
    contentAr: 'إخواني وأخواتي، في ظل ضغوط العمل والدراسة، ما هي الأذكار التي تجدون فيها راحة فورية وسكينة للقلب؟ أرجو مشاركة تجاربكم.',
    upvotes: 27,
    userUpvoted: false,
    repliesCount: 1,
    timestamp: 'منذ 8 ساعات',
    replies: [
      {
        id: 'rep-4',
        authorName: 'عبد الرحمن',
        contentAr: '«يَا حَيُّ يَا قَيُّومُ بِرَحْمَتِكَ أَسْتَغِيثُ أَصْلِحْ لِي شَأْنِي كُلَّهُ» مع الاستغفار 100 مرة، سحر عجيب في انشراح الصدر.',
        timestamp: 'منذ 6 ساعات'
      }
    ]
  }
];
