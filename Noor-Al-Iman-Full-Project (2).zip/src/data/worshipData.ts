export interface WorshipCheckItem {
  id: string;
  titleAr: string;
  category: 'fard' | 'sunnah' | 'quran' | 'dhikr';
  period: 'daily' | 'weekly' | 'monthly';
  rewardLeaves: number;
  descriptionAr: string;
}

export const DAILY_WORSHIP_ITEMS: WorshipCheckItem[] = [
  { id: 'fajr', titleAr: 'صلاة الفجر (في وقتها / جماعة)', category: 'fard', period: 'daily', rewardLeaves: 15, descriptionAr: 'ركعتا الفجر خير من الدنيا وما فيها، ومن صلى الصبح فهو في ذمة الله.' },
  { id: 'fajr_sunnah', titleAr: 'سنة الفجر القبلية (ركعتان)', category: 'sunnah', period: 'daily', rewardLeaves: 10, descriptionAr: 'كان النبي ﷺ أشد تعاهداً لها من سائر النوافل.' },
  { id: 'dhuhr', titleAr: 'صلاة الظهر', category: 'fard', period: 'daily', rewardLeaves: 10, descriptionAr: 'أول صلاة صلاها جبريل عليه السلام بالنبي ﷺ.' },
  { id: 'dhuhr_sunnah', titleAr: 'رواتب الظهر (4 قبلها و 2 بعدها)', category: 'sunnah', period: 'daily', rewardLeaves: 10, descriptionAr: 'من حافظ على أربع قبل الظهر وأربع بعدها حَرَّمه الله على النار.' },
  { id: 'asr', titleAr: 'صلاة العصر (الصلاة الوسطى)', category: 'fard', period: 'daily', rewardLeaves: 15, descriptionAr: 'من صلى البردين (الصبح والعصر) دخل الجنة.' },
  { id: 'maghrib', titleAr: 'صلاة المغرب', category: 'fard', period: 'daily', rewardLeaves: 10, descriptionAr: 'وتر النهار وتُعجل عند غروب الشمس.' },
  { id: 'maghrib_sunnah', titleAr: 'سنة المغرب البعدية (ركعتان)', category: 'sunnah', period: 'daily', rewardLeaves: 8, descriptionAr: 'من السنن الرواتب المؤكدة.' },
  { id: 'isha', titleAr: 'صلاة العشاء', category: 'fard', period: 'daily', rewardLeaves: 10, descriptionAr: 'من صلى العشاء في جماعة فكأنما قام نصف الليل.' },
  { id: 'isha_sunnah', titleAr: 'سنة العشاء والوتر', category: 'sunnah', period: 'daily', rewardLeaves: 12, descriptionAr: 'إن الله وتر يحب الوتر، فأوتروا يا أهل القرآن.' },
  { id: 'duha', titleAr: 'صلاة الضحى (صلاة الأوابين)', category: 'sunnah', period: 'daily', rewardLeaves: 12, descriptionAr: 'تجزئ عن 360 صدقة عن كل مَفْصل وسلامى في جسدك.' },
  { id: 'qiyam', titleAr: 'قيام الليل والتهجد', category: 'sunnah', period: 'daily', rewardLeaves: 25, descriptionAr: 'شرف المؤمن قيامه بالليل، ودأب الصالحين قبله.' },
  { id: 'quran_wird', titleAr: 'الورد القرآني اليومي (جزء أو حزب)', category: 'quran', period: 'daily', rewardLeaves: 20, descriptionAr: 'القرآن يشفع لصاحبه يوم القيامة، بكل حرف عشر حسنات.' },
  { id: 'morning_evening_azkar', titleAr: 'أذكار الصباح والمساء كاملة', category: 'dhikr', period: 'daily', rewardLeaves: 15, descriptionAr: 'الحصن الحصين من الشياطين والشرور طوال اليوم والليلة.' }
];

export const WEEKLY_WORSHIP_ITEMS: WorshipCheckItem[] = [
  { id: 'kahf_friday', titleAr: 'قراءة سورة الكهف يوم الجمعة', category: 'quran', period: 'weekly', rewardLeaves: 30, descriptionAr: 'أضاء له من النور ما بين الجمعتين وعصمه من الدجال.' },
  { id: 'fasting_mon_thu', titleAr: 'صيام الإثنين أو الخميس', category: 'sunnah', period: 'weekly', rewardLeaves: 35, descriptionAr: 'تُعرض الأعمال على الله يومي الإثنين والخميس وأحب أن يعرض عملي وأنا صائم.' },
  { id: 'friday_prayer', titleAr: 'التبكير لصلاة الجمعة والغسل', category: 'fard', period: 'weekly', rewardLeaves: 25, descriptionAr: 'من اغتسل يوم الجمعة وغسّل وبكّر وابتكر كان له بكل خطوة أجر سنة صيامها وقيامها.' },
  { id: 'salawat_friday', titleAr: 'الإكثار من الصلاة على النبي ﷺ ليلة ويوم الجمعة', category: 'dhikr', period: 'weekly', rewardLeaves: 25, descriptionAr: 'أكثروا عليّ من الصلاة فيه فإن صلاتكم معروضة عليّ.' },
  { id: 'silat_rahim', titleAr: 'صلة الأرحام وبر الوالدين', category: 'sunnah', period: 'weekly', rewardLeaves: 30, descriptionAr: 'من أحب أن يُبسط له في رزقه ويُنسأ له في أثره فليصل رحمه.' }
];

export const MONTHLY_WORSHIP_ITEMS: WorshipCheckItem[] = [
  { id: 'fasting_ayam_beed', titleAr: 'صيام الأيام البيض (13 و 14 و 15 من الشهر الهجري)', category: 'sunnah', period: 'monthly', rewardLeaves: 50, descriptionAr: 'صيام ثلاثة أيام من كل شهر صيام الدهر كله.' },
  { id: 'sadaqah_monthly', titleAr: 'صدقة شهرية وإعانة محتاج', category: 'sunnah', period: 'monthly', rewardLeaves: 40, descriptionAr: 'ما نقص مال من صدقة، والصدقة تطفئ غضب الرب وتدفع ميتة السوء.' },
  { id: 'khatma_monthly', titleAr: 'ختم القرآن الكريم كاملاً', category: 'quran', period: 'monthly', rewardLeaves: 100, descriptionAr: 'ختم القرآن يصحبه دعوة مستجابة وتتنزل عنده الرحمة والسكينة.' }
];

export interface StepGuide {
  stepNumber: number;
  titleAr: string;
  descriptionAr: string;
  duaAr?: string;
  sunnahNotesAr: string;
  mistakeAvoidAr?: string;
}

export const WUDHU_STEPS: StepGuide[] = [
  {
    stepNumber: 1,
    titleAr: 'النية والتسمية',
    descriptionAr: 'ينوي الطهارة بقلبه دون التلفظ باللسان، ثم يقول: «بِسْمِ اللَّهِ».',
    duaAr: 'بِسْمِ اللَّهِ',
    sunnahNotesAr: 'النية محلها القلب وجوباً، والتسمية سنة مؤكدة عند الجمهور.',
    mistakeAvoidAr: 'التلفظ بالنية جهراً كقول: نويت أن أتوضأ، فإنها بدعة لم ترد.'
  },
  {
    stepNumber: 2,
    titleAr: 'غسل الكفين ثلاثاً',
    descriptionAr: 'غسل اليدين من أطراف الأصابع إلى المعصمين (الرسغين) ثلاث مرات مع تخليل الأصابع.',
    sunnahNotesAr: 'البدء باليد اليمنى قبل اليسرى وتخليل أصابع اليدين.',
    mistakeAvoidAr: 'إهمال تخليل ما بين الأصابع أو غسل ظهر الكف دون بطنه.'
  },
  {
    stepNumber: 3,
    titleAr: 'المضمضة والاستنشاق ثلاثاً',
    descriptionAr: 'يأخذ غرفة من ماء بيمينه يضع نصفها في فمه للمضمضة ونصفها الآخر في أنفه للاستنشاق ثم يستنثر بشماله.',
    sunnahNotesAr: 'المبالغة في المضمضة والاستنشاق لغير الصائم.',
    mistakeAvoidAr: 'الفصل بين المضمضة والاستنشاق بغرفات كثيرة تخالف هدي النبي ﷺ.'
  },
  {
    stepNumber: 4,
    titleAr: 'غسل الوجه كاملاً ثلاثاً',
    descriptionAr: 'غسل الوجه من منابت شعر الرأس المعتاد إلى أسفل الذقن طولاً، ومن شحمة الأذن إلى شحمة الأذن الأخرى عرضاً.',
    sunnahNotesAr: 'تخليل اللحية الكثة بماء بكفه.',
    mistakeAvoidAr: 'ترك جوانب الوجه وبياض ما بين الأذن والعارضين دون غسل.'
  },
  {
    stepNumber: 5,
    titleAr: 'غسل اليدين إلى المرفقين ثلاثاً',
    descriptionAr: 'غسل اليدين بدءاً من رؤوس الأصابع حتى استيعاب المرفقين تماماً، يبدأ باليمنى ثم اليسرى.',
    sunnahNotesAr: 'إدخال المرفقين في الغسل مع الإسباغ.',
    mistakeAvoidAr: 'خطأ شائع جداً: غسل الذراع فقط والاعتماد على غسل الكفين في أول الوضوء!'
  },
  {
    stepNumber: 6,
    titleAr: 'مسح الرأس والأذنين مرة واحدة',
    descriptionAr: 'يمسح رأسه ببلل ماء جديد، يبدأ بمقدم رأسه حتى يقفوهما ثم يردهما إلى المكان الذي بدأ منه، ثم يدخل سبابتيه في صماخ أذنيه ويمسح بإبهاميه ظاهر أذنيه.',
    sunnahNotesAr: 'مسح الرأس والأذنين يكون مرة واحدة فقط بماء واحد.',
    mistakeAvoidAr: 'أخذ ماء جديد مستقل للأذنين أو مسح الرقبة حيث لم يثبت ذلك في السنة.'
  },
  {
    stepNumber: 7,
    titleAr: 'غسل الرجلين مع الكعبين ثلاثاً',
    descriptionAr: 'غسل القدم اليمنى ثم اليسرى إلى الكعبين (العظمان الناتئان أسفل الساق) مع تخليل الأصابع بالخنصر.',
    sunnahNotesAr: 'تخليل أصابع الرجلين بيده اليسرى وتعميم العقبين بالماء.',
    mistakeAvoidAr: 'ويل للأعقاب من النار: ترك أسفل العقب أو جوانب القدم دون وصول الماء.'
  },
  {
    stepNumber: 8,
    titleAr: 'الذكر المستحب بعد الوضوء',
    descriptionAr: 'يقول بعد الفراغ من الوضوء متوجهاً إلى القبلة الدعاء النبوي الشريف لتفتح له أبواب الجنة الثمانية.',
    duaAr: 'أَشْهَدُ أَنْ لاَ إِلَـهَ إِلاَّ اللهُ وَحْدَهُ لاَ شَرِيكَ لَهُ، وَأَشْهَدُ أَنَّ مُحَمَّداً عَبْدُهُ وَرَسُولُهُ، اللَّهُمَّ اجْعَلْنِي مِنَ التَّوَّابِينَ وَاجْعَلْنِي مِنَ الْمُتَطَهِّرِينَ.',
    sunnahNotesAr: 'فُتحت له أبواب الجنة الثمانية يدخل من أيها شاء (صحيح مسلم).'
  }
];

export const SALAH_STEPS: StepGuide[] = [
  {
    stepNumber: 1,
    titleAr: 'استقبال القبلة وتكبيرة الإحرام',
    descriptionAr: 'يقف معتدلاً مستقبلاً القبلة بنيته، ويرفع يديه حذو منكبيه أو فروع أذنيه قائلاً: «اللَّهُ أَكْبَرُ».',
    duaAr: 'اللَّهُ أَكْبَرُ',
    sunnahNotesAr: 'رفع اليدين مبسوطتي الأصابع مضمومة مستقبلاً بها القبلة.',
    mistakeAvoidAr: 'التلفظ بالنية أو نطق التكبيرة بمد همزة لفظ الجلالة (آلله أكبر) مما يفسد المعنى.'
  },
  {
    stepNumber: 2,
    titleAr: 'دعاء الاستفتاح وقراءة الفاتحة وسورة',
    descriptionAr: 'يضع كفه اليمنى على ظهر كفه اليسرى والرسغ والساعد على صدره، ويستفتح ثم يستعيذ ويبسمل سراً ويقرأ الفاتحة ثم ما تيسر من القرآن.',
    duaAr: 'سُبْحَانَكَ اللَّهُمَّ وَبِحَمْدِكَ، وَتَبَارَكَ اسْمُكَ، وَتَعَالَى جَدُّكَ، وَلاَ إِلَـهَ غَيْرُكَ.',
    sunnahNotesAr: 'النظر إلى موضع السجود طوال الصلاة واستشعار مناجاة الله.',
    mistakeAvoidAr: 'عدم قراءة الفاتحة للمنفرد والإمام؛ فقراءتها ركن لا تصح الصلاة إلا بها.'
  },
  {
    stepNumber: 3,
    titleAr: 'الركوع والاطمئنان فيه',
    descriptionAr: 'يكبر رافعاً يديه ثم يركع مائلاً ظهره مستوياً، ويمكن يديه من ركبتيه مفرجتي الأصابع كأنه قابض عليهما، ويسبح.',
    duaAr: 'سُبْحَانَ رَبِّيَ الْعَظِيمِ (3 مرات)',
    sunnahNotesAr: 'استواء الظهر حتى لو صُب عليه ماء لاستقر، ورأسه بحيال ظهره.',
    mistakeAvoidAr: 'نقرة الغراب: عدم الطمأنينة وعدم تسوية الظهر في الركوع.'
  },
  {
    stepNumber: 4,
    titleAr: 'الرفع من الركوع والاعتدال التام',
    descriptionAr: 'يرفع رأسه وظهره من الركوع قائلاً: «سَمِعَ اللَّهُ لِمَنْ حَمِدَهُ»، فإذا استتم قائماً معتدلاً قال التحميد.',
    duaAr: 'رَبَّنَا وَلَكَ الْحَمْدُ حَمْداً كَثِيراً طَيِّباً مُبَارَكاً فِيهِ، مِلْءَ السَّمَاوَاتِ وَمِلْءَ الأَرْضِ وَمِلْءَ مَا بَيْنَهُمَا وَمِلْءَ مَا شِئْتَ مِنْ شَيْءٍ بَعْدُ.',
    sunnahNotesAr: 'الاطمئنان في القيام بعد الركوع حتى يرجع كل فِقار إلى مكانه.',
    mistakeAvoidAr: 'الهويّ إلى السجود مباشرة قبل استتمام القيام والاعتدال.'
  },
  {
    stepNumber: 5,
    titleAr: 'السجود الأول على الأعضاء السبعة',
    descriptionAr: 'يهوي ساجداً مكبراً دون رفع اليدين، ويسجد على سبعة أعضاء: الجبهة مع الأنف، والكفين، والركبتين، وأطراف القدمين.',
    duaAr: 'سُبْحَانَ رَبِّيَ الأَعْلَى (3 مرات) + الدُّعَاء بما تيسر',
    sunnahNotesAr: 'أقرب ما يكون العبد من ربه وهو ساجد فأكثروا من الدعاء، وتفريج العضدين عن الجنبين.',
    mistakeAvoidAr: 'رفع أحد القدمين عن الأرض أثناء السجود، أو بسط الذراعين كبساط الكلب.'
  },
  {
    stepNumber: 6,
    titleAr: 'الجلوس بين السجدتين',
    descriptionAr: 'يرفع رأسه مكبراً ويجلس مفترشاً رجله اليسرى وناصباً رجله اليمنى واضعاً يديه على فخذيه مطمئناً.',
    duaAr: 'رَبِّ اغْفِرْ لِي، رَبِّ اغْفِرْ لِي، وَارْحَمْنِي وَاهْدِنِي وَاجْبُرْنِي وَعَافِنِي وَارْزُقْنِي.',
    sunnahNotesAr: 'الاطمئنان والسكينة بين السجدتين حتى يعود كل عظم لموضعه.',
    mistakeAvoidAr: 'الاستعجال بالسجدة الثانية دون استقرار الجلوس.'
  },
  {
    stepNumber: 7,
    titleAr: 'السجدة الثانية والنهوض للركعة التالية',
    descriptionAr: 'يسجد السجدة الثانية كالأولى تماماً مكبراً ومطمئناً، ثم ينهض للركعة التالية معتمداً على ركبتيه أو يديه.',
    duaAr: 'سُبْحَانَ رَبِّيَ الأَعْلَى (3 مرات)',
    sunnahNotesAr: 'جلسة الاستراحة الخفيفة قبل النهوض.',
    mistakeAvoidAr: 'عدم مساواة السجدة الثانية بالأولى في الذكر والخشوع.'
  },
  {
    stepNumber: 8,
    titleAr: 'التشهد الأخير والصلاة الإبراهيمية والسلام',
    descriptionAr: 'يجلس في الركعة الأخيرة متوركاً ويقرأ التشهد كاملاً مع الإشارة بالسبابة، ثم يصلي على النبي ﷺ ويتعوذ من أربع ثم يسلم عن يمينه وشماله.',
    duaAr: 'التَّحِيَّاتُ لِلَّهِ وَالصَّلَوَاتُ وَالطَّيِّبَاتُ، السَّلاَمُ عَلَيْكَ أَيُّهَا النَّبِيُّ وَرَحْمَةُ اللَّهِ وَبَرَكَاتُهُ، السَّلاَمُ عَلَيْنَا وَعَلَى عِبَادِ اللَّهِ الصَّالِحِينَ، أَشْهَدُ أَنْ لاَ إِلَـهَ إِلاَّ اللهُ وَأَشْهَدُ أَنَّ مُحَمَّداً عَبْدُهُ وَرَسُولُهُ. اللَّهُمَّ صَلِّ عَلَى مُحَمَّدٍ...',
    sunnahNotesAr: 'الاستعاذة قبل السلام من عذاب القبر وعذاب جهنم وفتنة المحيا والممات وفتنة المسيح الدجال.',
    mistakeAvoidAr: 'ترك التسليمتين أو عدم الالتفات بالوجه عند السلام.'
  }
];
