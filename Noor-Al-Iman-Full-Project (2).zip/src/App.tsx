import React, { useState, useEffect } from 'react';
import {
  Sparkles,
  BookOpen,
  Compass,
  Heart,
  Users,
  CheckSquare,
  Trophy,
  Bot,
  Bell,
  HeartHandshake,
  Facebook,
  Instagram,
  Smartphone,
  Download,
  Info,
} from 'lucide-react';
import { Header, NavTab } from './components/Header';
import { GoldenTreeCanvas } from './components/GoldenTreeCanvas';
import { AzkarSection } from './components/AzkarSection';
import { QuranSection } from './components/QuranSection';
import { TasbihSection } from './components/TasbihSection';
import { QiblaSection } from './components/QiblaSection';
import { WorshipGuideSection } from './components/WorshipGuideSection';
import { VirtuesSection } from './components/VirtuesSection';
import { QuizSection } from './components/QuizSection';
import { CommunitySection } from './components/CommunitySection';
import { AboutSection } from './components/AboutSection';
import { FollowAmirGalalSection } from './components/FollowAmirGalalSection';
import { FacebookIcon, InstagramIcon, XIcon, ThreadsIcon } from './components/SocialIcons';
import { GeminiReflectionsModal } from './components/GeminiReflectionsModal';
import { ApkDownloadModal } from './components/ApkDownloadModal';

export default function App() {
  const [activeTab, setActiveTab] = useState<NavTab>('tree');
  const [totalHasanat, setTotalHasanat] = useState<number>(() => {
    const saved = localStorage.getItem('ag_islamic_hasanat');
    return saved ? parseInt(saved, 10) : 320; // Seeded initial golden tree state
  });

  const [soundEnabled, setSoundEnabled] = useState<boolean>(true);
  const [salawatReminderActive, setSalawatReminderActive] = useState<boolean>(true);
  const [salawatIntervalMins, setSalawatIntervalMins] = useState<number>(15);
  const [isAiModalOpen, setIsAiModalOpen] = useState<boolean>(false);
  const [isApkModalOpen, setIsApkModalOpen] = useState<boolean>(false);
  const [globalToast, setGlobalToast] = useState<string | null>(null);

  // Persistence
  useEffect(() => {
    localStorage.setItem('ag_islamic_hasanat', totalHasanat.toString());
  }, [totalHasanat]);

  const addHasanat = (amount: number, reason: string) => {
    setTotalHasanat((prev) => prev + amount);
    setGlobalToast(`+${amount} ورقة ذهبية: ${reason}`);
    setTimeout(() => setGlobalToast(null), 3000);
  };

  // Smart Salawat Periodic Reminder
  useEffect(() => {
    if (!salawatReminderActive) return;

    const intervalMs = salawatIntervalMins * 60 * 1000;
    const timer = setInterval(() => {
      // Trigger pleasant reminder
      setGlobalToast('اللَّهُمَّ صَلِّ وَسَلِّمْ وَبَارِكْ عَلَى سَيِّدِنَا مُحَمَّدٍ ﷺ');
      if (soundEnabled) {
        try {
          const audioCtx = new (window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext)();
          const osc = audioCtx.createOscillator();
          const gain = audioCtx.createGain();
          osc.type = 'sine';
          osc.frequency.setValueAtTime(523.25, audioCtx.currentTime); // C5
          osc.frequency.exponentialRampToValueAtTime(659.25, audioCtx.currentTime + 0.3); // E5
          gain.gain.setValueAtTime(0.15, audioCtx.currentTime);
          gain.gain.exponentialRampToValueAtTime(0.001, audioCtx.currentTime + 0.6);
          osc.connect(gain);
          gain.connect(audioCtx.destination);
          osc.start();
          osc.stop(audioCtx.currentTime + 0.65);
        } catch {
          // Fallback
        }
      }
      setTimeout(() => setGlobalToast(null), 5000);
    }, intervalMs);

    return () => clearInterval(timer);
  }, [salawatReminderActive, salawatIntervalMins, soundEnabled]);

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col selection:bg-amber-500/30 selection:text-amber-200 pb-20 lg:pb-6">
      {/* Global Toast Alert */}
      {globalToast && (
        <div className="fixed top-18 left-1/2 -translate-x-1/2 z-50 px-5 py-3 rounded-2xl bg-gradient-to-r from-amber-500 to-amber-600 text-slate-950 font-bold text-xs sm:text-sm shadow-2xl flex items-center gap-2.5 animate-bounce">
          <Sparkles className="w-4 h-4 text-slate-950 shrink-0" />
          <span>{globalToast}</span>
        </div>
      )}

      {/* Top Header */}
      <Header
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        totalLeaves={totalHasanat}
        salawatReminderActive={salawatReminderActive}
        toggleSalawatReminder={() => setSalawatReminderActive(!salawatReminderActive)}
        soundEnabled={soundEnabled}
        toggleSound={() => setSoundEnabled(!soundEnabled)}
        onOpenApkModal={() => setIsApkModalOpen(true)}
      />

      {/* Creator Showcase Banner with Logo, Photo, Bold 'تصميم أمير جلال', and Social Links */}
      <div className="max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 pt-5">
        <div className="relative overflow-hidden p-5 sm:p-6 rounded-3xl bg-gradient-to-br from-slate-900/95 via-slate-950 to-amber-950/30 border-2 border-amber-500/30 shadow-2xl shadow-amber-500/10 flex flex-col md:flex-row items-center justify-between gap-5">
          <div className="absolute top-0 right-0 w-64 h-64 bg-amber-500/5 rounded-full blur-3xl pointer-events-none" />
          <div className="absolute bottom-0 left-0 w-64 h-64 bg-emerald-500/5 rounded-full blur-3xl pointer-events-none" />

          {/* Logo & Photo & 'تصميم أمير جلال' */}
          <div className="flex flex-col sm:flex-row items-center gap-4 text-center sm:text-right w-full md:w-auto relative z-10">
            {/* Logo and Photo Stack */}
            <div className="flex flex-col items-center gap-2 shrink-0">
              {/* Logo AG & Nour Al-Iman Emblem */}
              <div className="flex items-center gap-2 px-3 py-1 rounded-xl bg-amber-500/15 border border-amber-500/40 text-amber-300 text-xs font-bold font-quran shadow-xs">
                <Sparkles className="w-3.5 h-3.5 text-amber-400" />
                <span>لوجو التطبيق · AG</span>
              </div>

              {/* Amir Galal Photo under the Logo */}
              <div className="relative group">
                <div className="w-20 h-20 sm:w-24 sm:h-24 rounded-2xl bg-gradient-to-br from-amber-300 via-yellow-400 to-amber-600 p-1 shadow-xl shadow-amber-500/25 group-hover:scale-105 transition-transform duration-300 flex items-center justify-center">
                  <img
                    src="/amir-galal.svg"
                    alt="صورة المصمم أمير جلال"
                    className="w-full h-full rounded-[14px] object-cover"
                    onError={(e) => {
                      e.currentTarget.src = '/icon-192.png';
                    }}
                  />
                </div>
                <div className="absolute -bottom-1 -left-1 px-2 py-0.5 rounded-full bg-emerald-500 text-slate-950 font-bold text-[10px] shadow-sm">
                  مُصمم التطبيق
                </div>
              </div>
            </div>

            {/* Typography: Brand and Bold 'تصميم أمير جلال' */}
            <div className="flex flex-col items-center sm:items-start space-y-1">
              <span className="text-xs text-amber-400/90 font-semibold tracking-wide font-quran">
                تطبيق نُورُ الإِيمَان الإِسْلَامِيّ الشَّامِل
              </span>
              
              <h2 className="text-xl sm:text-3xl font-extrabold text-transparent bg-clip-text bg-gradient-to-r from-amber-300 via-yellow-100 to-amber-400 font-quran tracking-wider drop-shadow-md">
                تصميم أمير جلال
              </h2>

              <p className="text-xs text-slate-300 max-w-md font-quran leading-relaxed">
                القرآن الكريم، الأذكار الجامعة، شجرة الحسنات الذهبية، بوصلة القبلة، والتحديات الإيمانية.
              </p>
            </div>
          </div>

          {/* Action & Social Links for Amir Galal */}
          <div className="flex flex-wrap items-center justify-center sm:justify-start gap-2 w-full md:w-auto relative z-10">
            <button
              onClick={() => setIsApkModalOpen(true)}
              className="px-3.5 py-2.5 rounded-2xl bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-slate-950 font-extrabold text-xs sm:text-sm flex items-center justify-center gap-1.5 transition-all active:scale-95 shadow-lg shadow-amber-500/20"
              title="تنزيل التطبيق APK أو تثبيته على الهاتف"
            >
              <Smartphone className="w-4 h-4 shrink-0 text-slate-950" />
              <span>تنزيل APK</span>
            </button>

            <button
              onClick={() => setActiveTab('about')}
              className={`px-3 py-2.5 rounded-2xl border text-xs font-bold flex items-center justify-center gap-1.5 transition-all active:scale-95 shadow-md ${
                activeTab === 'about'
                  ? 'bg-amber-500/20 text-amber-300 border-amber-500/50'
                  : 'bg-slate-900/80 hover:bg-slate-800 text-slate-200 border-slate-700/60'
              }`}
              title="عن التطبيق والمطور"
            >
              <Info className="w-3.5 h-3.5 text-amber-400 shrink-0" />
              <span>عن التطبيق</span>
            </button>

            <a
              href="https://www.facebook.com/MR.AmirGalal"
              target="_blank"
              rel="noopener noreferrer"
              className="px-3 py-2.5 rounded-2xl bg-blue-600/25 hover:bg-blue-600/40 text-blue-200 border border-blue-500/50 text-xs font-bold flex items-center justify-center gap-1.5 transition-all active:scale-95 shadow-md shadow-blue-500/10"
              title="فيسبوك: MR.AmirGalal"
            >
              <FacebookIcon className="w-3.5 h-3.5 text-blue-400 shrink-0" />
              <span className="hidden xl:inline">MR.AmirGalal</span>
              <span className="xl:hidden">Facebook</span>
            </a>

            <a
              href="https://www.instagram.com/amir____galal/"
              target="_blank"
              rel="noopener noreferrer"
              className="px-3 py-2.5 rounded-2xl bg-gradient-to-r from-pink-500/25 to-purple-500/25 hover:from-pink-500/40 hover:to-purple-500/40 text-pink-200 border border-pink-500/50 text-xs font-bold flex items-center justify-center gap-1.5 transition-all active:scale-95 shadow-md shadow-pink-500/10"
              title="إنستغرام: amir____galal"
            >
              <InstagramIcon className="w-3.5 h-3.5 text-pink-400 shrink-0" />
              <span className="hidden xl:inline">amir____galal</span>
              <span className="xl:hidden">Instagram</span>
            </a>

            <a
              href="https://x.com/amir____galal"
              target="_blank"
              rel="noopener noreferrer"
              className="px-2.5 py-2.5 rounded-2xl bg-slate-800/60 hover:bg-slate-800 text-slate-200 border border-slate-700/60 text-xs font-bold flex items-center justify-center gap-1 transition-all active:scale-95 shadow-md"
              title="إكس (تويتر): amir____galal"
            >
              <XIcon className="w-3.5 h-3.5 text-slate-100 shrink-0" />
              <span>X</span>
            </a>

            <a
              href="https://www.threads.net/@amir____galal"
              target="_blank"
              rel="noopener noreferrer"
              className="px-2.5 py-2.5 rounded-2xl bg-zinc-800/60 hover:bg-zinc-800 text-zinc-200 border border-zinc-700/60 text-xs font-bold flex items-center justify-center gap-1 transition-all active:scale-95 shadow-md"
              title="ثريدز: @amir____galal"
            >
              <ThreadsIcon className="w-3.5 h-3.5 text-zinc-100 shrink-0" />
              <span>Threads</span>
            </a>
          </div>
        </div>
      </div>

      {/* Main Container */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-5 sm:py-6">
        {activeTab === 'tree' && (
          <div className="space-y-8">
            <GoldenTreeCanvas
              totalHasanat={totalHasanat}
              onAddHasanat={addHasanat}
              onShareToCommunity={() => setActiveTab('community')}
            />
            {/* Professional 'تابع أمير جلال' Section in Home */}
            <FollowAmirGalalSection variant="full" />
          </div>
        )}

        {activeTab === 'azkar' && (
          <AzkarSection onAddHasanat={addHasanat} soundEnabled={soundEnabled} />
        )}

        {activeTab === 'quran' && <QuranSection onAddHasanat={addHasanat} />}

        {activeTab === 'tasbih' && (
          <TasbihSection onAddHasanat={addHasanat} soundEnabled={soundEnabled} />
        )}

        {activeTab === 'qibla' && <QiblaSection />}

        {activeTab === 'worship' && <WorshipGuideSection onAddHasanat={addHasanat} />}

        {activeTab === 'community' && (
          <CommunitySection totalHasanat={totalHasanat} onAddHasanat={addHasanat} />
        )}

        {activeTab === 'virtues' && (
          <VirtuesSection
            salawatReminderActive={salawatReminderActive}
            toggleSalawatReminder={() => setSalawatReminderActive(!salawatReminderActive)}
            salawatIntervalMins={salawatIntervalMins}
            setSalawatIntervalMins={setSalawatIntervalMins}
            onAddHasanat={addHasanat}
          />
        )}

        {activeTab === 'quiz' && <QuizSection onAddHasanat={addHasanat} />}

        {activeTab === 'about' && (
          <AboutSection
            onNavigateTab={(tab) => setActiveTab(tab)}
            onOpenApkModal={() => setIsApkModalOpen(true)}
          />
        )}
      </main>

      {/* Floating AI Reflections Assistant Trigger */}
      <button
        onClick={() => setIsAiModalOpen(true)}
        className="fixed bottom-20 lg:bottom-8 left-6 z-40 p-3.5 sm:px-4 sm:py-3 rounded-2xl bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-slate-950 font-bold text-xs sm:text-sm shadow-xl shadow-amber-500/20 active:scale-95 transition-all flex items-center gap-2"
        title="تأملات واستفسارات قرآنية ذكية"
      >
        <Sparkles className="w-4 h-4 text-slate-950" />
        <span className="hidden sm:inline">تأملات قرآنية ذكية</span>
      </button>

      {/* AI Reflections Modal */}
      <GeminiReflectionsModal
        isOpen={isAiModalOpen}
        onClose={() => setIsAiModalOpen(false)}
      />

      {/* APK Download & Installation Modal */}
      <ApkDownloadModal
        isOpen={isApkModalOpen}
        onClose={() => setIsApkModalOpen(false)}
      />

      {/* Mobile Sticky Bottom Tab Bar (Thumb ergonomic zone) */}
      <nav className="lg:hidden fixed bottom-0 left-0 right-0 z-40 bg-slate-950/95 backdrop-blur-md border-t border-slate-900 grid grid-cols-5 items-center h-16 px-1">
        {[
          { id: 'tree' as NavTab, label: 'الشجرة', icon: Sparkles },
          { id: 'azkar' as NavTab, label: 'الأذكار', icon: BookOpen },
          { id: 'quran' as NavTab, label: 'القرآن', icon: Heart },
          { id: 'tasbih' as NavTab, label: 'المسبحة', icon: HeartHandshake },
          { id: 'community' as NavTab, label: 'المجتمع', icon: Users },
        ].map((tab) => {
          const Icon = tab.icon;
          const isActive = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`flex flex-col items-center justify-center h-full min-h-[44px] transition-colors ${
                isActive ? 'text-amber-300 font-bold' : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <Icon className={`w-5 h-5 ${isActive ? 'text-amber-400 scale-110' : ''}`} />
              <span className="text-[10px] mt-1">{tab.label}</span>
            </button>
          );
        })}
      </nav>

      {/* Footer */}
      <footer className="border-t border-slate-900/80 mt-12 py-8 text-center text-xs text-slate-400">
        <div className="max-w-7xl mx-auto px-4 flex flex-col md:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-full bg-gradient-to-br from-amber-300 to-amber-600 p-0.5 shadow-md shrink-0">
              <img
                src="/amir-galal.svg"
                alt="صورة المصمم أمير جلال"
                className="w-full h-full rounded-full object-cover"
                onError={(e) => {
                  e.currentTarget.src = '/icon-192.png';
                }}
              />
            </div>
            <div className="text-right">
              <span className="font-bold text-amber-300 font-quran text-base">نُورُ الإِيمَان</span>
              <span className="text-slate-500 mx-2">·</span>
              <span className="font-extrabold text-transparent bg-clip-text bg-gradient-to-r from-amber-300 to-yellow-300 font-quran text-sm">
                تصميم أمير جلال
              </span>
            </div>
          </div>

          <div className="flex flex-wrap items-center justify-center gap-3">
            <a
              href="https://www.facebook.com/MR.AmirGalal"
              target="_blank"
              rel="noopener noreferrer"
              className="text-slate-400 hover:text-blue-400 transition-colors flex items-center gap-1.5 text-xs font-semibold"
              title="فيسبوك: MR.AmirGalal"
            >
              <FacebookIcon className="w-4 h-4 text-blue-400" />
              <span>Facebook</span>
            </a>
            <span className="text-slate-700">|</span>
            <a
              href="https://www.instagram.com/amir____galal/"
              target="_blank"
              rel="noopener noreferrer"
              className="text-slate-400 hover:text-pink-400 transition-colors flex items-center gap-1.5 text-xs font-semibold"
              title="إنستغرام: amir____galal"
            >
              <InstagramIcon className="w-4 h-4 text-pink-400" />
              <span>Instagram</span>
            </a>
            <span className="text-slate-700">|</span>
            <a
              href="https://x.com/amir____galal"
              target="_blank"
              rel="noopener noreferrer"
              className="text-slate-400 hover:text-amber-300 transition-colors flex items-center gap-1.5 text-xs font-semibold"
              title="إكس (تويتر): amir____galal"
            >
              <XIcon className="w-4 h-4 text-slate-200" />
              <span>X</span>
            </a>
            <span className="text-slate-700">|</span>
            <a
              href="https://www.threads.net/@amir____galal"
              target="_blank"
              rel="noopener noreferrer"
              className="text-slate-400 hover:text-amber-300 transition-colors flex items-center gap-1.5 text-xs font-semibold"
              title="ثريدز: @amir____galal"
            >
              <ThreadsIcon className="w-4 h-4 text-zinc-200" />
              <span>Threads</span>
            </a>
          </div>

          <div className="font-quran text-slate-400 text-xs">
            «اللَّهُمَّ اجْعَلْ عَمَلَنَا كُلَّهُ صَالِحاً، وَاجْعَلْهُ لِوَجْهِكَ خَالِصاً»
          </div>

          <div className="text-[11px] text-slate-500">
            جميع الحقوق محفوظة © {new Date().getFullYear()} · أمير جلال
          </div>
        </div>
      </footer>
    </div>
  );
}
