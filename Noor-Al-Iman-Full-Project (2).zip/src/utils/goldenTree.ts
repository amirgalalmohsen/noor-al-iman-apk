/**
 * Golden Tree of Deeds (شجرة الحسنات الذهبية) Progression System
 */

export interface GoldenTreeLevel {
  stage: number;
  minPoints: number;
  maxPoints: number;
  titleAr: string;
  subTitleAr: string;
  goldenLeavesCount: number;
  goldenBranches: number;
  hadithAr: string;
  badge: string;
}

export const TREE_STAGES: GoldenTreeLevel[] = [
  {
    stage: 1,
    minPoints: 0,
    maxPoints: 99,
    titleAr: 'غرس البداية والنية الصالحة',
    subTitleAr: 'بذرة الذكر الأولى في روضة الجنة',
    goldenLeavesCount: 12,
    goldenBranches: 3,
    hadithAr: 'مَن قالَ: سُبْحانَ اللَّهِ وبِحَمْدِهِ، غُرِسَتْ له نَخْلَةٌ في الجَنَّةِ.',
    badge: '🌱 غارس البداية'
  },
  {
    stage: 2,
    minPoints: 100,
    maxPoints: 299,
    titleAr: 'شجرة النور الرطبة بالذكر',
    subTitleAr: 'فروعها تمتد وتكتسي بأوراق الذهب الخالص',
    goldenLeavesCount: 30,
    goldenBranches: 5,
    hadithAr: 'لا يَزَالُ لِسَانُكَ رَطْبًا مِنْ ذِكْرِ اللَّهِ تَعَالَى.',
    badge: '🌿 الذاكر الرطب'
  },
  {
    stage: 3,
    minPoints: 300,
    maxPoints: 699,
    titleAr: 'دوحة الحسنات المتلألئة',
    subTitleAr: 'أوراق من ذهب وياقوت تتفتح مع كل تسبيحة وصلوات',
    goldenLeavesCount: 60,
    goldenBranches: 8,
    hadithAr: 'أَحَبُّ الكَلَامِ إلى اللهِ أَرْبَعٌ: سُبْحَانَ اللهِ، وَالْحَمْدُ لِلَّهِ، وَلَا إِلَهَ إِلَّا اللَّهُ، وَاللَّهُ أَكْبَرُ.',
    badge: '✨ صاحب الدوحة'
  },
  {
    stage: 4,
    minPoints: 700,
    maxPoints: 1499,
    titleAr: 'حديقة الذاكرين العظيمة',
    subTitleAr: 'فروع ذهبية عملاقة تظلها الملائكة وتتفيأ ظلالها',
    goldenLeavesCount: 100,
    goldenBranches: 12,
    hadithAr: 'مَثَلُ الَّذِي يَذْكُرُ رَبَّهُ وَالَّذِي لا يَذْكُرُ رَبَّهُ مَثَلُ الحَيِّ وَالمَيِّتِ.',
    badge: '🌟 حامل المسك'
  },
  {
    stage: 5,
    minPoints: 1500,
    maxPoints: 99999,
    titleAr: 'سدرة المنتهى وشجرة الفردوس الذهبية',
    subTitleAr: 'أعلى مقامات الذاكرين الله كثيراً والذاكرات',
    goldenLeavesCount: 160,
    goldenBranches: 16,
    hadithAr: 'سَبَقَ المُفَرِّدُونَ، قالوا: ومَنِ المُفَرِّدُونَ يا رَسولَ اللهِ؟ قالَ: الذَّاكِرُونَ اللَّهَ كَثِيرًا وَالذَّاكِرَاتُ.',
    badge: '👑 السابقون المقربون'
  }
];

export interface TreeProgress {
  currentPoints: number;
  currentLevel: GoldenTreeLevel;
  nextLevel: GoldenTreeLevel | null;
  progressPercent: number;
  pointsToNextLevel: number;
  activeLeaves: number;
  goldLusterIndex: number; // 0 to 1
}

export function calculateTreeProgress(totalHasanat: number): TreeProgress {
  const points = Math.max(0, Math.floor(totalHasanat));
  
  let currentLevel = TREE_STAGES[0];
  let nextLevel: GoldenTreeLevel | null = TREE_STAGES[1];

  for (let i = 0; i < TREE_STAGES.length; i++) {
    const level = TREE_STAGES[i];
    if (points >= level.minPoints) {
      currentLevel = level;
      nextLevel = i < TREE_STAGES.length - 1 ? TREE_STAGES[i + 1] : null;
    }
  }

  let progressPercent = 100;
  let pointsToNextLevel = 0;

  if (nextLevel) {
    const range = nextLevel.minPoints - currentLevel.minPoints;
    const currentInRange = points - currentLevel.minPoints;
    progressPercent = Math.min(100, Math.max(0, Math.round((currentInRange / range) * 100)));
    pointsToNextLevel = nextLevel.minPoints - points;
  }

  // Active leaves scale with points
  const activeLeaves = Math.min(
    currentLevel.goldenLeavesCount,
    Math.max(5, Math.floor(currentLevel.goldenLeavesCount * (0.4 + (progressPercent / 100) * 0.6)))
  );

  const goldLusterIndex = Math.min(1, 0.4 + (progressPercent / 100) * 0.6);

  return {
    currentPoints: points,
    currentLevel,
    nextLevel,
    progressPercent,
    pointsToNextLevel,
    activeLeaves,
    goldLusterIndex
  };
}
