/**
 * Tasbih and Digital Masbaha Logic
 */

export interface DhikrPreset {
  id: string;
  arabic: string;
  transliteration?: string;
  translationAr: string;
  virtueAr: string;
  defaultTarget: number;
}

export const DHIKR_PRESETS: DhikrPreset[] = [
  {
    id: 'subhanallah',
    arabic: 'سُبْحَانَ اللَّهِ',
    translationAr: 'تنزيه لله تعالى عن كل نقص وعيب',
    virtueAr: 'تغرس شجرة في الجنة وتُحط الخطايا',
    defaultTarget: 33
  },
  {
    id: 'alhamdulillah',
    arabic: 'الْحَمْدُ لِلَّهِ',
    translationAr: 'الثناء الكامل على الله بصفات كماله ونعمه',
    virtueAr: 'تملأ ميزان الحسنات يوم القيامة',
    defaultTarget: 33
  },
  {
    id: 'allahuakbar',
    arabic: 'اللَّهُ أَكْبَرُ',
    translationAr: 'الله أعظم وأجل من كل شيء في الوجود',
    virtueAr: 'من أحب الكلام إلى الله تعالى',
    defaultTarget: 33
  },
  {
    id: 'la_ilaha_illallah',
    arabic: 'لَا إِلَهَ إِلَّا اللَّهُ وَحْدَهُ لَا شَرِيكَ لَهُ',
    translationAr: 'توحيد الله الخالص وإفراده بالعبادة',
    virtueAr: 'خير ما قلت أنا والنبيون من قبلي، وأفضل الذكر',
    defaultTarget: 100
  },
  {
    id: 'astaghfirullah',
    arabic: 'أَسْتَغْفِرُ اللَّهَ الْعَظِيمَ وَأَتُوبُ إِلَيْهِ',
    translationAr: 'طلب المغفرة والصفح من رب العزة',
    virtueAr: 'تفريج الهموم وجلب الرزق ونزول البركات',
    defaultTarget: 100
  },
  {
    id: 'salawat',
    arabic: 'اللَّهُمَّ صَلِّ وَسَلِّمْ عَلَى نَبِيِّنَا مُحَمَّدٍ',
    translationAr: 'الصلاة والتسليم على خاتم المرسلين ﷺ',
    virtueAr: 'من صلى عليّ صلاة صلى الله عليه بها عشراً',
    defaultTarget: 100
  },
  {
    id: 'hawqala',
    arabic: 'لَا حَوْلَ وَلَا قُوَّةَ إِلَّا بِاللَّهِ الْعَلِيِّ الْعَظِيمِ',
    translationAr: 'التبرؤ من الحول والقوة إلا بحول الله',
    virtueAr: 'كنز من كنوز الجنة ودواء لتسعة وتسعين داء',
    defaultTarget: 33
  },
  {
    id: 'subhanallah_bihamdihi',
    arabic: 'سُبْحَانَ اللَّهِ وَبِحَمْدِهِ ، سُبْحَانَ اللَّهِ الْعَظِيمِ',
    translationAr: 'تسبيح الله مع حمده وتعظيمه',
    virtueAr: 'كلمتان خفيفتان على اللسان ثقيلتان في الميزان حبيبتان إلى الرحمن',
    defaultTarget: 100
  }
];

export interface TasbihState {
  count: number;
  target: number;
  laps: number;
  totalCounts: number;
  completedCycles: number;
}

export function incrementTasbih(current: TasbihState): { newState: TasbihState; lapCompleted: boolean } {
  const nextCount = current.count + 1;
  const nextTotal = current.totalCounts + 1;
  let lapCompleted = false;
  let finalCount = nextCount;
  let nextLaps = current.laps;
  let nextCycles = current.completedCycles;

  if (current.target > 0 && nextCount >= current.target) {
    lapCompleted = true;
    finalCount = 0;
    nextLaps += 1;
    nextCycles += 1;
  }

  return {
    newState: {
      count: finalCount,
      target: current.target,
      laps: nextLaps,
      totalCounts: nextTotal,
      completedCycles: nextCycles
    },
    lapCompleted
  };
}

export function resetTasbih(target: number): TasbihState {
  return {
    count: 0,
    target,
    laps: 0,
    totalCounts: 0,
    completedCycles: 0
  };
}

export function calculateProgressPercentage(count: number, target: number): number {
  if (target <= 0) return 0;
  return Math.min(100, Math.round((count / target) * 100));
}
