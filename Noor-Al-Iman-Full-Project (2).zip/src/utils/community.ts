/**
 * Community & Privacy Utilities for Islamic Platform
 */

export interface UserPrivacySettings {
  shareGoldenTree: boolean;
  publicProfile: boolean;
  allowDuaGifts: boolean;
  displayName: string;
  avatarIcon: string;
}

export interface CommunityChallenge {
  id: string;
  titleAr: string;
  descriptionAr: string;
  targetCount: number;
  currentCount: number;
  totalParticipants: number;
  daysRemaining: number;
  category: 'quran' | 'azkar' | 'salah' | 'charity';
  rewardLeaves: number;
  joined: boolean;
  userProgress: number;
}

export interface DuaGift {
  id: string;
  senderName: string;
  recipientName: string;
  giftType: 'palm_tree' | 'dua_ghaib' | 'istighfar_bouquet' | 'salawat_pack';
  giftNameAr: string;
  messageAr: string;
  duaPoints: number;
  timestamp: string;
}

export interface ForumPost {
  id: string;
  authorName: string;
  authorTreeLevel: number;
  category: 'tadabbur' | 'hifz' | 'q_and_a' | 'nasihah';
  categoryAr: string;
  titleAr: string;
  contentAr: string;
  upvotes: number;
  userUpvoted?: boolean;
  repliesCount: number;
  timestamp: string;
  replies: Array<{
    id: string;
    authorName: string;
    contentAr: string;
    timestamp: string;
  }>;
}

export function calculateChallengeCompletionRate(current: number, target: number): number {
  if (target <= 0) return 0;
  return Math.min(100, Math.round((current / target) * 100));
}

export function canSendDuaGift(senderBalance: number, giftCost: number): boolean {
  return senderBalance >= giftCost;
}

export function filterPublicTrees<T extends { isPublic: boolean }>(items: T[]): T[] {
  return items.filter(item => item.isPublic);
}
