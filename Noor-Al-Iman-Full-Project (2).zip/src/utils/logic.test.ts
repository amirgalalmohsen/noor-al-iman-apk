import test from 'node:test';
import assert from 'node:assert/strict';

import { calculateQiblaBearing, calculateDistanceToKaaba, getCardinalDirection, KAABA_LAT, KAABA_LNG } from './qibla.ts';
import { calculateTreeProgress, TREE_STAGES } from './goldenTree.ts';
import { incrementTasbih, resetTasbih, calculateProgressPercentage, DHIKR_PRESETS } from './tasbih.ts';

test('Qibla: Makkah coordinates point towards itself (bearing near 0 or valid float)', () => {
  const bearing = calculateQiblaBearing(KAABA_LAT, KAABA_LNG);
  assert.ok(bearing >= 0 && bearing <= 360);
});

test('Qibla: Cairo bearing correctly calculates ~136 degrees (South-East)', () => {
  // Cairo: ~30.0444, 31.2357
  const bearing = calculateQiblaBearing(30.0444, 31.2357);
  // Bearing from Cairo to Makkah is approximately 136.2 degrees
  assert.ok(bearing >= 134 && bearing <= 138, `Expected Cairo bearing ~136, got ${bearing}`);
  const cardinal = getCardinalDirection(bearing);
  assert.match(cardinal, /جنوب شرق/);
});

test('Qibla: Distance to Kaaba from Cairo is ~1280 km', () => {
  const dist = calculateDistanceToKaaba(30.0444, 31.2357);
  assert.ok(dist >= 1200 && dist <= 1350, `Expected ~1280km, got ${dist}`);
});

test('Golden Tree: 0 points starts at Level 1', () => {
  const progress = calculateTreeProgress(0);
  assert.equal(progress.currentLevel.stage, 1);
  assert.equal(progress.currentPoints, 0);
  assert.ok(progress.nextLevel !== null);
  assert.equal(progress.nextLevel?.stage, 2);
  assert.equal(progress.progressPercent, 0);
});

test('Golden Tree: 150 points is at Level 2 with calculated progress', () => {
  const progress = calculateTreeProgress(150);
  assert.equal(progress.currentLevel.stage, 2);
  assert.ok(progress.progressPercent > 0 && progress.progressPercent < 100);
  assert.ok(progress.activeLeaves > 10);
});

test('Golden Tree: 2000 points reaches highest Level 5', () => {
  const progress = calculateTreeProgress(2000);
  assert.equal(progress.currentLevel.stage, 5);
  assert.equal(progress.nextLevel, null);
  assert.equal(progress.progressPercent, 100);
});

test('Tasbih: increment within target updates count', () => {
  const state = resetTasbih(33);
  const result = incrementTasbih(state);
  assert.equal(result.newState.count, 1);
  assert.equal(result.newState.totalCounts, 1);
  assert.equal(result.lapCompleted, false);
});

test('Tasbih: reaching target resets count and increments lap', () => {
  let state = resetTasbih(33);
  state.count = 32;
  state.totalCounts = 32;
  const result = incrementTasbih(state);
  assert.equal(result.newState.count, 0);
  assert.equal(result.newState.laps, 1);
  assert.equal(result.newState.totalCounts, 33);
  assert.equal(result.lapCompleted, true);
});

test('Tasbih: presets are properly defined', () => {
  assert.ok(DHIKR_PRESETS.length >= 7);
  const subhanallah = DHIKR_PRESETS.find(p => p.id === 'subhanallah');
  assert.ok(subhanallah);
  assert.equal(subhanallah?.defaultTarget, 33);
});

test('Tasbih: calculateProgressPercentage returns correct bounds', () => {
  assert.equal(calculateProgressPercentage(11, 33), 33);
  assert.equal(calculateProgressPercentage(33, 33), 100);
  assert.equal(calculateProgressPercentage(0, 33), 0);
});

import { calculateChallengeCompletionRate, canSendDuaGift, filterPublicTrees } from './community.ts';

test('Community: challenge completion rate capped at 100%', () => {
  assert.equal(calculateChallengeCompletionRate(50, 100), 50);
  assert.equal(calculateChallengeCompletionRate(120, 100), 100);
  assert.equal(calculateChallengeCompletionRate(0, 50), 0);
});

test('Community: sending Dua gift checks balance and privacy', () => {
  assert.equal(canSendDuaGift(20, 10), true);
  assert.equal(canSendDuaGift(5, 10), false);

  const list = [
    { id: 1, isPublic: true },
    { id: 2, isPublic: false },
    { id: 3, isPublic: true }
  ];
  assert.equal(filterPublicTrees(list).length, 2);
});

