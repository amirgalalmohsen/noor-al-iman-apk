/**
 * Qibla Direction and Distance Calculations
 * Kaaba coordinates: Latitude 21.4225° N, Longitude 39.8262° E
 */

export const KAABA_LAT = 21.422487;
export const KAABA_LNG = 39.826206;

export interface Coordinates {
  lat: number;
  lng: number;
}

export interface CityLocation {
  nameAr: string;
  nameEn: string;
  country: string;
  lat: number;
  lng: number;
}

export const FAMOUS_CITIES: CityLocation[] = [
  { nameAr: 'مكة المكرمة', nameEn: 'Makkah', country: 'السعودية', lat: 21.4225, lng: 39.8262 },
  { nameAr: 'المدينة المنورة', nameEn: 'Madinah', country: 'السعودية', lat: 24.4672, lng: 39.6111 },
  { nameAr: 'القاهرة', nameEn: 'Cairo', country: 'مصر', lat: 30.0444, lng: 31.2357 },
  { nameAr: 'الإسكندرية', nameEn: 'Alexandria', country: 'مصر', lat: 31.2001, lng: 29.9187 },
  { nameAr: 'القدس الشريف', nameEn: 'Jerusalem', country: 'فلسطين', lat: 31.7683, lng: 35.2137 },
  { nameAr: 'الرياض', nameEn: 'Riyadh', country: 'السعودية', lat: 24.7136, lng: 46.6753 },
  { nameAr: 'دبي', nameEn: 'Dubai', country: 'الإمارات', lat: 25.2048, lng: 55.2708 },
  { nameAr: 'أبو ظبي', nameEn: 'Abu Dhabi', country: 'الإمارات', lat: 24.4539, lng: 54.3773 },
  { nameAr: 'الكويت', nameEn: 'Kuwait City', country: 'الكويت', lat: 29.3759, lng: 47.9774 },
  { nameAr: 'الدوحة', nameEn: 'Doha', country: 'قطر', lat: 25.2854, lng: 51.5310 },
  { nameAr: 'عَمّان', nameEn: 'Amman', country: 'الأردن', lat: 31.9454, lng: 35.9284 },
  { nameAr: 'دمشق', nameEn: 'Damascus', country: 'سوريا', lat: 33.5138, lng: 36.2765 },
  { nameAr: 'بيروت', nameEn: 'Beirut', country: 'لبنان', lat: 33.8938, lng: 35.5018 },
  { nameAr: 'بغداد', nameEn: 'Baghdad', country: 'العراق', lat: 33.3152, lng: 44.3661 },
  { nameAr: 'صنعاء', nameEn: 'Sanaa', country: 'اليمن', lat: 15.3694, lng: 44.1910 },
  { nameAr: 'مسقط', nameEn: 'Muscat', country: 'عُمان', lat: 23.5880, lng: 58.3829 },
  { nameAr: 'المنامة', nameEn: 'Manama', country: 'البحرين', lat: 26.2285, lng: 50.5860 },
  { nameAr: 'الخرطوم', nameEn: 'Khartoum', country: 'السودان', lat: 15.5007, lng: 32.5599 },
  { nameAr: 'طرابلس', nameEn: 'Tripoli', country: 'ليبيا', lat: 32.8872, lng: 13.1913 },
  { nameAr: 'تونس', nameEn: 'Tunis', country: 'تونس', lat: 36.8065, lng: 10.1815 },
  { nameAr: 'الجزائر', nameEn: 'Algiers', country: 'الجزائر', lat: 36.7538, lng: 3.0588 },
  { nameAr: 'الرباط', nameEn: 'Rabat', country: 'المغرب', lat: 34.0209, lng: -6.8416 },
  { nameAr: 'الدار البيضاء', nameEn: 'Casablanca', country: 'المغرب', lat: 33.5731, lng: -7.5898 },
  { nameAr: 'إسطنبول', nameEn: 'Istanbul', country: 'تركيا', lat: 41.0082, lng: 28.9784 },
  { nameAr: 'لندن', nameEn: 'London', country: 'المملكة المتحدة', lat: 51.5074, lng: -0.1278 },
  { nameAr: 'باريس', nameEn: 'Paris', country: 'فرنسا', lat: 48.8566, lng: 2.3522 },
  { nameAr: 'نيويورك', nameEn: 'New York', country: 'الولايات المتحدة', lat: 40.7128, lng: -74.0060 },
  { nameAr: 'كوالالمبور', nameEn: 'Kuala Lumpur', country: 'ماليزيا', lat: 3.1390, lng: 101.6869 },
  { nameAr: 'جاكرتا', nameEn: 'Jakarta', country: 'إندونيسيا', lat: -6.2088, lng: 106.8456 }
];

const toRad = (degrees: number): number => (degrees * Math.PI) / 180;
const toDeg = (radians: number): number => (radians * 180) / Math.PI;

/**
 * Calculates Qibla direction in degrees clockwise from True North (0°-360°)
 */
export function calculateQiblaBearing(userLat: number, userLng: number): number {
  const phi1 = toRad(userLat);
  const phi2 = toRad(KAABA_LAT);
  const deltaLambda = toRad(KAABA_LNG - userLng);

  const y = Math.sin(deltaLambda);
  const x = Math.cos(phi1) * Math.tan(phi2) - Math.sin(phi1) * Math.cos(deltaLambda);

  let qibla = toDeg(Math.atan2(y, x));
  // Normalize to 0 - 360
  qibla = (qibla + 360) % 360;
  return Math.round(qibla * 10) / 10;
}

/**
 * Calculates Great Circle distance to Kaaba in kilometers
 */
export function calculateDistanceToKaaba(userLat: number, userLng: number): number {
  const R = 6371; // Earth radius in km
  const dLat = toRad(KAABA_LAT - userLat);
  const dLng = toRad(KAABA_LNG - userLng);

  const a =
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos(toRad(userLat)) * Math.cos(toRad(KAABA_LAT)) *
    Math.sin(dLng / 2) * Math.sin(dLng / 2);

  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  return Math.round(R * c);
}

/**
 * Returns compass cardinal direction in Arabic (e.g., جنوب شرق)
 */
export function getCardinalDirection(bearing: number): string {
  const normalized = (bearing % 360 + 360) % 360;
  if (normalized >= 337.5 || normalized < 22.5) return 'شمال (N)';
  if (normalized >= 22.5 && normalized < 67.5) return 'شمال شرق (NE)';
  if (normalized >= 67.5 && normalized < 112.5) return 'شرق (E)';
  if (normalized >= 112.5 && normalized < 157.5) return 'جنوب شرق (SE)';
  if (normalized >= 157.5 && normalized < 202.5) return 'جنوب (S)';
  if (normalized >= 202.5 && normalized < 247.5) return 'جنوب غرب (SW)';
  if (normalized >= 247.5 && normalized < 292.5) return 'غرب (W)';
  return 'شمال غرب (NW)';
}
