import React, { useState, useEffect } from 'react';
import { Play, Pause, RotateCcw, Volume2, Sparkles, Check, Settings2, Hand, Cpu } from 'lucide-react';
import { DHIKR_PRESETS, DhikrPreset, incrementTasbih, resetTasbih, calculateProgressPercentage, TasbihState } from '../utils/tasbih';

interface TasbihSectionProps {
  onAddHasanat: (amount: number, reason: string) => void;
  soundEnabled: boolean;
}

export const TasbihSection: React.FC<TasbihSectionProps> = ({ onAddHasanat, soundEnabled }) => {
  const [selectedPreset, setSelectedPreset] = useState<DhikrPreset>(DHIKR_PRESETS[0]);
  const [tasbihState, setTasbihState] = useState<TasbihState>(resetTasbih(DHIKR_PRESETS[0].defaultTarget));
  const [isAutoPlaying, setIsAutoPlaying] = useState<boolean>(false);
  const [autoSpeed, setAutoSpeed] = useState<number>(1200); // 1.2s
  const [vibrationEnabled, setVibrationEnabled] = useState<boolean>(true);
  const [celebrationToast, setCelebrationToast] = useState<string | null>(null);

  const playClickSound = () => {
    if (!soundEnabled) return;
    try {
      const audioCtx = new (window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext)();
      const osc = audioCtx.createOscillator();
      const gain = audioCtx.createGain();
      osc.type = 'triangle';
      osc.frequency.setValueAtTime(440, audioCtx.currentTime);
      osc.frequency.exponentialRampToValueAtTime(880, audioCtx.currentTime + 0.05);
      gain.gain.setValueAtTime(0.12, audioCtx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.001, audioCtx.currentTime + 0.08);
      osc.connect(gain);
      gain.connect(audioCtx.destination);
      osc.start();
      osc.stop(audioCtx.currentTime + 0.1);
    } catch {
      // Audio fallback
    }
  };

  const handleTap = () => {
    if (vibrationEnabled && 'vibrate' in navigator) {
      navigator.vibrate(20);
    }
    playClickSound();

    const { newState, lapCompleted } = incrementTasbih(tasbihState);
    setTasbihState(newState);

    if (lapCompleted) {
      const earned = Math.max(15, Math.floor(tasbihState.target / 3));
      onAddHasanat(earned, `إتمام جولة تسبيح: ${selectedPreset.arabic}`);
      setCelebrationToast(`تمت الدورة بنجاح! +${earned} حسنة لشجرة الذهب ✨`);
      setTimeout(() => setCelebrationToast(null), 3000);
    }
  };

  const handleSelectPreset = (preset: DhikrPreset) => {
    setSelectedPreset(preset);
    setTasbihState(resetTasbih(preset.defaultTarget));
    setIsAutoPlaying(false);
  };

  const handleSetTarget = (targetNum: number) => {
    setTasbihState((prev) => ({
      ...prev,
      target: targetNum,
      count: 0
    }));
  };

  const handleReset = () => {
    setTasbihState(resetTasbih(tasbihState.target));
    setIsAutoPlaying(false);
  };

  // Auto-counting effect
  useEffect(() => {
    if (!isAutoPlaying) return;
    const interval = setInterval(() => {
      handleTap();
    }, autoSpeed);

    return () => clearInterval(interval);
  }, [isAutoPlaying, autoSpeed, tasbihState]);

  // Spacebar trigger for keyboard users
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.code === 'Space' && (e.target as HTMLElement).tagName !== 'INPUT') {
        e.preventDefault();
        handleTap();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [tasbihState, vibrationEnabled, soundEnabled]);

  const progressPercent = calculateProgressPercentage(tasbihState.count, tasbihState.target);

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      {/* Toast Notification */}
      {celebrationToast && (
        <div className="fixed top-20 left-1/2 -translate-x-1/2 z-50 px-4 py-2 rounded-xl bg-amber-500 text-slate-950 font-bold text-sm shadow-xl flex items-center gap-2 animate-bounce">
          <Sparkles className="w-4 h-4" />
          <span>{celebrationToast}</span>
        </div>
      )}

      {/* Preset Dhikr Selection Bar */}
      <div className="flex items-center gap-2 overflow-x-auto pb-2 no-scrollbar">
        {DHIKR_PRESETS.map((preset) => (
          <button
            key={preset.id}
            onClick={() => handleSelectPreset(preset)}
            className={`px-3.5 py-2 rounded-xl text-xs sm:text-sm font-semibold whitespace-nowrap transition-all ${
              selectedPreset.id === preset.id
                ? 'bg-amber-500 text-slate-950 shadow-md shadow-amber-500/20'
                : 'bg-slate-900 border border-slate-800 text-slate-300 hover:bg-slate-800'
            }`}
          >
            {preset.arabic}
          </button>
        ))}
      </div>

      {/* Active Dhikr Virtue Banner */}
      <div className="p-4 rounded-2xl bg-amber-500/10 border border-amber-500/20 text-right">
        <h3 className="text-xl sm:text-2xl font-bold text-amber-200 font-quran">
          {selectedPreset.arabic}
        </h3>
        <p className="text-xs text-amber-300/80 mt-1 font-quran">
          {selectedPreset.virtueAr}
        </p>
      </div>

      {/* Main Digital Masbaha Device Surface */}
      <div className="p-6 sm:p-10 rounded-3xl bg-gradient-to-b from-slate-900 via-slate-950 to-slate-900 border-2 border-amber-500/30 shadow-2xl flex flex-col items-center">
        {/* Device Digital Screen */}
        <div className="w-full max-w-md p-6 rounded-2xl bg-slate-950 border border-slate-800 shadow-inner flex flex-col items-center justify-center space-y-2 relative overflow-hidden">
          <div className="absolute top-2 left-3 flex items-center gap-1.5 text-[10px] text-slate-500">
            <span>الدورات:</span>
            <strong className="text-amber-400 font-mono text-xs tabular-nums">
              {tasbihState.laps}
            </strong>
          </div>

          <div className="absolute top-2 right-3 flex items-center gap-1.5 text-[10px] text-slate-500">
            <span>الإجمالي:</span>
            <strong className="text-emerald-400 font-mono text-xs tabular-nums">
              {tasbihState.totalCounts}
            </strong>
          </div>

          {/* Big Digital Numbers */}
          <div className="py-4 text-center">
            <span className="font-mono text-6xl sm:text-7xl font-extrabold text-amber-300 tracking-wider tabular-nums">
              {tasbihState.count.toString().padStart(2, '0')}
            </span>
            <span className="text-sm font-mono text-slate-500 mr-2">
              / {tasbihState.target}
            </span>
          </div>

          {/* Progress Bar inside screen */}
          <div className="w-full h-2 rounded-full bg-slate-900 overflow-hidden">
            <div
              className="h-full bg-gradient-to-r from-amber-600 to-amber-400 transition-all duration-200 rounded-full"
              style={{ width: `${progressPercent}%` }}
            />
          </div>
        </div>

        {/* Giant Tactile Tap Bead Button */}
        <div className="my-8 flex flex-col items-center">
          <button
            onClick={handleTap}
            className="w-48 h-48 sm:w-56 sm:h-56 rounded-full bg-gradient-to-br from-amber-400 via-amber-600 to-amber-800 p-1.5 shadow-2xl shadow-amber-500/20 active:scale-95 transition-transform flex items-center justify-center focus:outline-none group"
            aria-label="تسبيح"
          >
            <div className="w-full h-full rounded-full bg-gradient-to-br from-slate-900 to-slate-950 flex flex-col items-center justify-center border-4 border-amber-400/40 group-hover:border-amber-400 transition-colors">
              <Sparkles className="w-8 h-8 text-amber-400 mb-2 animate-pulse" />
              <span className="text-xl sm:text-2xl font-extrabold text-amber-100 font-quran tracking-wide">
                سَبِّحْ
              </span>
              <span className="text-[11px] text-amber-400/80 mt-1">
                اضغط هنا أو المسافة
              </span>
            </div>
          </button>
        </div>

        {/* Controls & Mode Switches */}
        <div className="w-full max-w-md flex flex-wrap items-center justify-between gap-3 pt-4 border-t border-slate-800">
          {/* Target Cycle Selector */}
          <div className="flex items-center gap-1.5">
            <span className="text-xs text-slate-400">الهدف:</span>
            {[33, 100, 1000].map((t) => (
              <button
                key={t}
                onClick={() => handleSetTarget(t)}
                className={`px-2 py-1 rounded-lg text-xs font-mono tabular-nums transition-colors ${
                  tasbihState.target === t
                    ? 'bg-amber-500 text-slate-950 font-bold'
                    : 'bg-slate-900 border border-slate-800 text-slate-400 hover:text-white'
                }`}
              >
                {t}
              </button>
            ))}
          </div>

          {/* Auto Mode & Reset */}
          <div className="flex items-center gap-2">
            <button
              onClick={() => setIsAutoPlaying(!isAutoPlaying)}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold transition-all ${
                isAutoPlaying
                  ? 'bg-amber-500 text-slate-950 shadow-md shadow-amber-500/20'
                  : 'bg-slate-900 border border-slate-800 text-slate-300 hover:bg-slate-800'
              }`}
            >
              {isAutoPlaying ? <Pause className="w-3.5 h-3.5" /> : <Play className="w-3.5 h-3.5" />}
              <span>{isAutoPlaying ? 'إيقاف التلقائي' : 'تسبيح تلقائي'}</span>
            </button>

            <button
              onClick={handleReset}
              className="p-2 rounded-xl bg-slate-900 border border-slate-800 text-slate-400 hover:text-rose-400 transition-colors"
              title="تصفير العداد"
            >
              <RotateCcw className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
