import React, { useState } from 'react';
import {
  Users,
  Trophy,
  Gift,
  MessageSquare,
  Shield,
  Heart,
  Sparkles,
  Share2,
  CheckCircle2,
  ThumbsUp,
  Send,
  PlusCircle,
  Eye,
  EyeOff,
  Lock,
} from 'lucide-react';
import {
  INITIAL_COMMUNITY_CHALLENGES,
  COMMUNITY_PROFILES,
  INITIAL_FORUM_POSTS,
  CommunityTreeProfile,
} from '../data/communityData';
import {
  CommunityChallenge,
  ForumPost,
  UserPrivacySettings,
  DuaGift,
  calculateChallengeCompletionRate,
  canSendDuaGift,
} from '../utils/community';

interface CommunitySectionProps {
  totalHasanat: number;
  onAddHasanat: (amount: number, reason: string) => void;
}

export const CommunitySection: React.FC<CommunitySectionProps> = ({
  totalHasanat,
  onAddHasanat,
}) => {
  const [subTab, setSubTab] = useState<'challenges' | 'trees' | 'forum' | 'privacy'>('challenges');

  // Challenges state
  const [challenges, setChallenges] = useState<CommunityChallenge[]>(INITIAL_COMMUNITY_CHALLENGES);
  const [joinedToast, setJoinedToast] = useState<string | null>(null);

  // Community Profiles & Gifts
  const [profiles, setProfiles] = useState<CommunityTreeProfile[]>(COMMUNITY_PROFILES);
  const [duaPointsBalance, setDuaPointsBalance] = useState<number>(100);
  const [selectedGiftRecipient, setSelectedGiftRecipient] = useState<CommunityTreeProfile | null>(null);
  const [selectedGiftType, setSelectedGiftType] = useState<'palm_tree' | 'dua_ghaib' | 'istighfar_bouquet'>('palm_tree');
  const [customGiftMessage, setCustomGiftMessage] = useState<string>('');
  const [giftSuccessToast, setGiftSuccessToast] = useState<string | null>(null);

  // Forum state
  const [posts, setPosts] = useState<ForumPost[]>(INITIAL_FORUM_POSTS);
  const [forumCategory, setForumCategory] = useState<string>('all');
  const [newPostTitle, setNewPostTitle] = useState<string>('');
  const [newPostContent, setNewPostContent] = useState<string>('');
  const [newPostCategory, setNewPostCategory] = useState<'tadabbur' | 'hifz' | 'q_and_a' | 'nasihah'>('tadabbur');
  const [showNewPostForm, setShowNewPostForm] = useState<boolean>(false);
  const [replyInputs, setReplyInputs] = useState<Record<string, string>>({});

  // Privacy Settings state
  const [privacySettings, setPrivacySettings] = useState<UserPrivacySettings>({
    shareGoldenTree: true,
    publicProfile: true,
    allowDuaGifts: true,
    displayName: 'أمير جلال',
    avatarIcon: '👑',
  });

  const showToast = (msg: string) => {
    setJoinedToast(msg);
    setTimeout(() => setJoinedToast(null), 3000);
  };

  // Toggle Challenge Participation
  const handleToggleJoinChallenge = (chId: string) => {
    setChallenges((prev) =>
      prev.map((ch) => {
        if (ch.id === chId) {
          const nextJoined = !ch.joined;
          if (nextJoined) {
            showToast(`بارك الله فيك! انضممت لتحدي: ${ch.titleAr}`);
            onAddHasanat(15, `الانضمام لتحدي ${ch.titleAr}`);
          }
          return {
            ...ch,
            joined: nextJoined,
            totalParticipants: nextJoined ? ch.totalParticipants + 1 : ch.totalParticipants - 1,
          };
        }
        return ch;
      })
    );
  };

  // Contribute progress to challenge
  const handleContribute = (chId: string) => {
    setChallenges((prev) =>
      prev.map((ch) => {
        if (ch.id === chId) {
          const nextCount = ch.currentCount + 10;
          const nextUserProg = ch.userProgress + 10;
          onAddHasanat(ch.rewardLeaves, `مساهمة في ${ch.titleAr}`);
          showToast(`تمت إضافة 10 مساهمات إلى التحدي المبارك!`);
          return {
            ...ch,
            currentCount: nextCount,
            userProgress: nextUserProg,
          };
        }
        return ch;
      })
    );
  };

  // Send Virtual Dua Gift
  const handleSendGift = () => {
    if (!selectedGiftRecipient) return;
    const cost = selectedGiftType === 'palm_tree' ? 20 : selectedGiftType === 'dua_ghaib' ? 10 : 15;
    if (!canSendDuaGift(duaPointsBalance, cost)) {
      showToast('⚠️ رصيد نقاط الدعاء لديك غير كافٍ');
      return;
    }

    setDuaPointsBalance((prev) => prev - cost);
    setProfiles((prev) =>
      prev.map((p) => {
        if (p.id === selectedGiftRecipient.id) {
          return {
            ...p,
            duaPointsReceived: p.duaPointsReceived + cost,
          };
        }
        return p;
      })
    );

    onAddHasanat(25, `إهداء دعاء لأخيك المسلم بظهر الغيب`);
    setGiftSuccessToast(`تم إرسال هدية الدعاء بنجاح إلى ${selectedGiftRecipient.userName}! تقبل الله منكما ✨`);
    setSelectedGiftRecipient(null);
    setCustomGiftMessage('');
    setTimeout(() => setGiftSuccessToast(null), 3500);
  };

  // Forum Upvote
  const handleUpvote = (postId: string) => {
    setPosts((prev) =>
      prev.map((p) => {
        if (p.id === postId) {
          const nextUp = !p.userUpvoted;
          return {
            ...p,
            upvotes: nextUp ? p.upvotes + 1 : p.upvotes - 1,
            userUpvoted: nextUp,
          };
        }
        return p;
      })
    );
  };

  // Add Reply
  const handleAddReply = (postId: string) => {
    const text = replyInputs[postId]?.trim();
    if (!text) return;

    setPosts((prev) =>
      prev.map((p) => {
        if (p.id === postId) {
          return {
            ...p,
            repliesCount: p.repliesCount + 1,
            replies: [
              ...p.replies,
              {
                id: `rep-${Date.now()}`,
                authorName: privacySettings.displayName,
                contentAr: text,
                timestamp: 'الآن',
              },
            ],
          };
        }
        return p;
      })
    );

    setReplyInputs((prev) => ({ ...prev, [postId]: '' }));
    onAddHasanat(10, 'مشاركة رد هادف في حلقة الذكر');
  };

  // Create new Forum Post
  const handleCreatePost = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newPostTitle.trim() || !newPostContent.trim()) return;

    const categoryNames: Record<string, string> = {
      tadabbur: 'تدبر آية',
      hifz: 'تجارب حفظ القرآن',
      q_and_a: 'سؤال وجواب وتواصٍ',
      nasihah: 'نصيحة وتذكرة',
    };

    const newPost: ForumPost = {
      id: `post-${Date.now()}`,
      authorName: privacySettings.displayName,
      authorTreeLevel: 5,
      category: newPostCategory,
      categoryAr: categoryNames[newPostCategory] || 'حلقة ذكر',
      titleAr: newPostTitle.trim(),
      contentAr: newPostContent.trim(),
      upvotes: 1,
      userUpvoted: true,
      repliesCount: 0,
      timestamp: 'الآن',
      replies: [],
    };

    setPosts([newPost, ...posts]);
    setNewPostTitle('');
    setNewPostContent('');
    setShowNewPostForm(false);
    onAddHasanat(20, 'طرح موضوع وتأمل إسلامي في المجتمع');
    showToast('تم نشر موضوعك المبارك في حلقة الذكر!');
  };

  const filteredPosts = posts.filter(
    (p) => forumCategory === 'all' || p.category === forumCategory
  );

  return (
    <div className="space-y-6 text-right">
      {/* Toast Alert */}
      {(joinedToast || giftSuccessToast) && (
        <div className="fixed top-20 left-1/2 -translate-x-1/2 z-50 px-4 py-2.5 rounded-xl bg-amber-500 text-slate-950 font-bold text-sm shadow-xl flex items-center gap-2 animate-bounce">
          <Sparkles className="w-4 h-4" />
          <span>{joinedToast || giftSuccessToast}</span>
        </div>
      )}

      {/* Community Subtabs Navigation */}
      <div className="flex items-center justify-between gap-4 p-4 rounded-3xl bg-slate-900/80 border border-slate-800">
        <div className="flex items-center gap-2 overflow-x-auto no-scrollbar">
          {[
            { id: 'challenges', label: 'التحديات الإسلامية الجماعية' },
            { id: 'trees', label: 'معرض الأشجار وهدايا الدعاء' },
            { id: 'forum', label: 'حلقات الذكر والتدبر' },
            { id: 'privacy', label: 'إعدادات الخصوصية والظهور' },
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => setSubTab(tab.id as typeof subTab)}
              className={`px-3.5 py-2 rounded-xl text-xs sm:text-sm font-semibold whitespace-nowrap transition-colors ${
                subTab === tab.id
                  ? 'bg-amber-500 text-slate-950 shadow-md shadow-amber-500/20'
                  : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>

        {/* User Dua Points Balance */}
        <div className="hidden sm:flex items-center gap-2 px-3 py-1.5 rounded-xl bg-amber-500/10 border border-amber-500/30 text-amber-300 text-xs font-semibold tabular-nums shrink-0">
          <Gift className="w-3.5 h-3.5 text-amber-400" />
          <span>رصيد نقاط الدعاء: {duaPointsBalance}</span>
        </div>
      </div>

      {/* 1. CHALLENGES SUBTAB */}
      {subTab === 'challenges' && (
        <div className="space-y-4">
          <div className="p-6 rounded-3xl bg-gradient-to-r from-amber-950/30 via-slate-900 to-slate-900 border border-amber-500/30 flex flex-col md:flex-row md:items-center justify-between gap-4">
            <div>
              <span className="text-xs font-bold text-amber-400">
                ﴿ وَتَعَاوَنُوا عَلَى الْبِرِّ وَالتَّقْوَىٰ ﴾
              </span>
              <h2 className="text-2xl font-extrabold text-amber-100 font-quran mt-1">
                تحديات المجتمع الإسلامي التنافسية
              </h2>
              <p className="text-xs text-slate-400 mt-1 max-w-xl">
                شارك إخوانك المسلمين حول العالم في إنجاز التحديات الروحانية وقراءة الأوراد ونيل أوراق شجرة الذهب المشتركة
              </p>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {challenges.map((ch) => {
              const rate = calculateChallengeCompletionRate(ch.currentCount, ch.targetCount);

              return (
                <div
                  key={ch.id}
                  className={`p-6 rounded-3xl border transition-all space-y-4 ${
                    ch.joined
                      ? 'bg-slate-900/90 border-amber-500/40 shadow-lg shadow-amber-500/5'
                      : 'bg-slate-900/60 border-slate-800 hover:border-slate-700'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <span className="text-xs px-2.5 py-0.5 rounded-full bg-amber-500/15 text-amber-300 font-semibold border border-amber-500/25">
                      متبقي {ch.daysRemaining} أيام
                    </span>
                    <span className="text-xs text-slate-400 flex items-center gap-1">
                      <Users className="w-3.5 h-3.5 text-amber-400" />
                      <span>{ch.totalParticipants.toLocaleString('ar-EG')} مشارك</span>
                    </span>
                  </div>

                  <h3 className="text-xl font-bold text-amber-200 font-quran">
                    {ch.titleAr}
                  </h3>

                  <p className="text-xs text-slate-300 leading-relaxed">
                    {ch.descriptionAr}
                  </p>

                  {/* Progress Bar */}
                  <div className="space-y-1.5 pt-2">
                    <div className="flex items-center justify-between text-xs text-slate-400">
                      <span>إجمالي الإنجاز الجماعي:</span>
                      <span className="text-amber-400 font-bold tabular-nums">
                        {ch.currentCount.toLocaleString('ar-EG')} / {ch.targetCount.toLocaleString('ar-EG')} ({rate}%)
                      </span>
                    </div>
                    <div className="w-full h-2.5 rounded-full bg-slate-950 overflow-hidden">
                      <div
                        className="h-full bg-gradient-to-r from-amber-600 to-amber-400 transition-all rounded-full"
                        style={{ width: `${rate}%` }}
                      />
                    </div>
                  </div>

                  {ch.joined && (
                    <div className="p-3 rounded-xl bg-amber-500/5 border border-amber-500/20 flex items-center justify-between text-xs">
                      <span className="text-slate-300">مساهمتك الفردية:</span>
                      <span className="text-amber-300 font-bold tabular-nums">
                        {ch.userProgress} إنجاز
                      </span>
                    </div>
                  )}

                  {/* Actions */}
                  <div className="flex items-center justify-between pt-2">
                    <button
                      onClick={() => handleToggleJoinChallenge(ch.id)}
                      className={`px-4 py-2 rounded-xl text-xs font-bold transition-all ${
                        ch.joined
                          ? 'bg-slate-800 text-emerald-400 border border-emerald-500/30'
                          : 'bg-amber-500 text-slate-950 shadow-md hover:bg-amber-400'
                      }`}
                    >
                      {ch.joined ? 'مشارك في التحدي ✓' : 'انضم للتحدي (+15)'}
                    </button>

                    {ch.joined && (
                      <button
                        onClick={() => handleContribute(ch.id)}
                        className="px-4 py-2 rounded-xl bg-gradient-to-r from-emerald-600 to-emerald-500 hover:from-emerald-500 hover:to-emerald-400 text-white font-bold text-xs shadow-md transition-all"
                      >
                        سجّل مساهمة جديدة (+10)
                      </button>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* 2. TREES SHOWCASE & DUA GIFTS SUBTAB */}
      {subTab === 'trees' && (
        <div className="space-y-6">
          <div className="p-6 rounded-3xl bg-slate-900/80 border border-slate-800 flex flex-col md:flex-row md:items-center justify-between gap-4">
            <div>
              <span className="text-xs font-bold text-amber-400">
                ﴿ مَثَلًا كَلِمَةً طَيِّبَةً كَشَجَرَةٍ طَيِّبَةٍ أَصْلُهَا ثَابِتٌ وَفَرْعُهَا فِي السَّمَاءِ ﴾
              </span>
              <h2 className="text-2xl font-extrabold text-amber-100 font-quran mt-1">
                معرض الأشجار الذهبية وهدايا الدعاء بظهر الغيب
              </h2>
              <p className="text-xs text-slate-400 mt-1 max-w-xl">
                أهدِ إخوانك المسلمين نقاط دعاء وغرس نخلة في الجنة بظهر الغيب، لتنال مثل أجرهم بدعاء الملائكة: ولك بمثل!
              </p>
            </div>
          </div>

          {/* Profiles Grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            {profiles.map((prof) => (
              <div
                key={prof.id}
                className="p-5 rounded-3xl bg-slate-900/80 border border-slate-800 hover:border-amber-500/40 transition-all space-y-4 flex flex-col justify-between"
              >
                <div>
                  <div className="flex items-center justify-between">
                    <span className="w-10 h-10 rounded-2xl bg-amber-500/20 border border-amber-500/40 text-amber-300 font-bold flex items-center justify-center text-sm">
                      {prof.avatarChar}
                    </span>
                    <span className="text-xs px-2 py-0.5 rounded-full bg-slate-800 text-amber-300 border border-slate-700">
                      {prof.badge}
                    </span>
                  </div>

                  <h4 className="text-base font-bold text-slate-100 mt-3 font-quran">
                    {prof.userName}
                  </h4>
                  <p className="text-xs text-amber-400/90 font-medium">
                    {prof.levelTitle}
                  </p>
                  <p className="text-[11px] text-slate-400 mt-2 line-clamp-2">
                    {prof.recentDeed}
                  </p>
                </div>

                <div className="space-y-3 pt-3 border-t border-slate-800">
                  <div className="flex items-center justify-between text-xs text-slate-400">
                    <span>أوراق الذهب:</span>
                    <strong className="text-amber-300 font-mono tabular-nums">
                      {prof.leavesCount} 🌿
                    </strong>
                  </div>
                  <div className="flex items-center justify-between text-xs text-slate-400">
                    <span>هدايا الدعاء المستلمة:</span>
                    <strong className="text-emerald-400 font-mono tabular-nums">
                      {prof.duaPointsReceived} نقطة
                    </strong>
                  </div>

                  <button
                    onClick={() => setSelectedGiftRecipient(prof)}
                    className="w-full py-2 rounded-xl bg-amber-500/15 hover:bg-amber-500/25 border border-amber-500/30 text-amber-300 font-bold text-xs flex items-center justify-center gap-1.5 transition-colors"
                  >
                    <Gift className="w-3.5 h-3.5" />
                    <span>أهدِ دعاء بظهر الغيب</span>
                  </button>
                </div>
              </div>
            ))}
          </div>

          {/* Send Gift Modal */}
          {selectedGiftRecipient && (
            <div className="fixed inset-0 z-50 bg-black/75 backdrop-blur-xs flex items-center justify-center p-4">
              <div className="w-full max-w-lg p-6 rounded-3xl bg-slate-900 border border-amber-500/40 text-right space-y-4 shadow-2xl">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-amber-400">
                    إهداء دعاء مبارك إلى: {selectedGiftRecipient.userName}
                  </span>
                  <button
                    onClick={() => setSelectedGiftRecipient(null)}
                    className="p-1 rounded-lg text-slate-400 hover:text-white"
                  >
                    ✕
                  </button>
                </div>

                <p className="text-xs text-slate-300 leading-relaxed font-quran">
                  قال رسول الله ﷺ: «دَعْوَةُ المَرْءِ المُسْلِمِ لأَخِيهِ بِظَهْرِ الغَيْبِ مُسْتَجَابَةٌ، عِنْدَ رَأْسِهِ مَلَكٌ مُوَكَّلٌ كُلَّما دَعا لأَخِيهِ بِخَيْرٍ، قالَ المَلَكُ المُوَكَّلُ بهِ: آمِينَ، وَلَكَ بمِثْلٍ».
                </p>

                {/* Gift Types */}
                <div className="grid grid-cols-3 gap-2 pt-2">
                  {[
                    { id: 'palm_tree', label: 'غرس نخلة بالجنة', cost: 20, icon: '🌴' },
                    { id: 'dua_ghaib', label: 'دعوة بفك الكرب', cost: 10, icon: '🤲' },
                    { id: 'istighfar_bouquet', label: 'باقة استغفار', cost: 15, icon: '🌸' },
                  ].map((g) => (
                    <button
                      key={g.id}
                      onClick={() => setSelectedGiftType(g.id as typeof selectedGiftType)}
                      className={`p-3 rounded-2xl border text-center transition-all ${
                        selectedGiftType === g.id
                          ? 'bg-amber-500/20 border-amber-500 text-amber-200'
                          : 'bg-slate-950 border-slate-800 text-slate-400 hover:text-white'
                      }`}
                    >
                      <div className="text-xl">{g.icon}</div>
                      <div className="text-xs font-bold mt-1">{g.label}</div>
                      <div className="text-[10px] text-amber-400">{g.cost} نقطة</div>
                    </button>
                  ))}
                </div>

                <div>
                  <label className="block text-xs font-medium text-slate-400 mb-1">
                    رسالة دعاء طيبة (اختياري):
                  </label>
                  <textarea
                    value={customGiftMessage}
                    onChange={(e) => setCustomGiftMessage(e.target.value)}
                    placeholder="اللهم اجعله من عبادك الصالحين ووفقه لما تحب وترضى..."
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl p-3 text-xs text-slate-200 placeholder:text-slate-500 focus:outline-none focus:border-amber-500 h-20 resize-none"
                  />
                </div>

                <div className="flex items-center justify-between pt-2">
                  <span className="text-xs text-slate-400">
                    رصيدك الحالي: <strong className="text-amber-400">{duaPointsBalance}</strong> نقطة
                  </span>
                  <button
                    onClick={handleSendGift}
                    className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-slate-950 font-bold text-xs shadow-md transition-all flex items-center gap-1.5"
                  >
                    <Send className="w-3.5 h-3.5" />
                    <span>إرسال الهدية الآن</span>
                  </button>
                </div>
              </div>
            </div>
          )}
        </div>
      )}

      {/* 3. FORUM SUBTAB */}
      {subTab === 'forum' && (
        <div className="space-y-6">
          <div className="p-6 rounded-3xl bg-slate-900/80 border border-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div>
              <span className="text-xs font-bold text-amber-400">
                ﴿ وَتَوَاصَوْا بِالْحَقِّ وَتَوَاصَوْا بِالصَّبْرِ ﴾
              </span>
              <h2 className="text-2xl font-extrabold text-amber-100 font-quran mt-1">
                حلقات الذكر والتدبر القرآني
              </h2>
              <p className="text-xs text-slate-400 mt-1">
                اطرح تأملاتك القرآنية، شارك تجربتك في حفظ كتاب الله، واستشر إخوانك الصالحين
              </p>
            </div>

            <button
              onClick={() => setShowNewPostForm(!showNewPostForm)}
              className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-amber-500 text-slate-950 font-bold text-xs sm:text-sm shadow-md transition-all"
            >
              <PlusCircle className="w-4 h-4" />
              <span>طرح تأمل أو سؤال جديد</span>
            </button>
          </div>

          {/* New Post Form Drawer */}
          {showNewPostForm && (
            <form onSubmit={handleCreatePost} className="p-6 rounded-3xl bg-slate-900 border border-amber-500/30 space-y-4">
              <h3 className="text-base font-bold text-amber-200">طرح موضوع جديد في حلقة الذكر</h3>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-medium text-slate-400 mb-1">
                    عنوان الموضوع:
                  </label>
                  <input
                    type="text"
                    required
                    value={newPostTitle}
                    onChange={(e) => setNewPostTitle(e.target.value)}
                    placeholder="مثال: وقفة مع قول الله تعالى..."
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-slate-200 focus:outline-none focus:border-amber-500"
                  />
                </div>

                <div>
                  <label className="block text-xs font-medium text-slate-400 mb-1">
                    القسم:
                  </label>
                  <select
                    value={newPostCategory}
                    onChange={(e) => setNewPostCategory(e.target.value as typeof newPostCategory)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-slate-200 focus:outline-none focus:border-amber-500"
                  >
                    <option value="tadabbur">تدبر آية</option>
                    <option value="hifz">تجارب حفظ القرآن</option>
                    <option value="q_and_a">سؤال وجواب وتواصٍ</option>
                    <option value="nasihah">نصيحة وتذكرة</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-400 mb-1">
                  نص الموضوع أو التأمل:
                </label>
                <textarea
                  required
                  rows={4}
                  value={newPostContent}
                  onChange={(e) => setNewPostContent(e.target.value)}
                  placeholder="شارك إخوانك الفائدة بحسن نية وأسلوب رقيق..."
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl p-3 text-xs text-slate-200 focus:outline-none focus:border-amber-500 resize-none"
                />
              </div>

              <div className="flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setShowNewPostForm(false)}
                  className="px-4 py-2 rounded-xl bg-slate-800 text-slate-300 text-xs"
                >
                  إلغاء
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-amber-500 text-slate-950 font-bold text-xs"
                >
                  نشر الموضوع (+20 حسنة)
                </button>
              </div>
            </form>
          )}

          {/* Posts Feed */}
          <div className="space-y-4">
            {filteredPosts.map((post) => (
              <div
                key={post.id}
                className="p-6 rounded-3xl bg-slate-900/80 border border-slate-800 hover:border-slate-700 transition-colors space-y-4"
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <span className="w-8 h-8 rounded-xl bg-amber-500/20 text-amber-300 font-bold flex items-center justify-center text-xs">
                      {post.authorName.charAt(0)}
                    </span>
                    <div>
                      <div className="font-bold text-sm text-slate-100">{post.authorName}</div>
                      <div className="text-[10px] text-slate-400">{post.timestamp}</div>
                    </div>
                  </div>

                  <span className="text-xs px-2.5 py-0.5 rounded-full bg-slate-800 text-amber-300 border border-slate-700">
                    {post.categoryAr}
                  </span>
                </div>

                <h3 className="text-lg font-bold text-amber-200 font-quran">
                  {post.titleAr}
                </h3>

                <p className="text-sm text-slate-200 font-quran leading-relaxed whitespace-pre-line">
                  {post.contentAr}
                </p>

                {/* Post Footer with Upvote & Replies count */}
                <div className="flex items-center justify-between pt-3 border-t border-slate-800/80">
                  <div className="flex items-center gap-3">
                    <button
                      onClick={() => handleUpvote(post.id)}
                      className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-medium transition-colors ${
                        post.userUpvoted
                          ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40'
                          : 'bg-slate-800 text-slate-400 hover:text-white'
                      }`}
                    >
                      <ThumbsUp className="w-3.5 h-3.5" />
                      <span>جزاك الله خيراً ({post.upvotes})</span>
                    </button>

                    <span className="text-xs text-slate-400 flex items-center gap-1">
                      <MessageSquare className="w-3.5 h-3.5 text-amber-400" />
                      <span>{post.repliesCount} ردود</span>
                    </span>
                  </div>
                </div>

                {/* Existing Replies List */}
                {post.replies.length > 0 && (
                  <div className="space-y-2 pt-2 border-t border-slate-900">
                    {post.replies.map((rep) => (
                      <div
                        key={rep.id}
                        className="p-3 rounded-2xl bg-slate-950/70 border border-slate-800/80 text-xs text-slate-200 space-y-1"
                      >
                        <div className="flex items-center justify-between text-[11px] text-amber-400/90 font-semibold">
                          <span>{rep.authorName}</span>
                          <span className="text-[10px] text-slate-500">{rep.timestamp}</span>
                        </div>
                        <p className="leading-relaxed">{rep.contentAr}</p>
                      </div>
                    ))}
                  </div>
                )}

                {/* Quick Reply Form */}
                <div className="flex items-center gap-2 pt-2">
                  <input
                    type="text"
                    value={replyInputs[post.id] || ''}
                    onChange={(e) =>
                      setReplyInputs({ ...replyInputs, [post.id]: e.target.value })
                    }
                    onKeyDown={(e) => {
                      if (e.key === 'Enter') handleAddReply(post.id);
                    }}
                    placeholder="اكتب رداً أو تعليقاً طيباً..."
                    className="flex-1 bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-slate-200 focus:outline-none focus:border-amber-500"
                  />
                  <button
                    onClick={() => handleAddReply(post.id)}
                    className="px-3.5 py-2 rounded-xl bg-amber-500 text-slate-950 font-bold text-xs hover:bg-amber-400 transition-colors"
                  >
                    إرسال
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* 4. PRIVACY SETTINGS SUBTAB */}
      {subTab === 'privacy' && (
        <div className="max-w-2xl mx-auto space-y-6">
          <div className="p-6 rounded-3xl bg-slate-900/80 border border-slate-800 text-right space-y-2">
            <div className="flex items-center gap-2 text-amber-400">
              <Shield className="w-5 h-5" />
              <h3 className="text-xl font-bold font-quran text-amber-200">
                إعدادات الخصوصية والتحكم في المشاركة
              </h3>
            </div>
            <p className="text-xs text-slate-400 leading-relaxed">
              تحكم بدقة فيما يظهر للآخرين من إنجازاتك في شجرة الحسنات، وخصوصية تلقي هدايا الدعاء
            </p>
          </div>

          <div className="p-6 rounded-3xl bg-slate-900 border border-slate-800 space-y-5">
            {/* Display Name Input */}
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">
                الاسم الظاهر في المجتمع:
              </label>
              <input
                type="text"
                value={privacySettings.displayName}
                onChange={(e) =>
                  setPrivacySettings({ ...privacySettings, displayName: e.target.value })
                }
                className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-slate-200 focus:outline-none focus:border-amber-500"
              />
              <span className="text-[11px] text-slate-500 mt-1 block">
                يمكنك استخدام اسمك الحقيقي أو كنية مستعارة مثل: فاعل خير، أمة الله، الراجي عفو ربه.
              </span>
            </div>

            {/* Toggle 1: Share Golden Tree */}
            <div className="flex items-center justify-between p-4 rounded-2xl bg-slate-950 border border-slate-800">
              <div>
                <span className="text-sm font-bold text-slate-200 block">
                  مشاركة شجرتي الذهبية في معرض المجتمع
                </span>
                <span className="text-xs text-slate-400">
                  السماح للآخرين برؤية مستوى شجرتك وعدد أوراق الذهب تحفيزاً على الطاعة
                </span>
              </div>
              <button
                onClick={() =>
                  setPrivacySettings({
                    ...privacySettings,
                    shareGoldenTree: !privacySettings.shareGoldenTree,
                  })
                }
                className={`w-12 h-6 rounded-full transition-colors relative p-1 ${
                  privacySettings.shareGoldenTree ? 'bg-amber-500' : 'bg-slate-800'
                }`}
              >
                <div
                  className={`w-4 h-4 rounded-full bg-slate-950 transition-transform ${
                    privacySettings.shareGoldenTree ? '-translate-x-6' : 'translate-x-0'
                  }`}
                />
              </button>
            </div>

            {/* Toggle 2: Allow Dua Gifts */}
            <div className="flex items-center justify-between p-4 rounded-2xl bg-slate-950 border border-slate-800">
              <div>
                <span className="text-sm font-bold text-slate-200 block">
                  تلقي هدايا الدعاء بظهر الغيب
                </span>
                <span className="text-xs text-slate-400">
                  تمكين إخوانك المسلمين من إهدائك نقاط دعاء وغرس نخلة في الجنة
                </span>
              </div>
              <button
                onClick={() =>
                  setPrivacySettings({
                    ...privacySettings,
                    allowDuaGifts: !privacySettings.allowDuaGifts,
                  })
                }
                className={`w-12 h-6 rounded-full transition-colors relative p-1 ${
                  privacySettings.allowDuaGifts ? 'bg-amber-500' : 'bg-slate-800'
                }`}
              >
                <div
                  className={`w-4 h-4 rounded-full bg-slate-950 transition-transform ${
                    privacySettings.allowDuaGifts ? '-translate-x-6' : 'translate-x-0'
                  }`}
                />
              </button>
            </div>

            {/* Toggle 3: Public Profile */}
            <div className="flex items-center justify-between p-4 rounded-2xl bg-slate-950 border border-slate-800">
              <div>
                <span className="text-sm font-bold text-slate-200 block">
                  إظهار شارة المؤسس (Amir Galal Edition)
                </span>
                <span className="text-xs text-slate-400">
                  عرض وسام النسخة الخاصة على بروفايلك
                </span>
              </div>
              <button
                onClick={() =>
                  setPrivacySettings({
                    ...privacySettings,
                    publicProfile: !privacySettings.publicProfile,
                  })
                }
                className={`w-12 h-6 rounded-full transition-colors relative p-1 ${
                  privacySettings.publicProfile ? 'bg-amber-500' : 'bg-slate-800'
                }`}
              >
                <div
                  className={`w-4 h-4 rounded-full bg-slate-950 transition-transform ${
                    privacySettings.publicProfile ? '-translate-x-6' : 'translate-x-0'
                  }`}
                />
              </button>
            </div>

            <div className="pt-2 flex justify-end">
              <button
                onClick={() => showToast('تم حفظ إعدادات الخصوصية بنجاح')}
                className="px-6 py-2.5 rounded-xl bg-amber-500 text-slate-950 font-bold text-xs"
              >
                حفظ الإعدادات
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
