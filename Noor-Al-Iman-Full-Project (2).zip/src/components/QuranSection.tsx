import React, { useState, useRef, useEffect } from 'react';
import { Play, Pause, Volume2, Bookmark, BookOpen, Search, Info, HelpCircle, Check, ChevronLeft } from 'lucide-react';
import { SURAH_LIST, DETAILED_SURAHS, SurahSummary, DetailedSurah, QuranAyah, QuranWordMeaning } from '../data/quranData';

interface QuranSectionProps {
  onAddHasanat: (amount: number, reason: string) => void;
}

export const QuranSection: React.FC<QuranSectionProps> = ({ onAddHasanat }) => {
  const [selectedSurahNumber, setSelectedSurahNumber] = useState<number>(1);
  const [activeAyahNumber, setActiveAyahNumber] = useState<number | null>(null);
  const [isPlaying, setIsPlaying] = useState<boolean>(false);
  const [currentPlayingAyah, setCurrentPlayingAyah] = useState<number>(1);
  const [selectedWord, setSelectedWord] = useState<QuranWordMeaning | null>(null);
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [bookmarkedSurahs, setBookmarkedSurahs] = useState<number[]>([1]);
  const [showTafseerForAyah, setShowTafseerForAyah] = useState<number | null>(null);

  const audioRef = useRef<HTMLAudioElement | null>(null);

  const currentDetailedSurah: DetailedSurah = DETAILED_SURAHS[selectedSurahNumber] || DETAILED_SURAHS[1];

  const filteredSurahs = SURAH_LIST.filter((s) => {
    return (
      s.name.includes(searchQuery) ||
      s.englishName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      s.number.toString().includes(searchQuery)
    );
  });

  // Audio Playback
  const playAyahAudio = (ayahNumberInSurah: number) => {
    const ayah = currentDetailedSurah.ayahs.find((a) => a.ayahNumberInSurah === ayahNumberInSurah);
    if (!ayah) return;

    if (audioRef.current) {
      audioRef.current.pause();
    }

    const audio = new Audio(ayah.audioUrl);
    audioRef.current = audio;
    setCurrentPlayingAyah(ayahNumberInSurah);
    setIsPlaying(true);

    audio.play().catch((err) => {
      console.warn('Audio play error', err);
      setIsPlaying(false);
    });

    audio.onended = () => {
      if (ayahNumberInSurah < currentDetailedSurah.ayahs.length) {
        playAyahAudio(ayahNumberInSurah + 1);
      } else {
        setIsPlaying(false);
        onAddHasanat(30, `إتمام الاستماع لسورة ${currentDetailedSurah.name}`);
      }
    };
  };

  const togglePlaySurah = () => {
    if (isPlaying) {
      if (audioRef.current) audioRef.current.pause();
      setIsPlaying(false);
    } else {
      playAyahAudio(currentPlayingAyah || 1);
    }
  };

  useEffect(() => {
    return () => {
      if (audioRef.current) {
        audioRef.current.pause();
      }
    };
  }, []);

  const toggleBookmark = (surahNum: number) => {
    setBookmarkedSurahs((prev) =>
      prev.includes(surahNum) ? prev.filter((n) => n !== surahNum) : [...prev, surahNum]
    );
  };

  return (
    <div className="space-y-6">
      {/* Surah Bar & Controls */}
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 p-5 rounded-3xl bg-slate-900/80 border border-slate-800">
        <div className="flex items-center gap-4">
          <div className="w-12 h-12 rounded-2xl bg-amber-500/10 border border-amber-500/30 flex items-center justify-center text-amber-300 font-bold text-lg font-quran">
            {currentDetailedSurah.number}
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-xl sm:text-2xl font-extrabold text-amber-200 font-quran">
                سُورَةُ {currentDetailedSurah.name}
              </h2>
              <span className="text-xs px-2 py-0.5 rounded-full bg-slate-800 text-slate-300">
                {currentDetailedSurah.revelationType === 'Meccan' ? 'مكية' : 'مدنية'}
              </span>
              <span className="text-xs text-slate-400">
                {currentDetailedSurah.numberOfAyahs} آيات
              </span>
            </div>
            <p className="text-xs text-slate-400 mt-1 line-clamp-1">
              {currentDetailedSurah.virtueAr}
            </p>
          </div>
        </div>

        {/* Audio Recitation Player Toolbar */}
        <div className="flex items-center gap-3">
          <button
            onClick={togglePlaySurah}
            className="flex items-center gap-2 px-4 py-2 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-slate-950 font-bold text-xs sm:text-sm shadow-md transition-all"
          >
            {isPlaying ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4" />}
            <span>{isPlaying ? 'إيقاف التلاوة' : 'استماع للتلاوة العطرة'}</span>
          </button>

          <button
            onClick={() => toggleBookmark(currentDetailedSurah.number)}
            className={`p-2 rounded-xl border transition-colors ${
              bookmarkedSurahs.includes(currentDetailedSurah.number)
                ? 'bg-amber-500/20 border-amber-500/40 text-amber-300'
                : 'bg-slate-800 border-slate-700 text-slate-400 hover:text-slate-200'
            }`}
            title="حفظ العلامة المرجعية"
          >
            <Bookmark className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Main Grid: Surahs Directory (Sidebar) + Reading Canvas */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Surahs List Directory */}
        <div className="lg:col-span-4 space-y-3">
          <div className="relative">
            <Search className="w-4 h-4 absolute right-3 top-1/2 -translate-y-1/2 text-slate-500" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="ابحث برقم أو اسم السورة..."
              className="w-full bg-slate-900 border border-slate-800 rounded-xl pr-9 pl-3 py-2 text-xs text-slate-200 placeholder:text-slate-500 focus:outline-none focus:border-amber-500"
            />
          </div>

          <div className="max-h-[560px] overflow-y-auto space-y-1.5 pr-1">
            {filteredSurahs.map((surah) => {
              const isSelected = surah.number === selectedSurahNumber;
              const isDetailed = !!DETAILED_SURAHS[surah.number];

              return (
                <button
                  key={surah.number}
                  onClick={() => {
                    if (isDetailed) {
                      setSelectedSurahNumber(surah.number);
                      setCurrentPlayingAyah(1);
                      if (isPlaying && audioRef.current) audioRef.current.pause();
                      setIsPlaying(false);
                    }
                  }}
                  className={`w-full flex items-center justify-between p-3 rounded-xl border text-right transition-colors ${
                    isSelected
                      ? 'bg-amber-500/15 border-amber-500/40 text-amber-200 shadow-xs'
                      : isDetailed
                      ? 'bg-slate-900/60 border-slate-800/80 text-slate-300 hover:bg-slate-800 hover:border-slate-700'
                      : 'bg-slate-950/40 border-slate-900 text-slate-500 cursor-not-allowed opacity-60'
                  }`}
                >
                  <div className="flex items-center gap-2.5">
                    <span className="w-7 h-7 rounded-lg bg-slate-800 flex items-center justify-center text-xs font-bold text-amber-400 tabular-nums">
                      {surah.number}
                    </span>
                    <div>
                      <div className="font-bold text-sm font-quran">{surah.name}</div>
                      <div className="text-[10px] text-slate-400">{surah.englishName}</div>
                    </div>
                  </div>

                  <div className="text-left text-[11px] text-slate-400">
                    <span>{surah.numberOfAyahs} آية</span>
                    {isDetailed && (
                      <span className="block text-[10px] text-emerald-400">مكتملة التفسير</span>
                    )}
                  </div>
                </button>
              );
            })}
          </div>
        </div>

        {/* Quran Reader & Vocabulary Inspector */}
        <div className="lg:col-span-8 space-y-4">
          {/* Asbab al-Nuzul & Theme info box */}
          {currentDetailedSurah.asbabGeneral && (
            <div className="p-4 rounded-2xl bg-amber-500/5 border border-amber-500/20 text-right space-y-1">
              <span className="text-xs font-bold text-amber-400 flex items-center gap-1.5">
                <Info className="w-3.5 h-3.5" />
                <span>سبب النزول وموضوع السورة:</span>
              </span>
              <p className="text-xs text-amber-100/90 leading-relaxed font-quran">
                {currentDetailedSurah.asbabGeneral}
              </p>
            </div>
          )}

          {/* Bismillah Header if applicable */}
          {currentDetailedSurah.bismillahPre && (
            <div className="text-center py-4">
              <p className="text-2xl text-amber-300 font-quran tracking-wide">
                بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ
              </p>
            </div>
          )}

          {/* Ayahs Stream */}
          <div className="space-y-4">
            {currentDetailedSurah.ayahs.map((ayah) => {
              const isCurrentlyPlaying = isPlaying && currentPlayingAyah === ayah.ayahNumberInSurah;
              const hasTafseerOpen = showTafseerForAyah === ayah.ayahNumberInSurah;

              return (
                <div
                  key={ayah.number}
                  className={`p-5 rounded-2xl border transition-all ${
                    isCurrentlyPlaying
                      ? 'bg-amber-500/10 border-amber-500 shadow-lg shadow-amber-500/10'
                      : 'bg-slate-900/70 border-slate-800 hover:border-slate-700'
                  }`}
                >
                  {/* Ayah Header Bar */}
                  <div className="flex items-center justify-between mb-3">
                    <div className="flex items-center gap-2">
                      <span className="w-7 h-7 rounded-full border border-amber-500/40 bg-amber-500/10 flex items-center justify-center text-xs font-bold text-amber-300 tabular-nums">
                        {ayah.ayahNumberInSurah}
                      </span>
                      {isCurrentlyPlaying && (
                        <span className="text-xs text-amber-400 flex items-center gap-1 animate-pulse">
                          <Volume2 className="w-3.5 h-3.5" />
                          <span>جارٍ الاستماع...</span>
                        </span>
                      )}
                    </div>

                    <div className="flex items-center gap-2">
                      <button
                        onClick={() => playAyahAudio(ayah.ayahNumberInSurah)}
                        className="p-1.5 rounded-lg text-slate-400 hover:text-amber-300 hover:bg-slate-800 transition-colors"
                        title="استماع لهذه الآية الكريمة"
                      >
                        <Volume2 className="w-4 h-4" />
                      </button>

                      <button
                        onClick={() =>
                          setShowTafseerForAyah(hasTafseerOpen ? null : ayah.ayahNumberInSurah)
                        }
                        className={`px-2 py-1 rounded-lg text-xs font-medium transition-colors ${
                          hasTafseerOpen
                            ? 'bg-amber-500 text-slate-950 font-bold'
                            : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
                        }`}
                      >
                        التفسير الميسر
                      </button>
                    </div>
                  </div>

                  {/* Ayah Arabic Uthmani Text with clickable vocabulary tokens */}
                  <div className="my-3 text-right">
                    <p className="font-quran text-2xl sm:text-3xl text-slate-100 leading-[2.5] tracking-wide">
                      {ayah.text}{' '}
                      <span className="inline-flex items-center justify-center w-7 h-7 rounded-full border border-amber-500/40 text-amber-400 text-xs font-sans mr-2">
                        {ayah.ayahNumberInSurah}
                      </span>
                    </p>
                  </div>

                  {/* Marked Quranic Vocabulary Words (غريب القرآن ومعاني الكلمات) */}
                  {ayah.vocabulary && ayah.vocabulary.length > 0 && (
                    <div className="mt-3 pt-3 border-t border-slate-800/80 flex flex-wrap items-center gap-2">
                      <span className="text-[11px] text-amber-400 font-semibold flex items-center gap-1">
                        <HelpCircle className="w-3 h-3" />
                        <span>معاني المفردات:</span>
                      </span>
                      {ayah.vocabulary.map((vocab, vIdx) => (
                        <button
                          key={vIdx}
                          onClick={() => setSelectedWord(vocab)}
                          className="px-2 py-0.5 rounded-md bg-amber-500/10 hover:bg-amber-500/20 text-amber-300 border border-amber-500/25 text-xs transition-colors"
                        >
                          {vocab.word}
                        </button>
                      ))}
                    </div>
                  )}

                  {/* Tafseer Drawer */}
                  {hasTafseerOpen && (
                    <div className="mt-4 p-4 rounded-xl bg-slate-950/80 border border-amber-500/20 text-right space-y-1.5 animate-fadeIn">
                      <div className="flex items-center justify-between text-xs font-bold text-amber-400">
                        <span>التفسير الميسر - الآية {ayah.ayahNumberInSurah}</span>
                      </div>
                      <p className="text-sm text-slate-200 font-quran leading-relaxed">
                        {ayah.tafseer}
                      </p>
                    </div>
                  )}
                </div>
              );
            })}
          </div>

          {/* Vocabulary Popup Modal */}
          {selectedWord && (
            <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-xs flex items-center justify-center p-4">
              <div className="w-full max-w-md p-6 rounded-3xl bg-slate-900 border border-amber-500/40 text-right space-y-3 shadow-2xl">
                <div className="flex items-center justify-between">
                  <span className="text-xs px-2.5 py-1 rounded-full bg-amber-500/20 text-amber-300 font-semibold">
                    غريب مفردات القرآن
                  </span>
                  <button
                    onClick={() => setSelectedWord(null)}
                    className="p-1 rounded-lg text-slate-400 hover:text-white"
                  >
                    ✕
                  </button>
                </div>
                <h3 className="text-xl font-bold text-amber-200 font-quran">
                  {selectedWord.word}
                </h3>
                <p className="text-sm text-slate-200 leading-relaxed font-quran">
                  {selectedWord.meaning}
                </p>
                <div className="pt-2 flex justify-end">
                  <button
                    onClick={() => setSelectedWord(null)}
                    className="px-4 py-1.5 rounded-xl bg-amber-500 text-slate-950 font-bold text-xs"
                  >
                    فهمت المعنى
                  </button>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
