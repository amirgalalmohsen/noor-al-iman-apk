import React, { useState, useEffect } from 'react';
import { Volume2, VolumeX, RotateCcw, Check, Play, Pause, Sparkles, BookOpen, Search, Info } from 'lucide-react';
import { AZKAR_LIST, DhikrItem } from '../data/azkarData';

interface AzkarSectionProps {
  onAddHasanat: (amount: number, reason: string) => void;
  soundEnabled: boolean;
}

export const AzkarSection: React.FC<AzkarSectionProps> = ({ onAddHasanat, soundEnabled }) => {
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [counts, setCounts] = useState<Record<string, number>>({});
  const [autoDhikrId, setAutoDhikrId] = useState<string | null>(null);
  const [autoSpeed, setAutoSpeed] = useState<number>(2000); // 2 seconds
  const [activeInfoId, setActiveInfoId] = useState<string | null>(null);

  const categories = [
    { id: 'all', label: 'جميع الأذكار' },
    { id: 'morning', label: 'أذكار الصباح' },
    { id: 'evening', label: 'أذكار المساء' },
    { id: 'prayer', label: 'بعد الصلاة' },
    { id: 'sleep', label: 'النوم والاستيقاظ' },
    { id: 'ruqyah', label: 'الرقية الشرعية' },
    { id: 'prophetic', label: 'أدعية نبوية' },
  ];

  const filteredAzkar = AZKAR_LIST.filter((item) => {
    const matchesCategory = selectedCategory === 'all' || item.category === selectedCategory;
    const matchesSearch =
      searchQuery.trim() === '' ||
      item.text.includes(searchQuery) ||
      item.virtueAr.includes(searchQuery);
    return matchesCategory && matchesSearch;
  });

  // Sound chime
  const playChime = () => {
    if (!soundEnabled) return;
    try {
      const audioCtx = new (window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext)();
      const osc = audioCtx.createOscillator();
      const gain = audioCtx.createGain();
      osc.type = 'sine';
      osc.frequency.setValueAtTime(587.33, audioCtx.currentTime); // D5
      osc.frequency.exponentialRampToValueAtTime(880, audioCtx.currentTime + 0.15); // A5
      gain.gain.setValueAtTime(0.15, audioCtx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.001, audioCtx.currentTime + 0.3);
      osc.connect(gain);
      gain.connect(audioCtx.destination);
      osc.start();
      osc.stop(audioCtx.currentTime + 0.35);
    } catch {
      // AudioContext fallback
    }
  };

  const handleIncrement = (item: DhikrItem) => {
    const current = counts[item.id] || 0;
    if (current >= item.targetCount) return;

    const next = current + 1;
    setCounts((prev) => ({ ...prev, [item.id]: next }));
    playChime();

    if (next === item.targetCount) {
      onAddHasanat(item.rewardHasanat, `إتمام ${item.categoryAr}: ${item.text.slice(0, 30)}...`);
    }
  };

  const handleReset = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    setCounts((prev) => ({ ...prev, [id]: 0 }));
    if (autoDhikrId === id) setAutoDhikrId(null);
  };

  // Auto counter loop
  useEffect(() => {
    if (!autoDhikrId) return;
    const item = AZKAR_LIST.find((a) => a.id === autoDhikrId);
    if (!item) return;

    const timer = setInterval(() => {
      setCounts((prev) => {
        const current = prev[item.id] || 0;
        if (current >= item.targetCount) {
          setAutoDhikrId(null);
          return prev;
        }
        const next = current + 1;
        playChime();
        if (next === item.targetCount) {
          onAddHasanat(item.rewardHasanat, `إتمام ${item.categoryAr}`);
          setAutoDhikrId(null);
        }
        return { ...prev, [item.id]: next };
      });
    }, autoSpeed);

    return () => clearInterval(timer);
  }, [autoDhikrId, autoSpeed]);

  const speakDhikr = (text: string, e: React.MouseEvent) => {
    e.stopPropagation();
    if ('speechSynthesis' in window) {
      window.speechSynthesis.cancel();
      const utterance = new SpeechSynthesisUtterance(text);
      utterance.lang = 'ar-SA';
      utterance.rate = 0.85;
      window.speechSynthesis.speak(utterance);
    }
  };

  return (
    <div className="space-y-6">
      {/* Search and Filters Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        {/* Category Tabs */}
        <div className="flex items-center gap-1.5 overflow-x-auto pb-2 md:pb-0 no-scrollbar">
          {categories.map((cat) => (
            <button
              key={cat.id}
              onClick={() => setSelectedCategory(cat.id)}
              className={`px-3.5 py-1.5 rounded-xl text-xs sm:text-sm font-medium whitespace-nowrap transition-colors ${
                selectedCategory === cat.id
                  ? 'bg-amber-500 text-slate-950 font-bold shadow-md shadow-amber-500/10'
                  : 'bg-slate-900 border border-slate-800 text-slate-300 hover:text-white hover:bg-slate-800'
              }`}
            >
              {cat.label}
            </button>
          ))}
        </div>

        {/* Search Bar */}
        <div className="relative w-full md:w-64">
          <Search className="w-4 h-4 absolute right-3 top-1/2 -translate-y-1/2 text-slate-500" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="ابحث في نصوص الأذكار..."
            className="w-full bg-slate-900 border border-slate-800 rounded-xl pr-9 pl-3 py-2 text-xs sm:text-sm text-slate-200 placeholder:text-slate-500 focus:outline-none focus:border-amber-500"
          />
        </div>
      </div>

      {/* Speed Selector for Auto Mode */}
      <div className="flex items-center justify-between px-4 py-2.5 rounded-xl bg-slate-900/50 border border-slate-800 text-xs text-slate-400">
        <div className="flex items-center gap-2">
          <Sparkles className="w-4 h-4 text-amber-400" />
          <span>سرعة العداد التلقائي:</span>
        </div>
        <div className="flex items-center gap-2">
          {[
            { label: 'سريع (1 ث)', speed: 1000 },
            { label: 'متوسط (2 ث)', speed: 2000 },
            { label: 'هادئ (3 ث)', speed: 3000 },
          ].map((s) => (
            <button
              key={s.speed}
              onClick={() => setAutoSpeed(s.speed)}
              className={`px-2.5 py-1 rounded-lg text-[11px] transition-colors ${
                autoSpeed === s.speed
                  ? 'bg-amber-500/20 text-amber-300 border border-amber-500/30'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              {s.label}
            </button>
          ))}
        </div>
      </div>

      {/* Azkar Grid Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {filteredAzkar.map((item) => {
          const currentCount = counts[item.id] || 0;
          const isCompleted = currentCount >= item.targetCount;
          const isAutoPlaying = autoDhikrId === item.id;
          const percentage = Math.min(100, Math.round((currentCount / item.targetCount) * 100));

          return (
            <div
              key={item.id}
              onClick={() => handleIncrement(item)}
              className={`group relative p-5 rounded-2xl border transition-all cursor-pointer select-none flex flex-col justify-between ${
                isCompleted
                  ? 'bg-emerald-950/20 border-emerald-500/40'
                  : 'bg-slate-900/80 border-slate-800 hover:border-amber-500/40 hover:bg-slate-900'
              }`}
            >
              {/* Card Header */}
              <div className="flex items-center justify-between gap-2 mb-3">
                <span className="text-[11px] font-semibold text-amber-400">
                  {item.categoryAr}
                </span>

                <div className="flex items-center gap-1.5" onClick={(e) => e.stopPropagation()}>
                  <button
                    onClick={(e) => speakDhikr(item.text, e)}
                    className="p-1.5 rounded-lg text-slate-400 hover:text-amber-300 hover:bg-slate-800 transition-colors"
                    title="الاستماع الصوتي للذكر"
                  >
                    <Volume2 className="w-3.5 h-3.5" />
                  </button>

                  <button
                    onClick={() => setActiveInfoId(activeInfoId === item.id ? null : item.id)}
                    className="p-1.5 rounded-lg text-slate-400 hover:text-amber-300 hover:bg-slate-800 transition-colors"
                    title="فضل وتخريج الحديث"
                  >
                    <Info className="w-3.5 h-3.5" />
                  </button>

                  <button
                    onClick={() => setAutoDhikrId(isAutoPlaying ? null : item.id)}
                    className={`p-1.5 rounded-lg transition-colors ${
                      isAutoPlaying
                        ? 'bg-amber-500 text-slate-950'
                        : 'text-slate-400 hover:text-amber-300 hover:bg-slate-800'
                    }`}
                    title={isAutoPlaying ? 'إيقاف التسبيح التلقائي' : 'تشغيل التسبيح التلقائي'}
                  >
                    {isAutoPlaying ? <Pause className="w-3.5 h-3.5" /> : <Play className="w-3.5 h-3.5" />}
                  </button>

                  {currentCount > 0 && (
                    <button
                      onClick={(e) => handleReset(item.id, e)}
                      className="p-1.5 rounded-lg text-slate-400 hover:text-rose-400 hover:bg-slate-800 transition-colors"
                      title="إعادة ضبط العداد"
                    >
                      <RotateCcw className="w-3.5 h-3.5" />
                    </button>
                  )}
                </div>
              </div>

              {/* Dhikr Arabic Text */}
              <div className="my-2">
                <p className="font-quran text-lg sm:text-xl text-slate-100 leading-loose text-right">
                  {item.text}
                </p>
              </div>

              {/* Info Drawer when active */}
              {activeInfoId === item.id && (
                <div
                  onClick={(e) => e.stopPropagation()}
                  className="my-3 p-3 rounded-xl bg-amber-500/10 border border-amber-500/25 text-xs text-amber-200/90 space-y-1.5 text-right"
                >
                  <p>
                    <strong className="text-amber-400">فضله: </strong>
                    {item.virtueAr}
                  </p>
                  <p className="text-[11px] text-amber-300/70">
                    <strong className="text-amber-400">التخريج: </strong>
                    {item.sourceAr}
                  </p>
                </div>
              )}

              {/* Progress and Tap Button Footer */}
              <div className="mt-4 pt-3 border-t border-slate-800/80 flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <span className="text-xs text-slate-400">
                    المطلوب:{' '}
                    <strong className="text-slate-200 tabular-nums">{item.targetCount}</strong>
                  </span>
                  <span className="text-[11px] text-emerald-400">+{item.rewardHasanat} حسنة</span>
                </div>

                <div className="flex items-center gap-3">
                  <div className="flex flex-col items-end">
                    <span
                      className={`text-sm font-bold tabular-nums ${
                        isCompleted ? 'text-emerald-400' : 'text-amber-300'
                      }`}
                    >
                      {currentCount} / {item.targetCount}
                    </span>
                    <span className="text-[10px] text-slate-500">انقر للتسبيح</span>
                  </div>

                  {/* Circular visual progress badge */}
                  <div
                    className={`w-10 h-10 rounded-full border-2 flex items-center justify-center font-bold text-xs transition-transform group-active:scale-95 ${
                      isCompleted
                        ? 'border-emerald-500 bg-emerald-500/20 text-emerald-300'
                        : 'border-amber-500/50 bg-amber-500/10 text-amber-300'
                    }`}
                  >
                    {isCompleted ? <Check className="w-5 h-5 text-emerald-400" /> : `${percentage}%`}
                  </div>
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
