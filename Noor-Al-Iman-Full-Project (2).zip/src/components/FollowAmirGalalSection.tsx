import React, { useState } from 'react';
import { Sparkles, ExternalLink, Check, Copy, UserCheck } from 'lucide-react';
import { FacebookIcon, InstagramIcon, XIcon, ThreadsIcon } from './SocialIcons';

interface SocialAccount {
  id: string;
  name: string;
  platformAr: string;
  username: string;
  url: string;
  icon: React.FC<{ className?: string }>;
  tagline: string;
  bgGradient: string;
  borderColor: string;
  hoverBorder: string;
  iconColor: string;
  badgeColor: string;
  btnBg: string;
}

const SOCIAL_ACCOUNTS: SocialAccount[] = [
  {
    id: 'facebook',
    name: 'Facebook',
    platformAr: 'فيسبوك',
    username: 'MR.AmirGalal',
    url: 'https://www.facebook.com/MR.AmirGalal',
    icon: FacebookIcon,
    tagline: 'الصفحة الرسمية والتواصل والتحديثات',
    bgGradient: 'from-blue-950/40 via-slate-900/70 to-slate-950',
    borderColor: 'border-blue-500/30',
    hoverBorder: 'hover:border-blue-400/60',
    iconColor: 'text-blue-400',
    badgeColor: 'bg-blue-500/20 text-blue-300 border-blue-500/30',
    btnBg: 'bg-blue-600 hover:bg-blue-500 text-white',
  },
  {
    id: 'instagram',
    name: 'Instagram',
    platformAr: 'إنستغرام',
    username: 'amir____galal',
    url: 'https://www.instagram.com/amir____galal/',
    icon: InstagramIcon,
    tagline: 'الصور واليوميات والقصص المرئية',
    bgGradient: 'from-pink-950/30 via-purple-950/30 to-slate-950',
    borderColor: 'border-pink-500/30',
    hoverBorder: 'hover:border-pink-400/60',
    iconColor: 'text-pink-400',
    badgeColor: 'bg-gradient-to-r from-pink-500/20 to-purple-500/20 text-pink-300 border-pink-500/30',
    btnBg: 'bg-gradient-to-r from-pink-600 via-purple-600 to-amber-600 hover:opacity-95 text-white',
  },
  {
    id: 'x',
    name: 'X (Twitter)',
    platformAr: 'إكس (تويتر)',
    username: 'amir____galal',
    url: 'https://x.com/amir____galal',
    icon: XIcon,
    tagline: 'الخواطر والتحديثات التقنية والأفكار',
    bgGradient: 'from-slate-900/60 via-slate-900/80 to-slate-950',
    borderColor: 'border-slate-700/50',
    hoverBorder: 'hover:border-amber-400/50',
    iconColor: 'text-slate-100',
    badgeColor: 'bg-slate-800/60 text-slate-200 border-slate-700/50',
    btnBg: 'bg-slate-800 hover:bg-slate-700 text-white border border-slate-700',
  },
  {
    id: 'threads',
    name: 'Threads',
    platformAr: 'ثريدز',
    username: '@amir____galal',
    url: 'https://www.threads.net/@amir____galal',
    icon: ThreadsIcon,
    tagline: 'النقاشات الحية والتفاعل اليومي الهادف',
    bgGradient: 'from-zinc-950 via-slate-900/70 to-zinc-950',
    borderColor: 'border-zinc-700/40',
    hoverBorder: 'hover:border-amber-400/50',
    iconColor: 'text-zinc-100',
    badgeColor: 'bg-zinc-800/60 text-zinc-300 border-zinc-700/50',
    btnBg: 'bg-zinc-800 hover:bg-zinc-700 text-white border border-zinc-700',
  },
];

interface FollowAmirGalalSectionProps {
  variant?: 'full' | 'compact';
  className?: string;
}

export const FollowAmirGalalSection: React.FC<FollowAmirGalalSectionProps> = ({
  variant = 'full',
  className = '',
}) => {
  const [copiedId, setCopiedId] = useState<string | null>(null);

  const handleCopy = (id: string, text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    setTimeout(() => {
      setCopiedId(null);
    }, 2200);
  };

  return (
    <section
      id="follow-amir-galal"
      className={`relative overflow-hidden rounded-3xl bg-gradient-to-br from-slate-950 via-[#0B0B14] to-[#12111D] border border-amber-500/30 p-5 sm:p-7 md:p-8 shadow-2xl transition-all ${className}`}
      dir="rtl"
    >
      {/* Decorative Golden Ambient Glows */}
      <div className="absolute top-0 right-1/4 -mt-20 w-80 h-80 rounded-full bg-amber-500/10 blur-3xl pointer-events-none" />
      <div className="absolute bottom-0 left-1/4 -mb-20 w-80 h-80 rounded-full bg-blue-500/5 blur-3xl pointer-events-none" />

      {/* Header Container */}
      <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-4 pb-6 border-b border-amber-500/20">
        <div className="flex items-center gap-3.5 sm:gap-4">
          {/* Creator Avatar with Golden Rings */}
          <div className="relative group shrink-0">
            <div className="w-16 h-16 sm:w-20 sm:h-20 rounded-2xl bg-gradient-to-br from-amber-300 via-yellow-400 to-amber-600 p-0.5 shadow-lg shadow-amber-500/20 group-hover:scale-105 transition-transform duration-300">
              <img
                src="/amir-galal.svg"
                alt="صورة المصمم أمير جلال"
                className="w-full h-full rounded-[14px] object-cover bg-slate-900"
                onError={(e) => {
                  e.currentTarget.src = '/icon-192.png';
                }}
              />
            </div>
            <div
              className="absolute -bottom-1 -right-1 p-1 bg-emerald-500 text-slate-950 rounded-full shadow-md border-2 border-slate-950"
              title="مطور ومصمم معتمد"
            >
              <UserCheck className="w-3.5 h-3.5" />
            </div>
          </div>

          {/* Title & Creator Info */}
          <div className="space-y-1 text-right">
            <div className="flex items-center gap-2 flex-wrap">
              <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-amber-500/15 border border-amber-500/30 text-amber-300 text-[11px] font-bold font-quran">
                <Sparkles className="w-3 h-3 text-amber-400 animate-pulse" />
                <span>المُصمم والمُطور</span>
              </span>
              <span className="text-xs text-slate-400 font-mono">By Amir Galal</span>
            </div>

            <h3 className="text-xl sm:text-2xl md:text-3xl font-extrabold text-transparent bg-clip-text bg-gradient-to-r from-amber-200 via-yellow-100 to-amber-400 font-quran tracking-wide">
              تابع أمير جلال
            </h3>

            <p className="text-xs sm:text-sm text-slate-300 font-quran max-w-xl leading-relaxed">
              ابقَ على تواصل دائم لمتابعة جديد تحديثات تطبيق «نور الإيمان»، ومشاركة الملاحظات والأفكار، وتصفح أحدث المشروعات والتصميمات.
            </p>
          </div>
        </div>

        {/* Quick Follow Badge */}
        <div className="hidden lg:flex flex-col items-end justify-center shrink-0">
          <div className="px-3.5 py-2 rounded-2xl bg-slate-900/80 border border-slate-800 text-right">
            <span className="block text-[10px] text-amber-400 font-bold uppercase tracking-wider font-mono">
              Official Channels
            </span>
            <span className="text-xs font-semibold text-slate-200 font-quran">
              4 منصات رسمية ومباشرة
            </span>
          </div>
        </div>
      </div>

      {/* Social Cards Grid */}
      <div className="relative z-10 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3.5 sm:gap-4 pt-6">
        {SOCIAL_ACCOUNTS.map((account) => {
          const Icon = account.icon;
          const isCopied = copiedId === account.id;

          return (
            <div
              key={account.id}
              className={`group relative flex flex-col justify-between rounded-2xl bg-gradient-to-br ${account.bgGradient} border ${account.borderColor} ${account.hoverBorder} p-4 sm:p-5 shadow-lg transition-all duration-300 hover:-translate-y-1 hover:shadow-xl hover:shadow-amber-500/5`}
            >
              <div>
                {/* Top Bar with Platform Icon and Badge */}
                <div className="flex items-center justify-between mb-3.5">
                  <div
                    className={`w-11 h-11 rounded-xl bg-slate-900/90 border border-slate-800 flex items-center justify-center ${account.iconColor} shadow-md group-hover:scale-110 transition-transform`}
                  >
                    <Icon className="w-6 h-6" />
                  </div>

                  <span
                    className={`px-2 py-0.5 rounded-md text-[10px] font-bold border font-mono ${account.badgeColor}`}
                  >
                    {account.name}
                  </span>
                </div>

                {/* Handle and Arabic Name */}
                <div className="space-y-1 mb-2 text-right">
                  <div className="flex items-center justify-between">
                    <h4 className="text-sm sm:text-base font-bold text-slate-100 font-quran">
                      {account.platformAr}
                    </h4>

                    {/* Copy Handle Button */}
                    <button
                      onClick={() => handleCopy(account.id, account.username)}
                      title="نسخ اسم الحساب"
                      className="p-1 rounded-md text-slate-400 hover:text-amber-300 hover:bg-slate-800 transition-colors"
                      aria-label={`نسخ اسم مستخدم ${account.name}`}
                    >
                      {isCopied ? (
                        <Check className="w-3.5 h-3.5 text-emerald-400" />
                      ) : (
                        <Copy className="w-3.5 h-3.5" />
                      )}
                    </button>
                  </div>

                  <p
                    className="text-xs font-mono text-amber-300/95 font-semibold tracking-wide truncate"
                    dir="ltr"
                  >
                    {account.username}
                  </p>
                </div>

                <p className="text-[11px] text-slate-300 font-quran line-clamp-2 leading-relaxed mb-4">
                  {account.tagline}
                </p>
              </div>

              {/* Action Button */}
              <a
                href={account.url}
                target="_blank"
                rel="noopener noreferrer"
                className={`w-full py-2.5 px-3 rounded-xl font-bold text-xs flex items-center justify-center gap-1.5 transition-all shadow-md active:scale-95 ${account.btnBg}`}
                title={`فتح حساب ${account.name} لـ أمير جلال في نافذة جديدة`}
              >
                <span>متابعة على {account.platformAr}</span>
                <ExternalLink className="w-3.5 h-3.5 shrink-0 opacity-80" />
              </a>
            </div>
          );
        })}
      </div>

      {/* Footer Info Quote */}
      {variant === 'full' && (
        <div className="relative z-10 mt-6 pt-4 border-t border-slate-900 flex flex-col sm:flex-row items-center justify-between gap-2 text-center sm:text-right text-[11px] text-slate-400 font-quran">
          <p className="text-slate-300">
            «نُورُ الإِيمَان» عمل يبتغي به مصممه أمير جلال الأجر والثواب ونفع أمة المسلمين.
          </p>
          <span className="text-amber-400/90 font-mono font-medium">
            MR.AmirGalal · amir____galal
          </span>
        </div>
      )}
    </section>
  );
};
