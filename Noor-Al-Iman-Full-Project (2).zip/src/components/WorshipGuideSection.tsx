import React, { useState } from 'react';
import { CheckSquare, Square, Check, BookOpen, AlertCircle, Sparkles, ChevronRight, ChevronLeft } from 'lucide-react';
import {
  DAILY_WORSHIP_ITEMS,
  WEEKLY_WORSHIP_ITEMS,
  MONTHLY_WORSHIP_ITEMS,
  WUDHU_STEPS,
  SALAH_STEPS,
  WorshipCheckItem,
  StepGuide,
} from '../data/worshipData';

interface WorshipGuideSectionProps {
  onAddHasanat: (amount: number, reason: string) => void;
}

export const WorshipGuideSection: React.FC<WorshipGuideSectionProps> = ({ onAddHasanat }) => {
  const [activeTab, setActiveTab] = useState<'tracker' | 'wudhu' | 'salah' | 'mistakes'>('tracker');
  const [period, setPeriod] = useState<'daily' | 'weekly' | 'monthly'>('daily');
  const [completedItems, setCompletedItems] = useState<string[]>([]);
  const [activeStepIndex, setActiveStepIndex] = useState<number>(0);

  const toggleCheck = (item: WorshipCheckItem) => {
    if (completedItems.includes(item.id)) {
      setCompletedItems((prev) => prev.filter((id) => id !== item.id));
    } else {
      setCompletedItems((prev) => [...prev, item.id]);
      onAddHasanat(item.rewardLeaves, `إنجاز عبادة: ${item.titleAr}`);
    }
  };

  const currentList =
    period === 'daily'
      ? DAILY_WORSHIP_ITEMS
      : period === 'weekly'
      ? WEEKLY_WORSHIP_ITEMS
      : MONTHLY_WORSHIP_ITEMS;

  const completedCount = currentList.filter((i) => completedItems.includes(i.id)).length;
  const progressPercent = Math.round((completedCount / currentList.length) * 100);

  return (
    <div className="space-y-6">
      {/* Navigation Sub-Tabs */}
      <div className="flex items-center gap-2 overflow-x-auto pb-2 no-scrollbar">
        {[
          { id: 'tracker', label: 'جدول محاسبة العبادات' },
          { id: 'wudhu', label: 'دليل صفة الوضوء الصحيح' },
          { id: 'salah', label: 'صفة صلاة النبي ﷺ' },
          { id: 'mistakes', label: 'أخطاء شائعة وتصحيحها' },
        ].map((tab) => (
          <button
            key={tab.id}
            onClick={() => {
              setActiveTab(tab.id as typeof activeTab);
              setActiveStepIndex(0);
            }}
            className={`px-4 py-2 rounded-xl text-xs sm:text-sm font-semibold whitespace-nowrap transition-colors ${
              activeTab === tab.id
                ? 'bg-amber-500 text-slate-950 shadow-md shadow-amber-500/20'
                : 'bg-slate-900 border border-slate-800 text-slate-300 hover:bg-slate-800'
            }`}
          >
            {tab.label}
          </button>
        ))}
      </div>

      {/* 1. WORSHIP SCHEDULE & TRACKER TAB */}
      {activeTab === 'tracker' && (
        <div className="space-y-6">
          {/* Period Selector & Progress */}
          <div className="p-6 rounded-3xl bg-slate-900/80 border border-slate-800 flex flex-col md:flex-row md:items-center justify-between gap-4">
            <div className="flex items-center gap-2">
              {[
                { id: 'daily', label: 'العبادات اليومية والسنن' },
                { id: 'weekly', label: 'العبادات الأسبوعية (الجمعة والصيام)' },
                { id: 'monthly', label: 'العبادات الشهرية (الأيام البيض والختمة)' },
              ].map((p) => (
                <button
                  key={p.id}
                  onClick={() => setPeriod(p.id as typeof period)}
                  className={`px-3 py-1.5 rounded-xl text-xs font-medium transition-colors ${
                    period === p.id
                      ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40'
                      : 'bg-slate-800 text-slate-400 hover:text-white'
                  }`}
                >
                  {p.label}
                </button>
              ))}
            </div>

            {/* Completion Percentage */}
            <div className="flex items-center gap-3">
              <div className="text-right">
                <span className="text-xs text-slate-400">نسبة الإنجاز:</span>
                <div className="text-lg font-bold text-amber-300 tabular-nums">
                  {completedCount} / {currentList.length} ({progressPercent}%)
                </div>
              </div>
              <div className="w-12 h-12 rounded-full border-2 border-amber-500/30 flex items-center justify-center font-bold text-xs text-amber-300">
                {progressPercent}%
              </div>
            </div>
          </div>

          {/* Checklist Items */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            {currentList.map((item) => {
              const isChecked = completedItems.includes(item.id);

              return (
                <div
                  key={item.id}
                  onClick={() => toggleCheck(item)}
                  className={`p-4 rounded-2xl border transition-all cursor-pointer flex items-start gap-3 select-none text-right ${
                    isChecked
                      ? 'bg-emerald-950/20 border-emerald-500/40 text-emerald-100'
                      : 'bg-slate-900/70 border-slate-800 hover:border-slate-700 hover:bg-slate-900 text-slate-200'
                  }`}
                >
                  <button
                    className={`mt-1 p-1 rounded-lg border transition-colors ${
                      isChecked
                        ? 'bg-emerald-500 border-emerald-400 text-slate-950'
                        : 'border-slate-700 text-transparent'
                    }`}
                  >
                    <Check className="w-3.5 h-3.5" />
                  </button>

                  <div className="flex-1 space-y-1">
                    <div className="flex items-center justify-between">
                      <span className="text-sm font-bold font-quran">{item.titleAr}</span>
                      <span className="text-xs text-amber-400 font-semibold">
                        +{item.rewardLeaves} ورقة ذهبية
                      </span>
                    </div>
                    <p className="text-xs text-slate-400 leading-relaxed">
                      {item.descriptionAr}
                    </p>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* 2. WUDHU STEP-BY-STEP TAB */}
      {activeTab === 'wudhu' && (
        <div className="space-y-6">
          <div className="p-6 rounded-3xl bg-slate-900/80 border border-slate-800 text-right">
            <span className="text-xs font-bold text-amber-400">
              خطوة {activeStepIndex + 1} من {WUDHU_STEPS.length}
            </span>
            <h2 className="text-2xl font-extrabold text-amber-200 font-quran mt-1">
              {WUDHU_STEPS[activeStepIndex].titleAr}
            </h2>
            <p className="text-sm text-slate-200 mt-2 leading-relaxed">
              {WUDHU_STEPS[activeStepIndex].descriptionAr}
            </p>

            {WUDHU_STEPS[activeStepIndex].duaAr && (
              <div className="mt-4 p-4 rounded-2xl bg-amber-500/10 border border-amber-500/25">
                <span className="text-xs font-semibold text-amber-400 block mb-1">
                  الذكر أو الدعاء المشروع:
                </span>
                <p className="text-lg font-quran text-amber-100">
                  {WUDHU_STEPS[activeStepIndex].duaAr}
                </p>
              </div>
            )}

            <div className="mt-4 grid grid-cols-1 md:grid-cols-2 gap-3 text-xs">
              <div className="p-3 rounded-xl bg-slate-950 border border-emerald-500/20 text-emerald-300">
                <strong className="block text-emerald-400 mb-0.5">من سنن هذه الخطوة:</strong>
                {WUDHU_STEPS[activeStepIndex].sunnahNotesAr}
              </div>

              {WUDHU_STEPS[activeStepIndex].mistakeAvoidAr && (
                <div className="p-3 rounded-xl bg-slate-950 border border-rose-500/20 text-rose-300">
                  <strong className="block text-rose-400 mb-0.5">احذر هذا الخطأ:</strong>
                  {WUDHU_STEPS[activeStepIndex].mistakeAvoidAr}
                </div>
              )}
            </div>

            {/* Navigation buttons */}
            <div className="flex items-center justify-between mt-6 pt-4 border-t border-slate-800">
              <button
                onClick={() => setActiveStepIndex((prev) => Math.max(0, prev - 1))}
                disabled={activeStepIndex === 0}
                className="px-4 py-2 rounded-xl bg-slate-800 text-slate-300 disabled:opacity-30 text-xs font-medium"
              >
                الخطوة السابقة
              </button>

              <button
                onClick={() =>
                  setActiveStepIndex((prev) => Math.min(WUDHU_STEPS.length - 1, prev + 1))
                }
                disabled={activeStepIndex === WUDHU_STEPS.length - 1}
                className="px-4 py-2 rounded-xl bg-amber-500 text-slate-950 font-bold disabled:opacity-30 text-xs"
              >
                الخطوة التالية
              </button>
            </div>
          </div>

          {/* Quick Step Indicators */}
          <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-8 gap-2">
            {WUDHU_STEPS.map((step, idx) => (
              <button
                key={step.stepNumber}
                onClick={() => setActiveStepIndex(idx)}
                className={`p-2.5 rounded-xl border text-center transition-colors ${
                  activeStepIndex === idx
                    ? 'bg-amber-500/20 border-amber-500 text-amber-200 font-bold'
                    : 'bg-slate-900 border-slate-800 text-slate-400 hover:text-white'
                }`}
              >
                <span className="block text-[10px] text-slate-500">خطوة {step.stepNumber}</span>
                <span className="text-xs truncate block">{step.titleAr.slice(0, 14)}</span>
              </button>
            ))}
          </div>
        </div>
      )}

      {/* 3. SALAH STEP-BY-STEP TAB */}
      {activeTab === 'salah' && (
        <div className="space-y-6">
          <div className="p-6 rounded-3xl bg-slate-900/80 border border-slate-800 text-right">
            <span className="text-xs font-bold text-amber-400">
              ركن {activeStepIndex + 1} من {SALAH_STEPS.length}
            </span>
            <h2 className="text-2xl font-extrabold text-amber-200 font-quran mt-1">
              {SALAH_STEPS[activeStepIndex].titleAr}
            </h2>
            <p className="text-sm text-slate-200 mt-2 leading-relaxed">
              {SALAH_STEPS[activeStepIndex].descriptionAr}
            </p>

            {SALAH_STEPS[activeStepIndex].duaAr && (
              <div className="mt-4 p-4 rounded-2xl bg-amber-500/10 border border-amber-500/25">
                <span className="text-xs font-semibold text-amber-400 block mb-1">
                  الذكر أو الدعاء المأثور:
                </span>
                <p className="text-lg font-quran text-amber-100">
                  {SALAH_STEPS[activeStepIndex].duaAr}
                </p>
              </div>
            )}

            <div className="mt-4 grid grid-cols-1 md:grid-cols-2 gap-3 text-xs">
              <div className="p-3 rounded-xl bg-slate-950 border border-emerald-500/20 text-emerald-300">
                <strong className="block text-emerald-400 mb-0.5">من هدي النبي ﷺ في هذا الركن:</strong>
                {SALAH_STEPS[activeStepIndex].sunnahNotesAr}
              </div>

              {SALAH_STEPS[activeStepIndex].mistakeAvoidAr && (
                <div className="p-3 rounded-xl bg-slate-950 border border-rose-500/20 text-rose-300">
                  <strong className="block text-rose-400 mb-0.5">خطأ يجب تجنبه:</strong>
                  {SALAH_STEPS[activeStepIndex].mistakeAvoidAr}
                </div>
              )}
            </div>

            {/* Navigation buttons */}
            <div className="flex items-center justify-between mt-6 pt-4 border-t border-slate-800">
              <button
                onClick={() => setActiveStepIndex((prev) => Math.max(0, prev - 1))}
                disabled={activeStepIndex === 0}
                className="px-4 py-2 rounded-xl bg-slate-800 text-slate-300 disabled:opacity-30 text-xs font-medium"
              >
                الركن السابق
              </button>

              <button
                onClick={() =>
                  setActiveStepIndex((prev) => Math.min(SALAH_STEPS.length - 1, prev + 1))
                }
                disabled={activeStepIndex === SALAH_STEPS.length - 1}
                className="px-4 py-2 rounded-xl bg-amber-500 text-slate-950 font-bold disabled:opacity-30 text-xs"
              >
                الركن التالي
              </button>
            </div>
          </div>

          {/* Quick Step Indicators */}
          <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-8 gap-2">
            {SALAH_STEPS.map((step, idx) => (
              <button
                key={step.stepNumber}
                onClick={() => setActiveStepIndex(idx)}
                className={`p-2.5 rounded-xl border text-center transition-colors ${
                  activeStepIndex === idx
                    ? 'bg-amber-500/20 border-amber-500 text-amber-200 font-bold'
                    : 'bg-slate-900 border-slate-800 text-slate-400 hover:text-white'
                }`}
              >
                <span className="block text-[10px] text-slate-500">ركن {step.stepNumber}</span>
                <span className="text-xs truncate block">{step.titleAr.slice(0, 14)}</span>
              </button>
            ))}
          </div>
        </div>
      )}

      {/* 4. COMMON MISTAKES TAB */}
      {activeTab === 'mistakes' && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-right">
          {[
            {
              title: 'نقرة الغراب (عدم الطمأنينة)',
              category: 'الصلاة',
              description: 'الاستعجال في الركوع والسجود دون استقرار المفاصل والعظام، وقد قال النبي ﷺ للرجل: «ارجع فصلِّ فإنك لم تصلِّ».',
              correction: 'التريث والاطمئنان في كل ركن بقدر ما تقول الذكر ثلاث مرات بهدوء وخشوع.'
            },
            {
              title: 'ترك غسل الكعبين أو الأعقاب في الوضوء',
              category: 'الوضوء',
              description: 'إهمال وصول الماء إلى العقب وأسفل القدم مما يبطل الوضوء والصلاة، قال النبي ﷺ: «ويل للأعقاب من النار».',
              correction: 'إسباغ الوضوء وتمرير اليد على مؤخرة القدم والكعبين والتأكد من بللها التام.'
            },
            {
              title: 'مسابقة الإمام في الصلاة',
              category: 'صلاة الجماعة',
              description: 'الركوع أو السجود قبل الإمام أو معه تماماً، وهو أمر منهي عنه ومبطل للصلاة.',
              correction: 'متابعة الإمام بعد أن ينقطع صوته بالتكبير، قال ﷺ: «إنما جُعل الإمام ليؤتم به فإذا كبّر فكبّروا».'
            },
            {
              title: 'التلفظ بالنية جهراً',
              category: 'الطهارة والصلاة',
              description: 'قول «نويت أن أصلي كذا ركعات» بصوت مسموع، وهو لم يثبت عن رسول الله ﷺ ولا صحابته.',
              correction: 'النية محلها القلب الخالص بمجرد قيامك للوضوء أو وقوفك في الصف متوجهاً للقبلة.'
            }
          ].map((m, idx) => (
            <div key={idx} className="p-5 rounded-2xl bg-slate-900/80 border border-slate-800 space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-xs px-2 py-0.5 rounded-full bg-rose-500/10 text-rose-400 border border-rose-500/20 font-semibold">
                  {m.category}
                </span>
                <AlertCircle className="w-4 h-4 text-rose-400" />
              </div>
              <h3 className="text-base font-bold text-amber-200 font-quran">{m.title}</h3>
              <p className="text-xs text-slate-300 leading-relaxed">{m.description}</p>
              <div className="mt-2 pt-2 border-t border-slate-800 text-xs text-emerald-300">
                <strong className="text-emerald-400">التصحيح السني: </strong>
                {m.correction}
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};
