import React, { useState, useEffect } from 'react';
import { Compass, MapPin, Navigation, Sparkles, CheckCircle2 } from 'lucide-react';
import { calculateQiblaBearing, calculateDistanceToKaaba, getCardinalDirection, FAMOUS_CITIES, CityLocation } from '../utils/qibla';

export const QiblaSection: React.FC = () => {
  const [selectedCity, setSelectedCity] = useState<CityLocation>(FAMOUS_CITIES[2]); // Cairo default
  const [userCoords, setUserCoords] = useState<{ lat: number; lng: number }>({
    lat: FAMOUS_CITIES[2].lat,
    lng: FAMOUS_CITIES[2].lng
  });
  const [locationName, setLocationName] = useState<string>('القاهرة، مصر');
  const [isLocating, setIsLocating] = useState<boolean>(false);
  const [deviceHeading, setDeviceHeading] = useState<number>(0);
  const [hasCompassSupport, setHasCompassSupport] = useState<boolean>(false);

  const qiblaBearing = calculateQiblaBearing(userCoords.lat, userCoords.lng);
  const distanceKm = calculateDistanceToKaaba(userCoords.lat, userCoords.lng);
  const cardinalDirection = getCardinalDirection(qiblaBearing);

  // Compass needle rotation relative to True North or Device orientation
  const needleRotation = (qiblaBearing - deviceHeading + 360) % 360;
  const isAligned = Math.abs(needleRotation) < 5 || Math.abs(needleRotation - 360) < 5;

  const handleSelectCity = (city: CityLocation) => {
    setSelectedCity(city);
    setUserCoords({ lat: city.lat, lng: city.lng });
    setLocationName(`${city.nameAr}، ${city.country}`);
  };

  const [locationError, setLocationError] = useState<string | null>(null);

  const handleGetCurrentLocation = () => {
    setLocationError(null);
    if (!navigator.geolocation) {
      setLocationError('خدمة تحديد الموقع الجغرافي غير مدعومة في متصفح جهازك');
      return;
    }
    setIsLocating(true);
    navigator.geolocation.getCurrentPosition(
      (pos) => {
        setIsLocating(false);
        setUserCoords({ lat: pos.coords.latitude, lng: pos.coords.longitude });
        setLocationName('موقعي الجغرافي الحالي');
      },
      (err) => {
        setIsLocating(false);
        setLocationError('تعذر تحديد الموقع الجغرافي تلقائياً، يمكنك اختيار مدينتك من القائمة أدناه');
        console.warn('Geolocation error:', err.message);
      },
      { timeout: 8000 }
    );
  };

  // Device orientation event for mobile compass
  useEffect(() => {
    const handleOrientation = (e: DeviceOrientationEvent) => {
      if (e.alpha !== null) {
        setHasCompassSupport(true);
        // alpha represents rotation around z-axis in degrees [0, 360]
        setDeviceHeading(360 - e.alpha);
      }
    };

    if (window.DeviceOrientationEvent) {
      window.addEventListener('deviceorientation', handleOrientation, true);
    }

    return () => {
      window.removeEventListener('deviceorientation', handleOrientation, true);
    };
  }, []);

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      {/* Header Banner */}
      <div className="p-6 rounded-3xl bg-slate-900/80 border border-slate-800 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <span className="text-xs font-semibold text-amber-400">
            تحديد القبلة الشريفة بدقة فلكية
          </span>
          <h2 className="text-2xl font-bold text-amber-100 font-quran mt-0.5">
            بوصلة الكعبة المشرفة في مكة المكرمة
          </h2>
          <p className="text-xs text-slate-400 mt-1">
            الموقع الحالي:{' '}
            <strong className="text-amber-300 font-medium">{locationName}</strong>
          </p>
        </div>

        <button
          onClick={handleGetCurrentLocation}
          disabled={isLocating}
          className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-slate-950 font-bold text-xs sm:text-sm shadow-md transition-all self-start md:self-center"
        >
          <Navigation className={`w-4 h-4 ${isLocating ? 'animate-spin' : ''}`} />
          <span>{isLocating ? 'جارٍ تحديد الموقع...' : 'تحديد موقعي تلقائياً'}</span>
        </button>
      </div>

      {locationError && (
        <div className="p-3 rounded-xl bg-amber-500/15 border border-amber-500/30 text-amber-200 text-xs font-quran text-center">
          {locationError}
        </div>
      )}

      {/* Main Compass Surface and Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-12 gap-6 items-center">
        {/* Compass Visual Dial */}
        <div className="md:col-span-7 flex flex-col items-center">
          <div
            className={`relative w-72 h-72 sm:w-80 sm:h-80 rounded-full border-4 p-4 shadow-2xl flex items-center justify-center transition-all ${
              isAligned
                ? 'border-emerald-500 bg-emerald-950/20 shadow-emerald-500/20'
                : 'border-amber-500/40 bg-slate-950 shadow-amber-500/10'
            }`}
          >
            {/* Outer Cardinal Ring */}
            <div className="absolute inset-2 rounded-full border border-dashed border-amber-500/20 pointer-events-none" />

            {/* Cardinal Letters */}
            <div className="absolute top-3 text-xs font-bold text-slate-400 font-mono">ش (N)</div>
            <div className="absolute bottom-3 text-xs font-bold text-slate-400 font-mono">ج (S)</div>
            <div className="absolute right-3 text-xs font-bold text-slate-400 font-mono">ق (E)</div>
            <div className="absolute left-3 text-xs font-bold text-slate-400 font-mono">غ (W)</div>

            {/* Rotating Qibla Arrow Dial */}
            <div
              className="absolute inset-0 flex items-center justify-center transition-transform duration-500"
              style={{ transform: `rotate(${needleRotation}deg)` }}
            >
              <div className="flex flex-col items-center h-full justify-between py-6">
                {/* Kaaba Golden Needle Head */}
                <div className="flex flex-col items-center">
                  <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-amber-300 via-amber-500 to-amber-700 p-0.5 shadow-lg shadow-amber-500/30 flex items-center justify-center animate-bounce">
                    <div className="w-full h-full bg-slate-950 rounded-[10px] flex items-center justify-center text-[10px] text-amber-300 font-bold">
                      🕋
                    </div>
                  </div>
                  <div className="w-1.5 h-16 bg-gradient-to-b from-amber-400 to-amber-600 rounded-full" />
                </div>

                {/* Needle Base */}
                <div className="w-1.5 h-16 bg-slate-700 rounded-full opacity-60" />
              </div>
            </div>

            {/* Center Dial Hub */}
            <div className="z-10 w-12 h-12 rounded-full bg-slate-900 border-2 border-amber-400 flex items-center justify-center shadow-lg">
              <Compass className="w-5 h-5 text-amber-300" />
            </div>

            {/* Alignment Confirmed Pill */}
            {isAligned && (
              <div className="absolute bottom-6 px-3 py-1 rounded-full bg-emerald-500 text-slate-950 text-xs font-bold flex items-center gap-1 shadow-md">
                <CheckCircle2 className="w-3.5 h-3.5" />
                <span>أنت باتجاه الكعبة المشرفة</span>
              </div>
            )}
          </div>

          <p className="text-xs text-slate-400 mt-4 text-center">
            {hasCompassSupport
              ? 'البوصلة متصلة بمستشعر هاتفك مباشرة'
              : 'قم بتوجيه أعلى الهاتف أو الشاشة نحو زاوية القبلة'}
          </p>
        </div>

        {/* Direction Metrics & City Quick Select */}
        <div className="md:col-span-5 space-y-4 text-right">
          <div className="p-4 rounded-2xl bg-slate-900/80 border border-slate-800 space-y-3">
            <div>
              <span className="text-xs text-slate-400">زاوية القبلة:</span>
              <div className="text-3xl font-extrabold text-amber-300 font-mono tabular-nums">
                {qiblaBearing}°
              </div>
              <p className="text-xs text-slate-300 mt-0.5">
                الاتجاه:{' '}
                <strong className="text-amber-200">{cardinalDirection}</strong>
              </p>
            </div>

            <div className="pt-2 border-t border-slate-800">
              <span className="text-xs text-slate-400">المسافة إلى الكعبة المشرفة:</span>
              <div className="text-2xl font-bold text-emerald-400 font-mono tabular-nums">
                {distanceKm.toLocaleString('ar-EG')} كم
              </div>
            </div>
          </div>

          {/* Quick Famous Cities Picker */}
          <div className="p-4 rounded-2xl bg-slate-900/80 border border-slate-800 space-y-2">
            <span className="text-xs font-bold text-amber-400 flex items-center gap-1.5">
              <MapPin className="w-3.5 h-3.5" />
              <span>اختر مدينتك:</span>
            </span>
            <div className="flex flex-wrap gap-1.5 max-h-48 overflow-y-auto no-scrollbar pt-1">
              {FAMOUS_CITIES.map((city) => (
                <button
                  key={city.nameEn}
                  onClick={() => handleSelectCity(city)}
                  className={`px-2.5 py-1 rounded-lg text-xs transition-colors ${
                    selectedCity.nameEn === city.nameEn
                      ? 'bg-amber-500 text-slate-950 font-bold'
                      : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
                  }`}
                >
                  {city.nameAr}
                </button>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
