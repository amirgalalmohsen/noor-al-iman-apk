import React, { useState } from 'react';
import { Sparkles, MessageSquare, Send, Bot, User, X, BookOpen } from 'lucide-react';
import { GoogleGenAI } from '@google/genai';

interface Message {
  role: 'user' | 'assistant';
  content: string;
}

interface GeminiReflectionsModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const GeminiReflectionsModal: React.FC<GeminiReflectionsModalProps> = ({ isOpen, onClose }) => {
  const [messages, setMessages] = useState<Message[]>([
    {
      role: 'assistant',
      content:
        'مرحباً بك في المستشار القرآني والروحي الذكي. يسعدني مساعدتك في تدبر آيات القرآن الكريم، شرح معاني المفردات، أو تقديم نصائح نبوية مباركة لتعزيز عبادتك.',
    },
  ]);
  const [inputQuery, setInputQuery] = useState<string>('');
  const [isLoading, setIsLoading] = useState<boolean>(false);

  if (!isOpen) return null;

  const quickPrompts = [
    'تأمل في قول الله: {وَاصْبِرْ لِحُكْمِ رَبِّكَ فَإِنَّكَ بِأَعْيُنِنَا}',
    'كيف أستحضر الخشوع في صلاتي وأطرد الوساوس؟',
    'ما فضل الاستغفار وأثره في تفريج الكروب؟',
    'ما هي معاني أسماء الله الحسنى: الصمد، الغفور، الودود؟',
  ];

  const handleSend = async (userText: string) => {
    if (!userText.trim() || isLoading) return;

    const newMessages: Message[] = [...messages, { role: 'user', content: userText.trim() }];
    setMessages(newMessages);
    setInputQuery('');
    setIsLoading(true);

    try {
      const apiKey = process.env.GEMINI_API_KEY;
      if (apiKey) {
        const ai = new GoogleGenAI();
        const systemInstruction = `أنت مساعد إسلامي وقرآني متخصص، رقيق القلب، عالم بالكتاب والسنة بفهم السلف الصالح. أسلوبك رقيق ومؤنس ويدعو للطمأنينة والتفاؤل، تذكر الآيات والأحاديث الصحيحة مع تخريجها، وتتكلم باللغة العربية الفصحى الجميلة.`;

        const res = await ai.models.generateContent({
          model: 'gemini-2.5-flash',
          contents: userText.trim(),
          config: {
            systemInstruction,
          },
        });

        const reply = res.text || 'الحمد لله والصلاة والسلام على رسول الله. نسأل الله أن يبارك فيك وينفعك بكتابه العزيز.';
        setMessages([...newMessages, { role: 'assistant', content: reply }]);
      } else {
        // Fallback spiritual reflection
        setTimeout(() => {
          setMessages([
            ...newMessages,
            {
              role: 'assistant',
              content: `بارك الله في حرصك المبارك على تدبر كتاب الله وسنة رسوله ﷺ. تذكر دائماً أن أعظم ما يقربك إلى الله هو صدق النية ودوام الذكر؛ قال تعالى: {أَلَا بِذِكْرِ اللَّهِ تَطْمَئِنُّ الْقُلُوبُ}. اجعل لك ورداً يومياً لا تغفل عنه من القرآن والأذكار تفتح لك أبواب الخير والسكينة.`,
            },
          ]);
        }, 600);
      }
    } catch {
      setMessages([
        ...newMessages,
        {
          role: 'assistant',
          content:
            'قال رسول الله ﷺ: «مَنْ سَلَكَ طَرِيقًا يَلْتَمِسُ فِيهِ عِلْمًا، سَهَّلَ اللَّهُ لَهُ بِهِ طَرِيقًا إِلَى الْجَنَّةِ». نسأل الله أن يرزقنا وإياك العلم النافع والعمل الصالح.',
        },
      ]);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/75 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="w-full max-w-2xl bg-slate-900 border border-amber-500/40 rounded-3xl shadow-2xl flex flex-col max-h-[85vh] text-right overflow-hidden">
        {/* Header */}
        <div className="p-4 sm:p-5 border-b border-slate-800 flex items-center justify-between bg-slate-950/80">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-amber-500/20 border border-amber-500/40 flex items-center justify-center text-amber-300">
              <Sparkles className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-bold text-amber-200 font-quran">
                التأملات القرآنية والاستفسارات الروحية
              </h3>
              <p className="text-[11px] text-slate-400">
                مدعوم بالذكاء الاصطناعي لتدبر كتاب الله والأحاديث النبوية
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Messages Stream */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-5 space-y-4">
          {messages.map((m, idx) => (
            <div
              key={idx}
              className={`flex items-start gap-3 ${
                m.role === 'user' ? 'flex-row-reverse' : 'flex-row'
              }`}
            >
              <div
                className={`w-8 h-8 rounded-xl flex items-center justify-center shrink-0 ${
                  m.role === 'user'
                    ? 'bg-amber-500 text-slate-950'
                    : 'bg-emerald-950 border border-emerald-500/30 text-emerald-300'
                }`}
              >
                {m.role === 'user' ? <User className="w-4 h-4" /> : <Bot className="w-4 h-4" />}
              </div>

              <div
                className={`p-4 rounded-2xl max-w-[85%] text-xs sm:text-sm font-quran leading-relaxed ${
                  m.role === 'user'
                    ? 'bg-amber-500/20 text-amber-100 border border-amber-500/30 rounded-tr-none'
                    : 'bg-slate-950 border border-slate-800 text-slate-200 rounded-tl-none whitespace-pre-line'
                }`}
              >
                {m.content}
              </div>
            </div>
          ))}

          {isLoading && (
            <div className="flex items-center gap-2 text-xs text-amber-400 p-2">
              <Sparkles className="w-4 h-4 animate-spin" />
              <span>جارٍ استحضار التأمل القرآني المبارك...</span>
            </div>
          )}
        </div>

        {/* Quick Prompts */}
        <div className="p-3 border-t border-slate-800 bg-slate-950/40 overflow-x-auto no-scrollbar flex items-center gap-1.5">
          {quickPrompts.map((qp, qIdx) => (
            <button
              key={qIdx}
              onClick={() => handleSend(qp)}
              className="px-2.5 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 text-[11px] whitespace-nowrap transition-colors shrink-0"
            >
              {qp}
            </button>
          ))}
        </div>

        {/* Input bar */}
        <div className="p-4 border-t border-slate-800 bg-slate-950">
          <form
            onSubmit={(e) => {
              e.preventDefault();
              handleSend(inputQuery);
            }}
            className="flex items-center gap-2"
          >
            <input
              type="text"
              value={inputQuery}
              onChange={(e) => setInputQuery(e.target.value)}
              placeholder="اكتب سؤالك أو الآية التي ترغب في تدبرها..."
              className="flex-1 bg-slate-900 border border-slate-800 rounded-xl px-4 py-2.5 text-xs sm:text-sm text-slate-100 placeholder:text-slate-500 focus:outline-none focus:border-amber-500"
            />
            <button
              type="submit"
              disabled={isLoading || !inputQuery.trim()}
              className="p-2.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 disabled:opacity-40 transition-colors font-bold"
            >
              <Send className="w-4 h-4" />
            </button>
          </form>
        </div>
      </div>
    </div>
  );
};
