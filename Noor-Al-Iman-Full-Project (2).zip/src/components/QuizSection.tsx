import React, { useState } from 'react';
import { HelpCircle, CheckCircle2, XCircle, Sparkles, RotateCcw, Trophy, ArrowLeft } from 'lucide-react';
import { QUIZ_QUESTIONS, QuizQuestion } from '../data/quizData';

interface QuizSectionProps {
  onAddHasanat: (amount: number, reason: string) => void;
}

export const QuizSection: React.FC<QuizSectionProps> = ({ onAddHasanat }) => {
  const [currentIndex, setCurrentIndex] = useState<number>(0);
  const [selectedOption, setSelectedOption] = useState<number | null>(null);
  const [isAnswered, setIsAnswered] = useState<boolean>(false);
  const [score, setScore] = useState<number>(0);
  const [quizFinished, setQuizFinished] = useState<boolean>(false);

  const currentQ: QuizQuestion = QUIZ_QUESTIONS[currentIndex];

  const handleSelectOption = (index: number) => {
    if (isAnswered) return;
    setSelectedOption(index);
    setIsAnswered(true);

    if (index === currentQ.correctIndex) {
      setScore((prev) => prev + 1);
      onAddHasanat(currentQ.rewardLeaves, `إجابة صحيحة في مسابقة: ${currentQ.questionAr}`);
    }
  };

  const handleNext = () => {
    if (currentIndex < QUIZ_QUESTIONS.length - 1) {
      setCurrentIndex((prev) => prev + 1);
      setSelectedOption(null);
      setIsAnswered(false);
    } else {
      setQuizFinished(true);
    }
  };

  const handleRestart = () => {
    setCurrentIndex(0);
    setSelectedOption(null);
    setIsAnswered(false);
    setScore(0);
    setQuizFinished(false);
  };

  return (
    <div className="max-w-3xl mx-auto space-y-6">
      {/* Quiz Header */}
      <div className="p-6 rounded-3xl bg-slate-900/80 border border-slate-800 text-right flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <span className="text-xs font-semibold text-amber-400">
            مسابقات واختبارات إسلامية تفاعلية
          </span>
          <h2 className="text-2xl font-bold text-amber-100 font-quran mt-0.5">
            اختبر معلوماتك الدينية واغرس في شجرة الذهب
          </h2>
        </div>

        <div className="flex items-center gap-3">
          <div className="px-3.5 py-1.5 rounded-xl bg-amber-500/15 border border-amber-500/30 text-amber-300 text-xs font-bold tabular-nums">
            النتيجة: {score} من {QUIZ_QUESTIONS.length}
          </div>
        </div>
      </div>

      {!quizFinished ? (
        <div className="p-6 sm:p-8 rounded-3xl bg-slate-900/90 border border-slate-800 text-right space-y-6 shadow-xl">
          {/* Progress bar */}
          <div className="space-y-1.5">
            <div className="flex items-center justify-between text-xs text-slate-400">
              <span>السؤال {currentIndex + 1} من {QUIZ_QUESTIONS.length}</span>
              <span className="text-amber-400 font-bold">{currentQ.categoryAr}</span>
            </div>
            <div className="w-full h-2 rounded-full bg-slate-950 overflow-hidden">
              <div
                className="h-full bg-gradient-to-r from-amber-600 to-amber-400 transition-all rounded-full"
                style={{ width: `${((currentIndex + 1) / QUIZ_QUESTIONS.length) * 100}%` }}
              />
            </div>
          </div>

          {/* Question Text */}
          <div className="my-4">
            <h3 className="text-xl sm:text-2xl font-extrabold text-amber-100 font-quran leading-relaxed">
              {currentQ.questionAr}
            </h3>
          </div>

          {/* Options Grid */}
          <div className="space-y-3">
            {currentQ.optionsAr.map((option, idx) => {
              const isSelected = selectedOption === idx;
              const isCorrect = idx === currentQ.correctIndex;

              let btnStyle = 'bg-slate-950/80 border-slate-800 text-slate-200 hover:border-amber-500/40';

              if (isAnswered) {
                if (isCorrect) {
                  btnStyle = 'bg-emerald-950/50 border-emerald-500 text-emerald-200 font-bold';
                } else if (isSelected) {
                  btnStyle = 'bg-rose-950/50 border-rose-500 text-rose-200';
                } else {
                  btnStyle = 'bg-slate-950/40 border-slate-900 text-slate-500 opacity-60';
                }
              }

              return (
                <button
                  key={idx}
                  onClick={() => handleSelectOption(idx)}
                  disabled={isAnswered}
                  className={`w-full p-4 rounded-2xl border text-right transition-all flex items-center justify-between text-sm sm:text-base font-quran ${btnStyle}`}
                >
                  <span>{option}</span>
                  {isAnswered && (
                    <span>
                      {isCorrect ? (
                        <CheckCircle2 className="w-5 h-5 text-emerald-400" />
                      ) : isSelected ? (
                        <XCircle className="w-5 h-5 text-rose-400" />
                      ) : null}
                    </span>
                  )}
                </button>
              );
            })}
          </div>

          {/* Explanation Box when answered */}
          {isAnswered && (
            <div className="p-4 rounded-2xl bg-amber-500/10 border border-amber-500/25 space-y-1.5 animate-fadeIn">
              <span className="text-xs font-bold text-amber-400 block">
                {selectedOption === currentQ.correctIndex ? 'أحسنت! إجابة صحيحة ✨' : 'توضيح الإجابة الصحيحة:'}
              </span>
              <p className="text-sm text-slate-200 font-quran leading-relaxed">
                {currentQ.explanationAr}
              </p>
              <span className="block text-[11px] text-amber-300/70 mt-1">
                المصدر: {currentQ.sourceReferenceAr} (+{currentQ.rewardLeaves} ورقة ذهبية)
              </span>
            </div>
          )}

          {/* Next Button */}
          {isAnswered && (
            <div className="flex justify-end pt-2">
              <button
                onClick={handleNext}
                className="px-6 py-2.5 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-slate-950 font-extrabold text-sm shadow-md transition-all flex items-center gap-2"
              >
                <span>
                  {currentIndex === QUIZ_QUESTIONS.length - 1 ? 'عرض النتيجة النهائية' : 'السؤال التالي'}
                </span>
                <ArrowLeft className="w-4 h-4" />
              </button>
            </div>
          )}
        </div>
      ) : (
        /* Finished State */
        <div className="p-8 sm:p-12 rounded-3xl bg-slate-900 border border-amber-500/30 text-center space-y-5">
          <div className="w-16 h-16 rounded-2xl bg-amber-500/20 border border-amber-500/40 text-amber-300 flex items-center justify-center mx-auto">
            <Trophy className="w-8 h-8" />
          </div>

          <h3 className="text-2xl font-bold text-amber-100 font-quran">
            أتممت المسابقة الإسلامية بنجاح!
          </h3>

          <p className="text-sm text-slate-300">
            حصلت على{' '}
            <strong className="text-amber-400 text-lg tabular-nums">{score}</strong> من{' '}
            <strong className="text-slate-100 text-lg tabular-nums">
              {QUIZ_QUESTIONS.length}
            </strong>{' '}
            إجابة صحيحة، وأُضيفت أوراق الذهب إلى شجرتك المباركة.
          </p>

          <div className="pt-4 flex justify-center">
            <button
              onClick={handleRestart}
              className="flex items-center gap-2 px-6 py-3 rounded-2xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-sm shadow-lg transition-all"
            >
              <RotateCcw className="w-4 h-4" />
              <span>إعادة الاختبار مرة أخرى</span>
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
