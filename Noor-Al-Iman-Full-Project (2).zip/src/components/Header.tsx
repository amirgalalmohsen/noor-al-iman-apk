import React from 'react';
import { Volume2, VolumeX, Sparkles, Bell } from 'lucide-react';
import { FacebookIcon, InstagramIcon, XIcon, ThreadsIcon } from './SocialIcons';

export type NavTab = 
  | 'azkar' 
  | 'quran' 
  | 'tree' 
  | 'tasbih' 
  | 'qibla' 
  | 'worship' 
  | 'community' 
  | 'virtues' 
  | 'quiz'
  | 'about';

interface HeaderProps {
  activeTab: NavTab;
  setActiveTab: (tab: NavTab) => void;
  totalLeaves: number;
  salawatReminderActive: boolean;
  toggleSalawatReminder: () => void;
  soundEnabled: boolean;
  toggleSound: () => void;
  onOpenApkModal: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  activeTab,
  setActiveTab,
  totalLeaves,
  salawatReminderActive,
  toggleSalawatReminder,
  soundEnabled,
  toggleSound,
  onOpenApkModal,
}) => {
  const navLinks: { id: NavTab; label: string }[] = [
    { id: 'azkar', label: 'الأذكار الشاملة' },
    { id: 'quran', label: 'القرآن الكريم' },
    { id: 'tree', label: 'شجرة الحسنات' },
    { id: 'tasbih', label: 'المسبحة الذكية' },
    { id: 'qibla', label: 'بوصلة القبلة' },
    { id: 'community', label: 'المجتمع والتحديات' },
    { id: 'worship', label: 'جدول العبادات' },
    { id: 'virtues', label: 'الفضائل والسنن' },
    { id: 'quiz', label: 'المسابقات' },
    { id: 'about', label: 'عن التطبيق' },
  ];

  return (
    <header className="sticky top-0 z-40 bg-slate-950/90 backdrop-blur-md border-b border-amber-900/30">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between gap-3 h-16 sm:h-20">
          {/* Zone 1: App Icon, Brand Logo & Amir Galal Photo + 'تصميم أمير جلال' */}
          <div className="flex items-center gap-2 sm:gap-3 shrink-0">
            <button
              onClick={() => setActiveTab('tree')}
              className="flex items-center gap-2 sm:gap-2.5 group text-right focus:outline-none"
              aria-label="الرئيسية - شجرة الحسنات نور الإيمان"
            >
              {/* App Golden Emblem */}
              <div className="relative w-10 h-10 sm:w-11 sm:h-11 rounded-2xl bg-gradient-to-br from-amber-300 via-amber-500 to-amber-700 p-0.5 shadow-md shadow-amber-500/20 group-hover:scale-105 transition-transform flex items-center justify-center shrink-0">
                <img
                  src="/icon-192.png"
                  alt="لوجو تطبيق نور الإيمان"
                  className="w-full h-full rounded-[14px] object-cover"
                />
              </div>

              {/* Amir Galal Photo Avatar */}
              <div className="relative w-9 h-9 sm:w-10 sm:h-10 rounded-full bg-gradient-to-br from-amber-300 via-yellow-400 to-amber-600 p-0.5 shadow-md shadow-amber-500/25 group-hover:scale-105 transition-transform shrink-0" title="المصمم: أمير جلال">
                <img
                  src="/amir-galal.svg"
                  alt="صورة المصمم أمير جلال"
                  className="w-full h-full rounded-full object-cover"
                  onError={(e) => {
                    e.currentTarget.src = '/icon-192.png';
                  }}
                />
                <span className="absolute -bottom-0.5 -right-0.5 w-3 h-3 bg-emerald-500 border-2 border-slate-950 rounded-full" title="نشط"></span>
              </div>

              {/* Brand Title & 'تصميم أمير جلال' */}
              <div className="flex flex-col">
                <span className="text-base sm:text-lg font-bold text-amber-200 tracking-wide font-quran leading-tight">
                  نُورُ الإِيمَان
                </span>
                <span className="text-xs sm:text-sm font-extrabold text-transparent bg-clip-text bg-gradient-to-r from-amber-300 via-yellow-200 to-amber-400 font-quran tracking-wide drop-shadow-xs">
                  تصميم أمير جلال
                </span>
              </div>
            </button>

            {/* Social Media Links for Amir Galal */}
            <div className="hidden sm:flex items-center gap-1.5 mr-2 pr-2 border-r border-slate-800">
              <a
                href="https://www.facebook.com/MR.AmirGalal"
                target="_blank"
                rel="noopener noreferrer"
                title="فيسبوك: MR.AmirGalal"
                className="p-1.5 rounded-lg bg-blue-600/15 hover:bg-blue-600/30 text-blue-400 border border-blue-500/30 transition-all flex items-center justify-center"
              >
                <FacebookIcon className="w-3.5 h-3.5" />
              </a>

              <a
                href="https://www.instagram.com/amir____galal/"
                target="_blank"
                rel="noopener noreferrer"
                title="إنستغرام: amir____galal"
                className="p-1.5 rounded-lg bg-pink-600/15 hover:bg-pink-600/30 text-pink-400 border border-pink-500/30 transition-all flex items-center justify-center"
              >
                <InstagramIcon className="w-3.5 h-3.5" />
              </a>

              <a
                href="https://x.com/amir____galal"
                target="_blank"
                rel="noopener noreferrer"
                title="إكس (تويتر): amir____galal"
                className="p-1.5 rounded-lg bg-slate-800/60 hover:bg-slate-800 text-slate-200 border border-slate-700/50 transition-all flex items-center justify-center"
              >
                <XIcon className="w-3.5 h-3.5" />
              </a>

              <a
                href="https://www.threads.net/@amir____galal"
                target="_blank"
                rel="noopener noreferrer"
                title="ثريدز: @amir____galal"
                className="p-1.5 rounded-lg bg-zinc-800/60 hover:bg-zinc-800 text-zinc-200 border border-zinc-700/50 transition-all flex items-center justify-center"
              >
                <ThreadsIcon className="w-3.5 h-3.5" />
              </a>
            </div>
          </div>

          {/* Zone 2: Navigation links */}
          <nav className="hidden lg:flex items-center gap-1 xl:gap-2 text-sm font-medium">
            {navLinks.map((link) => (
              <button
                key={link.id}
                onClick={() => setActiveTab(link.id)}
                className={`px-3 py-1.5 rounded-lg whitespace-nowrap transition-all duration-200 text-xs xl:text-sm ${
                  activeTab === link.id
                    ? 'bg-amber-500/15 text-amber-300 border border-amber-500/30 shadow-xs'
                    : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900/60'
                }`}
              >
                {link.label}
              </button>
            ))}
          </nav>

          {/* Zone 3: Quick Action controls */}
          <div className="flex items-center gap-2 sm:gap-3 shrink-0">
            {/* Golden Leaf Points Pill */}
            <button
              onClick={() => setActiveTab('tree')}
              title="رصيد أوراق شجرة الحسنات الذهبية"
              className="flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-amber-500/10 border border-amber-500/25 text-amber-300 text-xs font-semibold tabular-nums hover:bg-amber-500/20 transition-colors"
            >
              <Sparkles className="w-3.5 h-3.5 text-amber-400 animate-pulse" />
              <span>{totalLeaves.toLocaleString('ar-EG')}</span>
              <span className="hidden sm:inline text-[11px] text-amber-400/70">ورقة ذهبية</span>
            </button>

            {/* APK Download Button */}
            <button
              onClick={onOpenApkModal}
              title="تثبيت التطبيق على الهاتف أو تحميل ملف APK"
              className="flex items-center gap-1 px-2.5 py-1 rounded-lg bg-amber-500 hover:bg-amber-400 text-slate-950 text-xs font-bold transition-all shadow-xs"
            >
              <span className="font-mono text-[11px]">APK</span>
              <span className="hidden sm:inline">تنزيل</span>
            </button>

            {/* Smart Salawat Reminder Toggle */}
            <button
              onClick={toggleSalawatReminder}
              title={salawatReminderActive ? 'التذكير الدوري بالصلاة على النبي مُفعل' : 'تفعيل التذكير بالصلاة على النبي ﷺ'}
              className={`p-2 rounded-lg border transition-colors ${
                salawatReminderActive
                  ? 'bg-emerald-500/15 border-emerald-500/40 text-emerald-300'
                  : 'bg-slate-900 border-slate-800 text-slate-400 hover:text-slate-200'
              }`}
              aria-label="تفعيل أو إيقاف التذكير الذكي بالصلاة على النبي"
            >
              <Bell className="w-4 h-4" />
            </button>

            {/* Sound Toggle */}
            <button
              onClick={toggleSound}
              title={soundEnabled ? 'كتم المؤثرات الصوتية' : 'تشغيل المؤثرات الصوتية'}
              className="p-2 rounded-lg bg-slate-900 border border-slate-800 text-slate-400 hover:text-slate-200 transition-colors"
              aria-label="تبديل الصوت"
            >
              {soundEnabled ? <Volume2 className="w-4 h-4 text-amber-400" /> : <VolumeX className="w-4 h-4" />}
            </button>
          </div>
        </div>

        {/* Mobile secondary navigation scrollbar & mobile Amir Galal social links */}
        <div className="lg:hidden flex items-center justify-between gap-2 py-2 border-t border-slate-900">
          <div className="flex items-center gap-1 overflow-x-auto no-scrollbar flex-1">
            {navLinks.map((link) => (
              <button
                key={link.id}
                onClick={() => setActiveTab(link.id)}
                className={`px-2.5 py-1 rounded-md whitespace-nowrap text-xs transition-colors shrink-0 ${
                  activeTab === link.id
                    ? 'bg-amber-500/20 text-amber-300 border border-amber-500/30'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                {link.label}
              </button>
            ))}
          </div>

          <div className="flex items-center gap-1 shrink-0 pr-1">
            <a
              href="https://www.facebook.com/MR.AmirGalal"
              target="_blank"
              rel="noopener noreferrer"
              title="فيسبوك: MR.AmirGalal"
              className="p-1.5 rounded-lg bg-blue-600/20 text-blue-400 border border-blue-500/30 active:scale-95 transition-all"
            >
              <FacebookIcon className="w-3.5 h-3.5" />
            </a>
            <a
              href="https://www.instagram.com/amir____galal/"
              target="_blank"
              rel="noopener noreferrer"
              title="إنستغرام: amir____galal"
              className="p-1.5 rounded-lg bg-pink-600/20 text-pink-400 border border-pink-500/30 active:scale-95 transition-all"
            >
              <InstagramIcon className="w-3.5 h-3.5" />
            </a>
            <a
              href="https://x.com/amir____galal"
              target="_blank"
              rel="noopener noreferrer"
              title="إكس (تويتر): amir____galal"
              className="p-1.5 rounded-lg bg-slate-800/60 text-slate-200 border border-slate-700/50 active:scale-95 transition-all"
            >
              <XIcon className="w-3.5 h-3.5" />
            </a>
            <a
              href="https://www.threads.net/@amir____galal"
              target="_blank"
              rel="noopener noreferrer"
              title="ثريدز: @amir____galal"
              className="p-1.5 rounded-lg bg-zinc-800/60 text-zinc-200 border border-zinc-700/50 active:scale-95 transition-all"
            >
              <ThreadsIcon className="w-3.5 h-3.5" />
            </a>
          </div>
        </div>
      </div>
    </header>
  );
};
