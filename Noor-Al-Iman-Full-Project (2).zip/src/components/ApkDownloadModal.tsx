import React, { useState, useEffect } from 'react';
import {
  Download,
  Smartphone,
  ExternalLink,
  Check,
  Copy,
  X,
  Sparkles,
  ShieldCheck,
  Code2,
  AlertTriangle,
  Globe,
  Image as ImageIcon,
  FileArchive,
} from 'lucide-react';
import { FacebookIcon, InstagramIcon, XIcon, ThreadsIcon } from './SocialIcons';

interface BeforeInstallPromptEvent extends Event {
  prompt: () => Promise<void>;
  userChoice: Promise<{ outcome: 'accepted' | 'dismissed'; platform: string }>;
}

interface ApkDownloadModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const ApkDownloadModal: React.FC<ApkDownloadModalProps> = ({ isOpen, onClose }) => {
  const [deferredPrompt, setDeferredPrompt] = useState<BeforeInstallPromptEvent | null>(null);
  const [isInstalled, setIsInstalled] = useState<boolean>(false);
  const [copiedUrl, setCopiedUrl] = useState<boolean>(false);
  const [copiedZipUrl, setCopiedZipUrl] = useState<boolean>(false);
  const [copiedManifest, setCopiedManifest] = useState<boolean>(false);
  const [showManualTip, setShowManualTip] = useState<boolean>(false);
  const [activeTab, setActiveTab] = useState<'source_zip' | 'direct' | 'pwabuilder' | 'hosting' | 'manifest'>('source_zip');

  const livePublicUrl = 'https://ais-pre-3nbcvgpzfxo2m2hy435lw7-952182067276.europe-west2.run.app';
  const appUrl = (typeof window !== 'undefined' && window.location.origin && !window.location.origin.includes('localhost'))
    ? window.location.origin
    : livePublicUrl;

  const zipDownloadUrl = `${appUrl}/Noor-Al-Iman-Android-Source.zip`;

  const qrCodeUrl = `https://api.qrserver.com/v1/create-qr-code/?size=180x180&data=${encodeURIComponent(appUrl)}`;
  const pwaBuilderUrl = `https://www.pwabuilder.com?url=${encodeURIComponent(appUrl)}`;

  const manifestJsonString = JSON.stringify(
    {
      id: '/',
      name: 'نور الإيمان',
      short_name: 'نور الإيمان',
      description: 'تطبيق إسلامي شامل للقرآن الكريم والأذكار والأدعية والعبادات.',
      start_url: '/',
      scope: '/',
      display: 'standalone',
      orientation: 'portrait',
      background_color: '#0B0B12',
      theme_color: '#D4AF37',
      lang: 'ar',
      dir: 'rtl',
      categories: ['lifestyle', 'books', 'education'],
      icons: [
        {
          src: '/icon-192.png',
          sizes: '192x192',
          type: 'image/png',
          purpose: 'any',
        },
        {
          src: '/icon-512.png',
          sizes: '512x512',
          type: 'image/png',
          purpose: 'any',
        },
        {
          src: '/icon-maskable-512.png',
          sizes: '512x512',
          type: 'image/png',
          purpose: 'maskable',
        },
      ],
    },
    null,
    2
  );

  useEffect(() => {
    if (window.matchMedia('(display-mode: standalone)').matches) {
      setIsInstalled(true);
    }

    const handleBeforeInstall = (e: Event) => {
      e.preventDefault();
      setDeferredPrompt(e as BeforeInstallPromptEvent);
    };

    window.addEventListener('beforeinstallprompt', handleBeforeInstall);
    return () => window.removeEventListener('beforeinstallprompt', handleBeforeInstall);
  }, []);

  if (!isOpen) return null;

  const handleInstallPWA = async () => {
    if (!deferredPrompt) {
      setShowManualTip(true);
      return;
    }
    await deferredPrompt.prompt();
    const { outcome } = await deferredPrompt.userChoice;
    if (outcome === 'accepted') {
      setIsInstalled(true);
      setDeferredPrompt(null);
    }
  };

  const copyAppUrl = () => {
    navigator.clipboard.writeText(appUrl);
    setCopiedUrl(true);
    setTimeout(() => setCopiedUrl(false), 2500);
  };

  const copyZipUrl = () => {
    navigator.clipboard.writeText(zipDownloadUrl);
    setCopiedZipUrl(true);
    setTimeout(() => setCopiedZipUrl(false), 2500);
  };

  const copyManifest = () => {
    navigator.clipboard.writeText(manifestJsonString);
    setCopiedManifest(true);
    setTimeout(() => setCopiedManifest(false), 2500);
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="w-full max-w-xl bg-slate-900 border border-amber-500/40 rounded-3xl p-5 sm:p-7 text-right space-y-4 shadow-2xl relative max-h-[90vh] overflow-y-auto">
        {/* Header */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between border-b border-slate-800 pb-4 gap-3">
          <div className="flex items-center gap-3">
            <div className="relative w-12 h-12 rounded-2xl bg-gradient-to-br from-amber-300 via-amber-500 to-amber-700 p-0.5 shadow-md shadow-amber-500/20 shrink-0">
              <img
                src="/icon-192.png"
                alt="أيقونة تطبيق نور الإيمان"
                className="w-full h-full rounded-[14px] object-cover"
              />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-lg sm:text-xl font-bold text-amber-200 font-quran">
                  تطبيق نُورُ الإِيمَان
                </h3>
                <span className="text-xs text-amber-400/80 font-bold font-quran">
                  · أمير جلال
                </span>
              </div>
              <p className="text-xs text-slate-400">
                تثبيت التطبيق على الهاتف وحل فحص PWABuilder
              </p>
            </div>
          </div>

          <div className="flex items-center justify-between sm:justify-end gap-2">
            <div className="flex items-center gap-1">
              <a
                href="https://www.facebook.com/MR.AmirGalal"
                target="_blank"
                rel="noopener noreferrer"
                title="فيسبوك: MR.AmirGalal"
                className="p-1.5 rounded-lg bg-blue-600/20 text-blue-300 border border-blue-500/30 hover:bg-blue-600/30 transition-colors"
              >
                <FacebookIcon className="w-3.5 h-3.5 text-blue-400" />
              </a>
              <a
                href="https://www.instagram.com/amir____galal/"
                target="_blank"
                rel="noopener noreferrer"
                title="إنستغرام: amir____galal"
                className="p-1.5 rounded-lg bg-pink-600/20 text-pink-300 border border-pink-500/30 hover:bg-pink-600/30 transition-colors"
              >
                <InstagramIcon className="w-3.5 h-3.5 text-pink-400" />
              </a>
              <a
                href="https://x.com/amir____galal"
                target="_blank"
                rel="noopener noreferrer"
                title="إكس: amir____galal"
                className="p-1.5 rounded-lg bg-slate-800/60 text-slate-200 border border-slate-700/50 hover:bg-slate-800 transition-colors"
              >
                <XIcon className="w-3.5 h-3.5 text-slate-100" />
              </a>
              <a
                href="https://www.threads.net/@amir____galal"
                target="_blank"
                rel="noopener noreferrer"
                title="ثريدز: @amir____galal"
                className="p-1.5 rounded-lg bg-zinc-800/60 text-zinc-200 border border-zinc-700/50 hover:bg-zinc-800 transition-colors"
              >
                <ThreadsIcon className="w-3.5 h-3.5 text-zinc-100" />
              </a>
            </div>

            <button
              onClick={onClose}
              className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Subtabs */}
        <div className="flex flex-wrap items-center gap-1 p-1 bg-slate-950 rounded-xl border border-slate-800">
          <button
            onClick={() => setActiveTab('source_zip')}
            className={`flex-1 py-1.5 px-2 text-xs font-bold rounded-lg transition-colors flex items-center justify-center gap-1.5 ${
              activeTab === 'source_zip'
                ? 'bg-amber-500 text-slate-950 shadow-xs'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <FileArchive className="w-3.5 h-3.5" />
            <span>سورس Android (ZIP)</span>
          </button>
          <button
            onClick={() => setActiveTab('direct')}
            className={`flex-1 py-1.5 px-2 text-xs font-bold rounded-lg transition-colors ${
              activeTab === 'direct'
                ? 'bg-amber-500 text-slate-950 shadow-xs'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            تثبيت فوري (WebAPK)
          </button>
          <button
            onClick={() => setActiveTab('pwabuilder')}
            className={`py-1.5 px-2.5 text-xs font-bold rounded-lg transition-colors ${
              activeTab === 'pwabuilder'
                ? 'bg-amber-500 text-slate-950 shadow-xs'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            PWABuilder
          </button>
          <button
            onClick={() => setActiveTab('manifest')}
            className={`py-1.5 px-2.5 text-xs font-bold rounded-lg transition-colors ${
              activeTab === 'manifest'
                ? 'bg-amber-500 text-slate-950 shadow-xs'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            Manifest
          </button>
        </div>

        {/* Tab 0: Android Source Code ZIP */}
        {activeTab === 'source_zip' && (
          <div className="p-5 rounded-2xl bg-gradient-to-br from-amber-500/10 via-slate-950 to-slate-950 border border-amber-500/30 space-y-4">
            <div className="flex items-center justify-between">
              <span className="text-xs px-2.5 py-0.5 rounded-full bg-amber-500/20 text-amber-300 border border-amber-500/30 font-bold flex items-center gap-1">
                <Sparkles className="w-3 h-3 text-amber-400" />
                <span>حزمة كود أندرويد الأصلية الكاملة جاهزة للتحميل</span>
              </span>
              <FileArchive className="w-5 h-5 text-amber-400" />
            </div>

            {/* Direct Download Button */}
            <a
              href="/Noor-Al-Iman-Android-Source.zip"
              download="Noor-Al-Iman-Android-Source.zip"
              className="w-full py-3 px-4 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-slate-950 font-extrabold text-sm shadow-lg shadow-amber-500/20 flex items-center justify-center gap-2 transition-all block text-center"
            >
              <Download className="w-4 h-4" />
              <span>تنزيل ملف السورس: Noor-Al-Iman-Android-Source.zip (201 KB)</span>
            </a>

            {/* Link display & copy */}
            <div className="p-3 rounded-xl bg-slate-900 border border-slate-800 space-y-2">
              <div className="flex items-center justify-between text-xs">
                <span className="text-amber-300 font-bold font-quran">
                  رابط التحميل المباشر للمشاركة:
                </span>
                <span className="text-[10px] text-emerald-400 font-mono">ZIP مباشر</span>
              </div>
              <div className="flex items-center gap-2">
                <input
                  type="text"
                  readOnly
                  value={zipDownloadUrl}
                  className="flex-1 bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-xs text-amber-200 font-mono select-all focus:outline-none"
                />
                <button
                  onClick={copyZipUrl}
                  className="px-3 py-2 rounded-lg bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs flex items-center gap-1.5 transition-colors shrink-0"
                >
                  {copiedZipUrl ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                  <span>{copiedZipUrl ? 'تم النسخ' : 'نسخ الرابط'}</span>
                </button>
              </div>
            </div>

            {/* Contents list */}
            <div className="p-3.5 rounded-xl bg-slate-900/80 border border-slate-800 text-xs space-y-2 text-slate-300 font-quran">
              <p className="text-amber-300 font-bold">محتويات الأرشيف الفعلية (28 ملفاً):</p>
              <ul className="space-y-1 text-[11px] list-disc list-inside text-slate-300 pr-1 leading-relaxed">
                <li><code className="text-amber-300 font-mono">native-android/</code>: كود Kotlin لنظام أندرويد مع Gradle 8.5 و SDK 34.</li>
                <li><code className="text-amber-300 font-mono">MainActivity.kt</code>: تطبيق WebView الآمن مع التعامل مع التنزيلات وانقطاع النت.</li>
                <li><code className="text-amber-300 font-mono">AndroidManifest.xml</code>: حزمة <code className="text-emerald-400 font-mono">com.amirgalal.nooreleman</code> واسم «نور الإيمان».</li>
                <li><code className="text-amber-300 font-mono">res/mipmap-*/</code>: جميع مقاسات الأيقونات الرسمية بدقة عالية.</li>
                <li><code className="text-amber-300 font-mono">.github/workflows/build-android-apk.yml</code>: سير عمل آلي لبناء APK ونشره في Releases.</li>
                <li><code className="text-amber-300 font-mono">README-APK.md</code>: شرح تفصيلي خطوة بخطوة للربط بـ GitHub وبناء APK.</li>
              </ul>
            </div>
          </div>
        )}

        {/* Tab 1: Direct WebAPK Install & Phone Link */}
        {activeTab === 'direct' && (
          <div className="p-5 rounded-2xl bg-gradient-to-br from-amber-500/10 via-slate-950 to-slate-950 border border-amber-500/30 space-y-4">
            <div className="flex items-center justify-between">
              <span className="text-xs px-2.5 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 font-bold">
                الحل الأسرع والمباشر 100% للهاتف
              </span>
              <Smartphone className="w-5 h-5 text-amber-400" />
            </div>

            {/* Direct App Link Display Box */}
            <div className="p-3.5 rounded-xl bg-slate-900 border border-amber-500/30 space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-xs text-amber-300 font-bold font-quran">
                  رابط فتح وتثبيت التطبيق على الهاتف مباشرة:
                </span>
                <span className="text-[10px] text-emerald-400 font-mono">HTTPS مباشر</span>
              </div>

              <div className="flex items-center gap-2">
                <input
                  type="text"
                  readOnly
                  value={appUrl}
                  className="flex-1 bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-xs text-amber-200 font-mono select-all focus:outline-none"
                />
                <button
                  onClick={copyAppUrl}
                  className="px-3 py-2 rounded-lg bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs flex items-center gap-1.5 transition-colors shrink-0"
                >
                  {copiedUrl ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                  <span>{copiedUrl ? 'تم النسخ' : 'نسخ الرابط'}</span>
                </button>
              </div>
            </div>

            {/* QR Code and Direct Install */}
            <div className="flex flex-col sm:flex-row items-center gap-4 p-4 rounded-xl bg-slate-900/80 border border-slate-800">
              <div className="p-2 rounded-xl bg-white shrink-0 shadow-md">
                <img
                  src={qrCodeUrl}
                  alt="QR Code لتنزيل التطبيق على الهاتف"
                  className="w-28 h-28 sm:w-32 sm:h-32 object-contain"
                  onError={(e) => {
                    e.currentTarget.style.display = 'none';
                  }}
                />
              </div>

              <div className="space-y-2 text-right">
                <h5 className="text-xs font-bold text-amber-300 font-quran">
                  امسح الرمز بكاميرا هاتفك أو افتح الرابط في Chrome
                </h5>
                <p className="text-[11px] text-slate-300 leading-relaxed font-quran">
                  يقوم نظام أندرويد بتحويل هذا الرابط تلقائياً إلى <strong>تطبيق رسمي (WebAPK)</strong> مثبت على شاشة الهاتف، بأيقونة نور الإيمان 512×512، وبدون شريط متصفح، ويعمل في أي وقت بدون إنترنت.
                </p>

                <button
                  onClick={handleInstallPWA}
                  className="w-full py-2.5 px-4 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-slate-950 font-extrabold text-xs shadow-md flex items-center justify-center gap-2 transition-all mt-1"
                >
                  <Download className="w-4 h-4" />
                  <span>{isInstalled ? 'التطبيق مُثبّت بالفعل على هاتفك ✓' : 'تثبيت التطبيق فوراً كـ App'}</span>
                </button>
              </div>
            </div>

            {(showManualTip || !deferredPrompt) && (
              <div className="p-3.5 rounded-xl bg-amber-500/10 border border-amber-500/30 text-[11px] text-slate-200 space-y-1.5 font-quran">
                <strong className="text-amber-400 block font-semibold">
                  طريقة التثبيت المباشر على هاتف أندرويد عبر متصفح Chrome:
                </strong>
                <p>1. افتح الرابط المنسوخ أعلاه في متصفح <strong>Google Chrome</strong> على هاتفك.</p>
                <p>2. اضغط على القائمة العلوية <strong>(الثلاث نقاط ⋮)</strong>.</p>
                <p>3. اختر <strong>«تثبيت التطبيق» (Install app)</strong> أو <strong>«إضافة إلى الشاشة الرئيسية»</strong>.</p>
                <p className="text-emerald-300">✓ سيظهر التطبيق فوراً كأيقونة مستقلة في قائمة تطبيقات هاتفك مثل أي ملف APK مثبت!</p>
              </div>
            )}
          </div>
        )}

        {/* Tab 2: PWABuilder Block Bypass & Manual Icon Upload */}
        {activeTab === 'pwabuilder' && (
          <div className="space-y-4">
            <div className="p-4 rounded-2xl bg-rose-500/10 border border-rose-500/30 text-xs text-rose-200 space-y-2">
              <div className="flex items-center gap-2 text-rose-400 font-bold">
                <AlertTriangle className="w-4 h-4 shrink-0" />
                <span>تشخيص سبب رسالة: "Your web host is blocking PWABuilder"</span>
              </div>
              <p className="leading-relaxed">
                استضافة المعاينة الحالية على Google Cloud Run تفرض جدار حماية يتطلب كوكيز جلسة من Google (HTTP 302 إلى cookie_check). عند محاولة سيرفرات PWABuilder تحميل الأيقونات والـ manifest، ترفض خوادم جوجل الطلب لأنه صادر من روبوت خارجي بدون تسجيل دخول.
              </p>
            </div>

            <div className="p-5 rounded-2xl bg-slate-950 border border-slate-800 space-y-3">
              <h4 className="text-sm font-bold text-slate-100 font-quran">
                خطوات تجاوز المشكلة في PWABuilder:
              </h4>

              <div className="text-xs text-slate-300 space-y-2.5">
                <p>
                  <strong>الخطوة 1:</strong> حمّل ملفات الأيقونة الأصلية إلى جهازك مباشرة (لكي ترفعها يدوياً إلى PWABuilder بدلاً من تركه يحاول تحميلها من الرابط المحظور):
                </p>
                <div className="flex items-center gap-2">
                  <a
                    href="/icon-512.png"
                    download="icon-512.png"
                    className="flex-1 py-2 px-3 rounded-xl bg-slate-800 hover:bg-slate-700 text-amber-300 border border-slate-700 text-xs font-semibold flex items-center justify-center gap-1.5"
                  >
                    <ImageIcon className="w-3.5 h-3.5" />
                    <span>تحميل أيقونة 512×512 PNG</span>
                  </a>
                  <a
                    href="/icon-192.png"
                    download="icon-192.png"
                    className="flex-1 py-2 px-3 rounded-xl bg-slate-800 hover:bg-slate-700 text-amber-300 border border-slate-700 text-xs font-semibold flex items-center justify-center gap-1.5"
                  >
                    <ImageIcon className="w-3.5 h-3.5" />
                    <span>تحميل أيقونة 192×192 PNG</span>
                  </a>
                </div>

                <p className="pt-2">
                  <strong>الخطوة 2:</strong> في صفحة PWABuilder عند ظهور خطأ التحميل، اضغط على <strong>«Package Options»</strong> أو <strong>«Icons»</strong> وارفع صورة <strong>icon-512.png</strong> التي قمت بتحميلها للتو.
                </p>

                <p>
                  <strong>الخطوة 3:</strong> اضغط <strong>«Generate»</strong> وسيقوم PWABuilder بإنشاء وتنزيل ملف الـ <strong>APK</strong> دون الحاجة للاتصال بخوادم جوجل!
                </p>
              </div>

              <a
                href={pwaBuilderUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="w-full py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-amber-300 border border-amber-500/30 text-xs font-bold flex items-center justify-center gap-2 transition-colors mt-3"
              >
                <span>فتح موقع PWABuilder</span>
                <ExternalLink className="w-3.5 h-3.5" />
              </a>
            </div>
          </div>
        )}

        {/* Tab 3: Free Permanent Static Hosting */}
        {activeTab === 'hosting' && (
          <div className="space-y-4">
            <div className="p-4 rounded-2xl bg-amber-500/10 border border-amber-500/30 text-xs text-amber-200 space-y-1.5">
              <span className="font-bold text-amber-400 flex items-center gap-1.5">
                <Globe className="w-4 h-4" />
                <span>نشر المشروع على استضافة عامة مفتوحة 100%:</span>
              </span>
              <p className="leading-relaxed">
                إذا أردت رابطاً عاماً دائماً بدون أي جدار حماية من جوجل ليتمكن أي شخص في العالم أو أي أداة مثل PWABuilder من فحص الـ Manifest وتحميل الـ APK بنقرة واحدة:
              </p>
            </div>

            <div className="p-5 rounded-2xl bg-slate-950 border border-slate-800 space-y-3 text-xs text-slate-300">
              <h4 className="text-sm font-bold text-slate-100 font-quran">
                خيارات النشر المجاني الدائم (مجلد dist جاهز تماماً):
              </h4>

              <div className="p-3 rounded-xl bg-slate-900 border border-slate-800 space-y-1.5">
                <strong className="text-emerald-400 block font-semibold">1. استضافة Netlify (الأسهل والأسرع خلال دقيقة واحدة):</strong>
                <p>ادخل إلى موقع <strong>netlify.com/drop</strong> واسحب مجلد <strong>dist</strong> الخاص بالمشروع وأفلته هناك؛ ستحصل فوراً على رابط دائم ومفتوح للجميع مجاناً!</p>
              </div>

              <div className="p-3 rounded-xl bg-slate-900 border border-slate-800 space-y-1.5">
                <strong className="text-emerald-400 block font-semibold">2. استضافة Vercel (مجاناً بنقرة واحدة):</strong>
                <p>قم بربط مستودع GitHub الخاص بالمشروع على <strong>vercel.com</strong> وسيتم نشره تلقائياً برابط HTTPS عام وسريع جداً.</p>
              </div>

              <div className="p-3 rounded-xl bg-slate-900 border border-slate-800 space-y-1.5">
                <strong className="text-emerald-400 block font-semibold">3. استضافة GitHub Pages أو Cloudflare Pages:</strong>
                <p>استضافة مجانية مدى الحياة ومفتوحة المصدر للملفات الثابتة.</p>
              </div>
            </div>
          </div>
        )}

        {/* Tab 4: Manifest Code Viewer */}
        {activeTab === 'manifest' && (
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-xs text-slate-400 font-mono">/manifest.json</span>
              <button
                onClick={copyManifest}
                className="px-3 py-1 rounded-lg bg-amber-500 text-slate-950 font-bold text-xs flex items-center gap-1"
              >
                {copiedManifest ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                <span>{copiedManifest ? 'تم النسخ' : 'نسخ الكود'}</span>
              </button>
            </div>

            <pre
              className="p-4 rounded-2xl bg-slate-950 border border-slate-800 text-amber-300 text-[11px] font-mono overflow-x-auto max-h-60 text-left"
              dir="ltr"
            >
              {manifestJsonString}
            </pre>
          </div>
        )}
      </div>
    </div>
  );
};
