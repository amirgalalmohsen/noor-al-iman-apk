import React from 'react';
import {
  Sparkles,
  Heart,
  BookOpen,
  Compass,
  Smartphone,
  ShieldCheck,
  Award,
  Layers,
  ArrowRight,
} from 'lucide-react';
import { FollowAmirGalalSection } from './FollowAmirGalalSection';
import { NavTab } from './Header';

interface AboutSectionProps {
  onNavigateTab: (tab: NavTab) => void;
  onOpenApkModal: () => void;
}

export const AboutSection: React.FC<AboutSectionProps> = ({
  onNavigateTab,
  onOpenApkModal,
}) => {
  const features = [
    {
      title: 'القرآن الكريم كاملاً',
      desc: 'قراءة ميسرة بالرسم العثماني، تلاوات صوتية عطرة لأشهر القراء، وتفسير ميسر للآيات.',
      icon: BookOpen,
      tab: 'quran' as NavTab,
    },
    {
      title: 'شجرة الحسنات الذهبية',
      desc: 'نظام بصري تفاعلي فريد يحول أعمالك الصالحة وأذكارك إلى أوراق ذهبية نامية ومثمرة.',
      icon: Sparkles,
      tab: 'tree' as NavTab,
    },
    {
      title: 'الأذكار والمسبحة الذكية',
      desc: 'أذكار الصباح والمساء وأدعية اليوم والليلة موثقة بالأحاديث، مع عدادات لمسية تفاعلية.',
      icon: Heart,
      tab: 'azkar' as NavTab,
    },
    {
      title: 'بوصلة القبلة ومواقيت العبادة',
      desc: 'تحديد دقيق لاتجاه الكعبة المشرفة وفق موقعك الجغرافي، مع جدول متكامل لمحاسبة النفس.',
      icon: Compass,
      tab: 'qibla' as NavTab,
    },
  ];

  return (
    <div className="space-y-8 animate-fadeIn" dir="rtl">
      {/* Hero Banner: About App & Vision */}
      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-slate-950 via-[#0B0B14] to-slate-900 border border-amber-500/30 p-6 sm:p-10 shadow-2xl">
        <div className="absolute top-0 left-0 w-96 h-96 bg-amber-500/10 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute bottom-0 right-0 w-72 h-72 bg-blue-500/5 rounded-full blur-3xl pointer-events-none" />

        <div className="relative z-10 flex flex-col md:flex-row items-center gap-6 sm:gap-8 text-center md:text-right justify-between">
          <div className="space-y-3 max-w-2xl">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-amber-500/15 border border-amber-500/30 text-amber-300 text-xs font-bold font-quran">
              <Sparkles className="w-3.5 h-3.5 text-amber-400" />
              <span>رؤية ورسالة التطبيق</span>
            </div>

            <h1 className="text-2xl sm:text-4xl font-extrabold text-transparent bg-clip-text bg-gradient-to-r from-amber-200 via-yellow-100 to-amber-400 font-quran tracking-wide">
              عن تطبيق «نُورُ الإِيمَان»
            </h1>

            <p className="text-sm sm:text-base text-slate-300 font-quran leading-relaxed">
              تطبيق إسلامي متطور شامل، ابتكره وصممه <strong>أمير جلال</strong> ليكون رفيقاً نقياً في يوم المسلم وليلته. صُمم التطبيق بعناية فائقة تدمج بين الأصالة الشرعية للمحتوى، وأحدث معايير التصميم العصري وسلاسة التجربة الرقمية.
            </p>

            <div className="flex flex-wrap items-center justify-center md:justify-start gap-2 pt-2">
              <span className="px-3 py-1 rounded-xl bg-slate-900 border border-slate-800 text-slate-300 text-xs font-quran flex items-center gap-1.5">
                <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
                <span>خالٍ تماماً من الإعلانات</span>
              </span>
              <span className="px-3 py-1 rounded-xl bg-slate-900 border border-slate-800 text-slate-300 text-xs font-quran flex items-center gap-1.5">
                <Award className="w-3.5 h-3.5 text-amber-400" />
                <span>أذكار موثقة وصحيحة</span>
              </span>
              <span className="px-3 py-1 rounded-xl bg-slate-900 border border-slate-800 text-slate-300 text-xs font-quran flex items-center gap-1.5">
                <Layers className="w-3.5 h-3.5 text-blue-400" />
                <span>حفظ التقدم ومزامنة محلية</span>
              </span>
            </div>
          </div>

          {/* Quick APK action */}
          <div className="flex flex-col items-center gap-3 shrink-0 p-5 rounded-2xl bg-slate-900/90 border border-amber-500/30 text-center w-full md:w-auto">
            <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-amber-300 to-amber-600 p-0.5 shadow-lg">
              <img
                src="/icon-192.png"
                alt="لوجو تطبيق نور الإيمان"
                className="w-full h-full rounded-[14px] object-cover"
              />
            </div>
            <div>
              <p className="text-xs font-bold text-amber-200 font-quran">متوفر للهاتف كـ APK و WebApp</p>
              <p className="text-[11px] text-slate-400">بدون الحاجة لمتجر</p>
            </div>
            <button
              onClick={onOpenApkModal}
              className="w-full py-2 px-4 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs flex items-center justify-center gap-1.5 shadow-md transition-all active:scale-95"
            >
              <Smartphone className="w-3.5 h-3.5" />
              <span>تحميل أو تثبيت التطبيق</span>
            </button>
          </div>
        </div>
      </div>

      {/* Primary Section: Follow Amir Galal */}
      <FollowAmirGalalSection variant="full" />

      {/* Core Features Grid */}
      <div className="space-y-4">
        <div className="text-right">
          <h2 className="text-lg sm:text-xl font-bold text-amber-200 font-quran">
            ركائز وأقسام التطبيق الرئيسية
          </h2>
          <p className="text-xs sm:text-sm text-slate-400 font-quran">
            تم بناء كل قسم في «نور الإيمان» ليكون أداة فاعلة تقربك إلى الله عز وجل
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {features.map((feature, idx) => {
            const Icon = feature.icon;
            return (
              <div
                key={idx}
                className="rounded-2xl bg-slate-900/70 border border-slate-800 p-5 hover:border-amber-500/40 transition-all text-right flex flex-col justify-between group"
              >
                <div className="space-y-2.5">
                  <div className="w-10 h-10 rounded-xl bg-amber-500/10 border border-amber-500/20 text-amber-400 flex items-center justify-center group-hover:scale-110 transition-transform">
                    <Icon className="w-5 h-5" />
                  </div>
                  <h3 className="text-base font-bold text-slate-100 font-quran">
                    {feature.title}
                  </h3>
                  <p className="text-xs text-slate-300 font-quran leading-relaxed">
                    {feature.desc}
                  </p>
                </div>

                <button
                  onClick={() => onNavigateTab(feature.tab)}
                  className="mt-4 pt-3 border-t border-slate-800/80 text-xs font-bold text-amber-400 hover:text-amber-300 flex items-center justify-between transition-colors"
                >
                  <span>فتح القسم</span>
                  <ArrowRight className="w-3.5 h-3.5 rotate-180" />
                </button>
              </div>
            );
          })}
        </div>
      </div>

      {/* Developer Note & Duaa Card */}
      <div className="rounded-3xl bg-gradient-to-r from-amber-500/10 via-slate-900 to-amber-500/10 border border-amber-500/30 p-6 sm:p-8 text-center space-y-3">
        <p className="text-xs text-amber-400 font-bold uppercase tracking-wider font-mono">
          Developer Dedication
        </p>
        <p className="text-base sm:text-xl font-bold text-amber-200 font-quran leading-relaxed max-w-2xl mx-auto">
          «اللَّهُمَّ اجْعَلْ هَذَا الْعَمَلَ خَالِصاً لِوَجْهِكَ الْكَرِيمِ، وَتَقَبَّلْهُ مِنَّا وَمِنْ كُلِّ مَنْ قَرَأَ فِيهِ أَوْ نَشَرَهُ، وَاجْعَلْهُ فِي مِيزَانِ حَسَنَاتِنَا يَوْمَ نَلْقَاكَ»
        </p>
        <p className="text-xs text-slate-400 font-quran">
          تطوير وتصميم: <strong>أمير جلال (Amir Galal)</strong> · جميع الحقوق محفوظة
        </p>
      </div>
    </div>
  );
};
