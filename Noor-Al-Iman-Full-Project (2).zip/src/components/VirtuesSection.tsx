import React, { useState } from 'react';
import { Sparkles, Heart, Bell, Check, Clock, BookOpen, Volume2 } from 'lucide-react';
import { VIRTUES_DATA, VirtueArticle } from '../data/virtuesData';

interface VirtuesSectionProps {
  salawatReminderActive: boolean;
  toggleSalawatReminder: () => void;
  salawatIntervalMins: number;
  setSalawatIntervalMins: (mins: number) => void;
  onAddHasanat: (amount: number, reason: string) => void;
}

export const VirtuesSection: React.FC<VirtuesSectionProps> = ({
  salawatReminderActive,
  toggleSalawatReminder,
  salawatIntervalMins,
  setSalawatIntervalMins,
  onAddHasanat,
}) => {
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [salawatCount, setSalawatCount] = useState<number>(0);

  const categories = [
    { id: 'all', label: 'جميع الفضائل' },
    { id: 'prophet_prayer', label: 'فضل الصلاة على النبي ﷺ' },
    { id: 'salat', label: 'فضائل الصلوات' },
    { id: 'surah', label: 'فضائل السور' },
    { id: 'dhikr', label: 'فضائل الأذكار' },
  ];

  const filtered = VIRTUES_DATA.filter(
    (item) => selectedCategory === 'all' || item.category === selectedCategory
  );

  const handleSalawatTap = () => {
    const next = salawatCount + 1;
    setSalawatCount(next);
    if (next % 10 === 0) {
      onAddHasanat(20, '10 صلوات على النبي ﷺ');
    }
  };

  return (
    <div className="space-y-6">
      {/* Salawat Special Hero Banner & Smart Reminder Config */}
      <div className="p-6 sm:p-8 rounded-3xl bg-gradient-to-br from-amber-950/40 via-slate-900 to-slate-950 border border-amber-500/30 text-right space-y-4">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <span className="text-xs font-semibold text-amber-400">
              ﴿ إِنَّ اللَّهَ وَمَلَائِكَتَهُ يُصَلُّونَ عَلَى النَّبِيِّ ﴾
            </span>
            <h2 className="text-2xl sm:text-3xl font-extrabold text-amber-100 font-quran mt-1">
              مكتبة الفضائل والتذكير الذكي بالصلاة على النبي ﷺ
            </h2>
            <p className="text-xs text-slate-300 mt-1 max-w-xl">
              من صلّى عليه صلاةً صلّى الله عليه بها عشراً وحُطت عنه عشر خطيئات ورُفعت له عشر درجات
            </p>
          </div>

          {/* Direct Salawat Clicker */}
          <div className="flex items-center gap-3 self-start md:self-center">
            <button
              onClick={handleSalawatTap}
              className="px-5 py-3 rounded-2xl bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-slate-950 font-extrabold text-sm shadow-xl active:scale-95 transition-all flex items-center gap-2"
            >
              <Heart className="w-4 h-4 fill-slate-950" />
              <span>صلِّ على النبي ﷺ ({salawatCount})</span>
            </button>
          </div>
        </div>

        {/* Smart Reminder Frequency Settings */}
        <div className="pt-4 border-t border-slate-800 flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-2 text-xs text-slate-300">
            <Bell className="w-4 h-4 text-amber-400" />
            <span>خاصية التنبيه الذكي بالصلاة على النبي:</span>
          </div>

          <div className="flex items-center gap-2">
            {[15, 30, 60].map((mins) => (
              <button
                key={mins}
                onClick={() => setSalawatIntervalMins(mins)}
                className={`px-3 py-1 rounded-xl text-xs font-medium transition-colors ${
                  salawatIntervalMins === mins
                    ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40'
                    : 'bg-slate-800 text-slate-400 hover:text-white'
                }`}
              >
                كل {mins} دقيقة
              </button>
            ))}

            <button
              onClick={toggleSalawatReminder}
              className={`px-3 py-1 rounded-xl text-xs font-bold transition-colors ${
                salawatReminderActive
                  ? 'bg-emerald-500 text-slate-950'
                  : 'bg-slate-800 text-slate-400 hover:text-white'
              }`}
            >
              {salawatReminderActive ? 'مُفعّل' : 'تفعيل'}
            </button>
          </div>
        </div>
      </div>

      {/* Category Tabs */}
      <div className="flex items-center gap-2 overflow-x-auto pb-2 no-scrollbar">
        {categories.map((cat) => (
          <button
            key={cat.id}
            onClick={() => setSelectedCategory(cat.id)}
            className={`px-4 py-2 rounded-xl text-xs sm:text-sm font-semibold whitespace-nowrap transition-colors ${
              selectedCategory === cat.id
                ? 'bg-amber-500 text-slate-950 shadow-md shadow-amber-500/20'
                : 'bg-slate-900 border border-slate-800 text-slate-300 hover:bg-slate-800'
            }`}
          >
            {cat.label}
          </button>
        ))}
      </div>

      {/* Articles Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {filtered.map((item) => (
          <div
            key={item.id}
            className="p-6 rounded-3xl bg-slate-900/80 border border-slate-800 text-right space-y-4 hover:border-amber-500/30 transition-colors"
          >
            <div className="flex items-center justify-between">
              <span className="text-xs font-semibold text-amber-400">
                {item.categoryAr}
              </span>
              <BookOpen className="w-4 h-4 text-amber-400/60" />
            </div>

            <h3 className="text-xl font-bold text-amber-200 font-quran">
              {item.titleAr}
            </h3>

            <p className="text-xs text-slate-300 leading-relaxed">
              {item.summaryAr}
            </p>

            <div className="p-3.5 rounded-2xl bg-amber-500/5 border border-amber-500/20">
              <p className="text-sm font-quran text-amber-100 leading-relaxed">
                {item.hadithAr}
              </p>
              <span className="block text-[11px] text-amber-400/70 mt-1">
                المصدر: {item.sourceAr}
              </span>
            </div>

            <div className="space-y-1.5 pt-1">
              <span className="text-xs font-bold text-slate-300 block">
                أهم الثمرات والفضائل:
              </span>
              <ul className="space-y-1 text-xs text-slate-400">
                {item.benefitsAr.map((benefit, bIdx) => (
                  <li key={bIdx} className="flex items-start gap-2">
                    <span className="text-amber-400 font-bold">•</span>
                    <span>{benefit}</span>
                  </li>
                ))}
              </ul>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
