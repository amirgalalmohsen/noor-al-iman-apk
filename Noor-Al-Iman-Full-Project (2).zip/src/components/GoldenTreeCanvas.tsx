import React, { useEffect, useRef, useState } from 'react';
import { Sparkles, Trophy, Share2, Droplets, CheckCircle2, Award, Heart } from 'lucide-react';
import { calculateTreeProgress, TREE_STAGES } from '../utils/goldenTree';

interface GoldenTreeCanvasProps {
  totalHasanat: number;
  onAddHasanat: (amount: number, reason: string) => void;
  onShareToCommunity?: () => void;
}

export const GoldenTreeCanvas: React.FC<GoldenTreeCanvasProps> = ({
  totalHasanat,
  onAddHasanat,
  onShareToCommunity,
}) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const [justWatered, setJustWatered] = useState(false);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  const progress = calculateTreeProgress(totalHasanat);

  const triggerToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 3000);
  };

  const handleWaterTree = () => {
    setJustWatered(true);
    onAddHasanat(30, 'سِقاية شجرة الحسنات بذكر الله والاستغفار');
    triggerToast('تمت سقاية شجرتك المباركة! +30 حسنة ونمت فروع الذهب ✨');
    setTimeout(() => setJustWatered(false), 1200);
  };

  // Draw the fractal golden tree on Canvas
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animationFrameId: number;
    let time = 0;

    const width = canvas.width;
    const height = canvas.height;

    const drawBranch = (
      startX: number,
      startY: number,
      len: number,
      angle: number,
      branchWidth: number,
      depth: number,
      maxDepth: number
    ) => {
      ctx.beginPath();
      ctx.save();
      ctx.strokeStyle = '#D4AF37'; // Golden
      ctx.lineWidth = branchWidth;
      ctx.lineCap = 'round';

      // Subtle golden shimmer gradient
      const endX = startX + len * Math.sin(angle);
      const endY = startY - len * Math.cos(angle);

      const grad = ctx.createLinearGradient(startX, startY, endX, endY);
      grad.addColorStop(0, '#B45309'); // Amber base
      grad.addColorStop(0.5, '#F59E0B'); // Warm gold
      grad.addColorStop(1, '#FDE68A'); // Gleaming gold tip
      ctx.strokeStyle = grad;

      ctx.moveTo(startX, startY);
      ctx.lineTo(endX, endY);
      ctx.stroke();

      if (depth >= maxDepth) {
        // Draw shimmering golden leaf / flower
        const leafSize = 4 + (progress.goldLusterIndex * 4);
        ctx.fillStyle = '#FBBF24';
        ctx.shadowColor = '#F59E0B';
        ctx.shadowBlur = 8 + Math.sin(time + endX) * 4;

        ctx.beginPath();
        ctx.arc(endX, endY, leafSize, 0, Math.PI * 2);
        ctx.fill();

        // Inner glowing core
        ctx.fillStyle = '#FFFBEB';
        ctx.beginPath();
        ctx.arc(endX, endY, leafSize * 0.4, 0, Math.PI * 2);
        ctx.fill();

        ctx.restore();
        return;
      }

      ctx.restore();

      // Branching with slight organic wind sway
      const wind = Math.sin(time * 0.02 + depth) * 0.05;
      const subBranches = depth < 2 ? 3 : 2;
      const angleSpread = 0.35 + (depth * 0.05);

      for (let i = 0; i < subBranches; i++) {
        const offsetAngle = (i - (subBranches - 1) / 2) * angleSpread + wind;
        const nextLen = len * (0.68 + Math.sin(i * 1.5) * 0.08);
        drawBranch(
          endX,
          endY,
          nextLen,
          angle + offsetAngle,
          Math.max(1, branchWidth * 0.65),
          depth + 1,
          maxDepth
        );
      }
    };

    const render = () => {
      time += 1;
      ctx.clearRect(0, 0, width, height);

      // Deep celestial spiritual night background
      const bgGrad = ctx.createRadialGradient(width / 2, height / 2, 20, width / 2, height / 2, width / 1.5);
      bgGrad.addColorStop(0, '#064e3b22'); // Deep Emerald
      bgGrad.addColorStop(1, '#022c2200');
      ctx.fillStyle = bgGrad;
      ctx.fillRect(0, 0, width, height);

      // Floating golden dust particles
      const particleCount = 15 + Math.floor(progress.activeLeaves / 5);
      ctx.fillStyle = 'rgba(251, 191, 36, 0.4)';
      for (let p = 0; p < particleCount; p++) {
        const px = (Math.sin(p * 99 + time * 0.01) * 0.5 + 0.5) * width;
        const py = ((p * 25 + time * 0.5) % height);
        const radius = 1 + (p % 3);
        ctx.beginPath();
        ctx.arc(px, height - py, radius, 0, Math.PI * 2);
        ctx.fill();
      }

      // Base trunk coordinates
      const startX = width / 2;
      const startY = height - 30;
      const trunkLen = 65 + Math.min(25, progress.currentLevel.stage * 5);
      const trunkWidth = 10 + Math.min(6, progress.currentLevel.stage * 1.5);
      const maxDepth = Math.min(5, 2 + progress.currentLevel.stage);

      drawBranch(startX, startY, trunkLen, 0, trunkWidth, 0, maxDepth);

      // Grass / golden mound at the bottom
      ctx.fillStyle = '#065F46';
      ctx.beginPath();
      ctx.ellipse(width / 2, height - 15, 120, 16, 0, 0, Math.PI * 2);
      ctx.fill();

      animationFrameId = requestAnimationFrame(render);
    };

    render();

    return () => {
      cancelAnimationFrame(animationFrameId);
    };
  }, [progress]);

  return (
    <div className="space-y-6">
      {/* Toast Alert */}
      {toastMessage && (
        <div className="fixed top-20 left-1/2 -translate-x-1/2 z-50 px-4 py-2.5 rounded-xl bg-amber-500/95 text-slate-950 font-bold text-sm shadow-xl flex items-center gap-2 animate-bounce">
          <Sparkles className="w-4 h-4 text-slate-950" />
          <span>{toastMessage}</span>
        </div>
      )}

      {/* Hero Header & Level Banner */}
      <div className="relative overflow-hidden rounded-3xl border border-amber-500/30 bg-gradient-to-br from-slate-900 via-slate-950 to-emerald-950/40 p-6 sm:p-8">
        <div className="absolute -top-24 -left-24 w-72 h-72 rounded-full bg-amber-500/10 blur-3xl pointer-events-none" />
        <div className="absolute -bottom-24 -right-24 w-72 h-72 rounded-full bg-emerald-500/10 blur-3xl pointer-events-none" />

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
          {/* Canvas Section */}
          <div className="lg:col-span-6 flex flex-col items-center">
            <div className="relative w-full max-w-[420px] aspect-square rounded-2xl bg-slate-950/80 border border-amber-500/20 p-2 shadow-2xl flex items-center justify-center">
              <canvas
                ref={canvasRef}
                width={400}
                height={400}
                className="w-full h-full object-contain"
              />
              <div className="absolute top-4 right-4 px-3 py-1 rounded-full bg-amber-500/20 border border-amber-500/40 text-amber-300 text-xs font-semibold backdrop-blur-md">
                {progress.currentLevel.badge}
              </div>
              <div className="absolute bottom-4 left-4 px-3 py-1 rounded-full bg-emerald-950/80 border border-emerald-500/40 text-emerald-300 text-xs font-medium backdrop-blur-md">
                🌿 {progress.activeLeaves} ورقة ذهبية متفتحة
              </div>
            </div>

            {/* Action Bar Below Canvas */}
            <div className="flex items-center gap-3 mt-4 w-full max-w-[420px]">
              <button
                onClick={handleWaterTree}
                className={`flex-1 flex items-center justify-center gap-2 py-2.5 px-4 rounded-xl text-sm font-bold transition-all shadow-md ${
                  justWatered
                    ? 'bg-emerald-500 text-slate-950 scale-95'
                    : 'bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-slate-950 shadow-amber-500/20'
                }`}
              >
                <Droplets className="w-4 h-4" />
                <span>اسقِ الشجرة بالاستغفار (+30)</span>
              </button>

              {onShareToCommunity && (
                <button
                  onClick={onShareToCommunity}
                  className="p-2.5 rounded-xl bg-slate-900 border border-amber-500/30 text-amber-300 hover:bg-slate-800 transition-colors"
                  title="مشاركة إنجاز شجرتك في مجتمع الذاكرين"
                  aria-label="مشاركة الشجرة"
                >
                  <Share2 className="w-4 h-4" />
                </button>
              )}
            </div>
          </div>

          {/* Details & Progress Stats */}
          <div className="lg:col-span-6 space-y-5 text-right">
            <div>
              <span className="text-xs font-semibold text-amber-400 tracking-wider">
                المستوى {progress.currentLevel.stage} من 5
              </span>
              <h2 className="text-2xl sm:text-3xl font-extrabold text-amber-100 font-quran mt-1">
                {progress.currentLevel.titleAr}
              </h2>
              <p className="text-sm text-slate-400 mt-1">
                {progress.currentLevel.subTitleAr}
              </p>
            </div>

            {/* Hadith Callout */}
            <div className="p-4 rounded-2xl bg-amber-500/5 border border-amber-500/20">
              <p className="text-sm text-amber-200/90 font-quran leading-relaxed">
                قال رسول الله ﷺ: «{progress.currentLevel.hadithAr}»
              </p>
            </div>

            {/* Level Progress Bar */}
            <div className="space-y-2">
              <div className="flex items-center justify-between text-xs font-medium text-slate-400">
                <span>المستوى التالي: {progress.nextLevel ? progress.nextLevel.titleAr : 'أعلى المستويات'}</span>
                <span className="text-amber-300 font-bold tabular-nums">
                  {progress.progressPercent}%
                </span>
              </div>
              <div className="w-full h-3 rounded-full bg-slate-900 border border-slate-800 overflow-hidden">
                <div
                  className="h-full bg-gradient-to-r from-amber-600 to-amber-400 transition-all duration-500 rounded-full"
                  style={{ width: `${progress.progressPercent}%` }}
                />
              </div>
              {progress.nextLevel && (
                <p className="text-[11px] text-slate-500">
                  متبقي {progress.pointsToNextLevel.toLocaleString('ar-EG')} نقطة صالحة للارتقاء إلى المستوى القادم
                </p>
              )}
            </div>

            {/* 3 Metric Cards */}
            <div className="grid grid-cols-3 gap-3 pt-2">
              <div className="p-3 rounded-xl bg-slate-900/80 border border-slate-800 text-center">
                <span className="text-xl sm:text-2xl font-bold text-amber-300 tabular-nums">
                  {totalHasanat.toLocaleString('ar-EG')}
                </span>
                <p className="text-[11px] text-slate-400 mt-0.5">مجموع الحسنات</p>
              </div>

              <div className="p-3 rounded-xl bg-slate-900/80 border border-slate-800 text-center">
                <span className="text-xl sm:text-2xl font-bold text-amber-300 tabular-nums">
                  {progress.activeLeaves}
                </span>
                <p className="text-[11px] text-slate-400 mt-0.5">أوراق الذهب</p>
              </div>

              <div className="p-3 rounded-xl bg-slate-900/80 border border-slate-800 text-center">
                <span className="text-xl sm:text-2xl font-bold text-emerald-400 tabular-nums">
                  {progress.currentLevel.stage} / 5
                </span>
                <p className="text-[11px] text-slate-400 mt-0.5">درجة الشجرة</p>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Levels Milestone Roadmap */}
      <div className="p-6 rounded-3xl bg-slate-900/60 border border-slate-800 space-y-4">
        <h3 className="text-lg font-bold text-slate-200 flex items-center gap-2">
          <Trophy className="w-5 h-5 text-amber-400" />
          <span>مراتب شجرة الحسنات الذهبية</span>
        </h3>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-3">
          {TREE_STAGES.map((stg) => {
            const isCurrent = stg.stage === progress.currentLevel.stage;
            const isCompleted = progress.currentPoints >= stg.maxPoints;

            return (
              <div
                key={stg.stage}
                className={`p-4 rounded-2xl border transition-all ${
                  isCurrent
                    ? 'bg-amber-500/15 border-amber-500/50 shadow-md shadow-amber-500/10'
                    : isCompleted
                    ? 'bg-slate-900/90 border-emerald-500/30'
                    : 'bg-slate-950/40 border-slate-800 opacity-60'
                }`}
              >
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-amber-400">
                    مستوى {stg.stage}
                  </span>
                  {isCompleted ? (
                    <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                  ) : isCurrent ? (
                    <Sparkles className="w-4 h-4 text-amber-400 animate-spin" />
                  ) : null}
                </div>
                <h4 className="text-sm font-bold text-slate-200 mt-2 font-quran">
                  {stg.titleAr}
                </h4>
                <p className="text-[11px] text-slate-400 mt-1 line-clamp-2">
                  {stg.subTitleAr}
                </p>
                <div className="mt-3 text-[10px] text-amber-400/80 font-medium">
                  {stg.goldenLeavesCount} ورقة ذهبية
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
