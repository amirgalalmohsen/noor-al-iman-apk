# تطبيق «نُورُ الإِيمَان» الشامل | Noor Al-Iman

> **تصميم وتطوير: أمير جلال (Amir Galal)**  
> **حزمة تطبيق الأندرويد:** `com.amirgalal.nooreleman`  
> **الرابط المباشر:** [https://amir-galal.ai.studio/](https://amir-galal.ai.studio/)

---

## 📌 نبذة عن المشروع
تطبيق إسلامي متطور شامل يدمج بين التصميم العصري الفاخر (Dark Navy & Gold) والتجربة البرمجية السريعة والآمنة. يضم:
- **القرآن الكريم كاملاً:** قراءة ميسرة بالرسم العثماني، تلاوات صوتية عطرة، وتفسير للآيات.
- **شجرة الحسنات الذهبية:** نظام بصري تحفيزي تفاعلي يحول الطاعات والأذكار إلى أوراق شجرة ذهبية نامية.
- **الأذكار والمسبحة الذكية:** أذكار الصباح والمساء واليوم والليلة، ومسبحة لمسية ذكية مع حفظ الأوراد محلياً.
- **بوصلة القبلة:** حساب دقيق لاتجاه الكعبة المشرفة وفق الإحداثيات الجغرافية.
- **المجتمع الإيماني:** مشاركة الأدعية والتحديات الخيرية.
- **تطبيق Android أصلي كامل:** مشروع WebView متقدم داخل `native-android/` جاهز للبناء التلقائي عبر GitHub Actions.

---

## 🌐 قنوات التواصل الرسمية للمصمم أمير جلال

- **Facebook:** [https://www.facebook.com/MR.AmirGalal](https://www.facebook.com/MR.AmirGalal) (`MR.AmirGalal`)
- **Instagram:** [https://www.instagram.com/amir____galal/](https://www.instagram.com/amir____galal/) (`amir____galal`)
- **X (Twitter):** [https://x.com/amir____galal](https://x.com/amir____galal) (`amir____galal`)
- **Threads:** [https://www.threads.net/@amir____galal](https://www.threads.net/@amir____galal) (`@amir____galal`)

---

## 📂 البنية الكاملة للمشروع

```text
noor-al-iman/
├── src/                                  # الكود المصدري لموقع الويب (React 19 + TypeScript + Tailwind CSS)
│   ├── components/                       # المكونات (شجرة الحسنات، القرآن، الأذكار، القبلة، عن التطبيق، إلخ)
│   ├── data/                             # بيانات السور والأذكار والفضائل
│   ├── utils/                            # الحسابات الفلكية واختبارات القبلة وشجرة الحسنات
│   ├── App.tsx                           # المكون الجذري والواجهة الرئيسية
│   └── main.tsx                          # نقطة الدخول
├── public/                               # الملفات الثابتة والأيقونات وشعار أمير جلال
│   ├── amir-galal.svg                    # الصورة الرمزية للمصمم أمير جلال
│   ├── icon-192.png & icon-512.png       # أيقونات التطبيق الرسمية
│   ├── manifest.json                     # ملف تعريف PWA
│   └── sw.js                             # Service Worker للتخزين المؤقت
├── native-android/                       # مشروع أندرويد الأصلي الكامل (Android Studio)
│   ├── app/                              # وحدة تطبيق الأندرويد (SDK 34)
│   │   ├── src/main/java/.../MainActivity.kt # كود أندرويد لـ WebView وشاشة انقطاع النت والتنزيلات
│   │   ├── src/main/AndroidManifest.xml  # إعدادات الحزمة والصلاحيات واسم نور الإيمان
│   │   ├── src/main/res/mipmap-*/        # كافة مقاسات الأيقونات الرسمية بدقة فائقة
│   │   └── src/main/res/xml/             # تأمين الاتصال الشبكي ومنع Cleartext HTTP
│   └── gradle/wrapper/ & gradlew         # أداة بناء Gradle 8.5 الرسمية
├── .github/workflows/
│   └── build-android-apk.yml             # سير عمل GitHub Actions الآلي لبناء وتوقيع ونشر APK
├── README-APK.md                         # دليل تفصيلي خطوة بخطوة لبناء وتثبيت ملف APK
├── package.json                          # تبعيات المشروع
├── tsconfig.json                         # إعدادات TypeScript
└── vite.config.ts                        # إعدادات مجمع Vite
```

---

## 🚀 طريقة تشغيل موقع الويب محلياً

```bash
# تثبيت التبعيات
npm install

# تشغيل بيئة التطوير
npm run dev

# بناء النسخة الإنتاجية
npm run build
```

---

## 📱 طريقة بناء تطبيق Android واستخراج APK

راجع ملف `README-APK.md` للحصول على الشرح الكامل خطوة بخطوة.  
ملخص سريع:
1. ارفع المشروع إلى مستودع عام على **GitHub**.
2. افتح تبويب **Actions** واختر **Build & Release Noor Al-Iman APK**.
3. اضغط **Run workflow**؛ سيقوم GitHub Actions ببناء ملف `Noor-Al-Iman.apk` تلقائياً ونشره في قسم **Releases**.
4. رابط التنزيل الدائم لأحدث ملف APK:
   `https://github.com/OWNER/REPOSITORY/releases/latest/download/Noor-Al-Iman.apk`

---

## 🤲 دعاء ختامي
«اللَّهُمَّ اجْعَلْ هَذَا الْعَمَلَ خَالِصاً لِوَجْهِكَ الْكَرِيمِ، وَتَقَبَّلْهُ مِنَّا وَمِنْ كُلِّ مَنْ قَرَأَ فِيهِ أَوْ نَشَرَهُ، وَاجْعَلْهُ فِي مِيزَانِ حَسَنَاتِنَا يَوْمَ نَلْقَاكَ»
